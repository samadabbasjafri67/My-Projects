import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import dotenv from "dotenv";
import cors from "cors";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // API routes
  app.post("/api/verify-upi-payment", async (req, res) => {
    try {
      const { amount, upiId } = req.body;

      // In a real production app, you would use a payment gateway API
      // to check the status of the UPI transaction.
      // For this implementation, we'll simulate a successful verification.
      
      console.log(`Verifying UPI Payment for Amount: ${amount}, UPI ID: ${upiId}`);

      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      res.json({
        success: true,
        transactionId: `upi_${Math.random().toString(36).substr(2, 9)}`,
        message: "UPI Payment verified successfully"
      });
    } catch (error: any) {
      res.status(500).send({ error: error.message });
    }
  });

  // API Route to proxy Gemini chatbot requests securely on the server
  app.post("/api/chatbot", async (req, res) => {
    try {
      const { language, messages } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey) {
        console.warn("GEMINI_API_KEY is not set. ChatBot returning simulation fallback.");
        return res.json({
          reply: language === 'hi'
            ? "नमस्ते! अभी मेरा मुख्य सर्वर सक्रिय नहीं है (कोई API कुंजी नहीं मिली), लेकिन मैं सिम्युलेटेड मोड में चल रहा हूँ। मैं एक तेज़ और सुरक्षित राइड ढूंढने में आपकी मदद कर सकता हूँ!"
            : "Hello! My main server is not active (missing API key), but I am running in offline simulation mode. I can still guide you regarding women-only rides, EV rides, and carbon analytics!"
        });
      }

      const systemInstruction = `You are the EcoPool Assistant, a helpful AI guide for the EcoPool carpooling platform.
EcoPool features:
- Community-based carpooling to save the planet.
- Women-Only Rides: Exclusive safety for female passengers.
- EV Tracking & Green Mobility: Dedicated EV category with integration to see charging stations.
- Carbon Analytics: Track CO2 savings and tree equivalents in EV Analytics.
- Dynamic Pricing: AI-optimized ride prices.
- Smart Match Score: Real-time matching based on route and preferences.
- Live Tracking: Real-time driver location and journey status.
- Wallet & Rewards: Cashbacks, referrals (₹50 bonus), and internal UPI-like payments.
- Parcel Delivery: Send packages with trusted riders.
- SOS Button: Emergency alerts for safety.
- Subscription Plans: Free and premium layers.

Guidelines:
1. Be polite, enthusiastic, and concise.
2. Support both English and Hindi based on the user's input/preference (the app language is currently ${language === 'hi' ? 'Hindi' : 'English'}).
3. If users ask about features, explain how they benefit them (saving money, environment, or safety).
4. Do not mention that you are an AI or a language model unless asked.
5. Use emojis to keep the conversation friendly.`;

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: messages.map((m: any) => ({
          role: m.role === 'model' ? 'model' : 'user',
          parts: [{ text: m.content || '' }]
        })),
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      const reply = response.text || (language === 'hi' ? "क्षमा करें, मैं इसे समझ नहीं पाया।" : "Sorry, I couldn't process that.");
      res.json({ reply });
    } catch (error: any) {
      console.error("Server ChatBot Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // API Route to proxy Gemini carpooling price negotiation securely on the server
  app.post("/api/negotiate", async (req, res) => {
    try {
      const { language, originalPrice, offeredVal, minFair, maxFair, rideFrom, rideTo } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey) {
        console.warn("GEMINI_API_KEY is not set. Returning simulation fallback code.");
        return res.json({ success: false, error: "Missing API Key" });
      }

      const promptMsg = `You are a helpful Indian Carpooling Pricing negotiation bot. 
The driver of a ride from "${rideFrom}" to "${rideTo}" originally priced the ride at ₹${originalPrice} per seat.
The passenger is trying to bargain/negotiate and has offered ₹${offeredVal}.
Under current market trends, dynamic traffic, and driver feedback, the intelligent fair price range (82% to 90% of original) is determined as ₹${minFair} - ₹${maxFair}.

Determine if the offered price is:
1. Too low (e.g. offered < ₹${minFair}). Refuse and counter with a higher price around the maxFair or middle.
2. Extremely reasonable (e.g. offered >= ₹${minFair} and offered <= ₹${maxFair}). Accept or make a very minor friendly compromise counter (e.g., if he offers 170 in 165-180, counter with 175, or accept 175 if exact).
3. Fair & Close enough: If he offers close to maxFair or higher, accept it outright!

Your response MUST contain the exact text "Fair price range ₹${minFair}–₹${maxFair}" (and use dynamic Indian English / Hindi mix colloquialisms like "Chalo, let's meet at...", "Abey yaar, fuel is too expensive...", "Perfect range!", "Bhai, look at traffic!").
Format your response to naturally represent what the AI system calculated, and then what the Driver says.
Make it concise (2-4 lines max).
Return JSON matching this schema:
{
  "aiAnalysis": "The fair price range calculated by AI...",
  "status": "approved" | "rejected" | "countered",
  "counterPrice": number
}
Input language preference: ${language === 'hi' ? 'Hindi' : 'English'}. Respond in that language with local touch.`;

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: promptMsg,
        config: {
          responseMimeType: "application/json",
        }
      });

      if (response.text) {
        try {
          const parsed = JSON.parse(response.text.trim());
          return res.json({
            success: true,
            aiAnalysis: parsed.aiAnalysis,
            status: parsed.status,
            counterPrice: parsed.counterPrice || offeredVal
          });
        } catch (jsonErr) {
          console.warn("Got non-JSON response from Gemini. Text was:", response.text);
          throw new Error("Gemini returned invalid JSON: " + response.text);
        }
      }

      throw new Error("Empty response from Gemini");
    } catch (error: any) {
      console.error("Server Negotiation Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // API route to send Brevo booking and cancellation emails
  app.post("/api/send-booking-notification", async (req, res) => {
    const apiKey = process.env.BREVO_API_KEY;
    if (!apiKey) {
      console.warn("BREVO_API_KEY environment variable is not set. Skipping email dispatch.");
      return res.status(202).json({
        success: true,
        simulated: true,
        message: "BREVO_API_KEY environment variable is missing. Simulated successful email send."
      });
    }

    const { type, booking, passenger, driver, cancelReason, cancelledBy } = req.body;

    try {
      const emailHeader = (title: string, subtitle: string) => `
        <div style="background-color: #1d4ed8; color: #ffffff; padding: 24px; text-align: center; border-top-left-radius: 8px; border-top-right-radius: 8px;">
          <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px; font-family: sans-serif;">EcoPool</h1>
          <p style="margin: 4px 0 0; font-size: 14px; font-weight: 500; font-family: sans-serif; opacity: 0.9;">${title}</p>
          <span style="font-size: 11px; font-family: monospace; background-color: rgba(255,255,255,0.2); padding: 2px 6px; border-radius: 4px; display: inline-block; margin-top: 8px;">${subtitle}</span>
        </div>
      `;

      const emailFooter = `
        <div style="text-align: center; padding: 24px; color: #64748b; font-size: 12px; font-family: sans-serif; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; background-color: #f8fafc; border-top: 1px solid #e2e8f0;">
          <p style="margin: 0 0 8px;">🌱 Thank you for choosing EcoPool — share resources, build trust, reduce emissions.</p>
          <p style="margin: 0;">&copy; ${new Date().getFullYear()} EcoPool Inc. Standard notification service.</p>
        </div>
      `;

      const makeContainer = (content: string) => `
        <div style="max-width: 600px; margin: 24px auto; border: 1px solid #e2e8f0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); font-family: sans-serif; line-height: 1.5; color: #1e293b;">
          ${content}
        </div>
      `;

      let passengerEmailBody = "";
      let driverEmailBody = "";
      let passengerSubject = "";
      let driverSubject = "";

      const bTypeLabel = booking.type === 'parcel' ? 'Parcel Delivery' : 'Ride Booking';

      if (type === "confirmed") {
        passengerSubject = `EcoPool Booking Confirmed: ${booking.pickupLocation || booking.ride?.from} → ${booking.dropLocation || booking.ride?.to}`;
        passengerEmailBody = makeContainer(`
          ${emailHeader("Booking Confirmation Status", "RESERV_ID: " + (booking.id || "N/A").substring(0,8).toUpperCase())}
          <div style="padding: 24px; background-color: #ffffff;">
            <p style="margin-top: 0; font-size: 16px;">Hi <b>${passenger.name || "Customer"}</b>,</p>
            <p style="color: #475569;">Great news! Your <b>${bTypeLabel}</b> is confirmed. Details of your upcoming shared trip can be found below:</p>
            
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8fafc; border-radius: 6px;">
              <tr>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold; width: 35%;">Route:</td>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.pickupLocation || booking.ride?.from} ➔ ${booking.dropLocation || booking.ride?.to}</td>
              </tr>
              <tr>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Date &amp; Time:</td>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.ride?.date} at ${booking.ride?.time}</td>
              </tr>
              ${booking.type === 'parcel' ? `
                <tr>
                  <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Package:</td>
                  <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.parcelInfo?.itemType || 'Parcel'} (${booking.parcelInfo?.weight || 0} kg)</td>
                </tr>
                <tr>
                  <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Description:</td>
                  <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.parcelInfo?.description || 'N/A'}</td>
                </tr>
              ` : `
                <tr>
                  <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Seats:</td>
                  <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.seats || 1} seat(s)</td>
                </tr>
                ${booking.selectedSeatLabels ? `
                  <tr>
                    <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Seat Preference:</td>
                    <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.selectedSeatLabels.join(", ")}</td>
                  </tr>
                ` : ''}
              `}
              <tr>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Total Cost:</td>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; color: #1d4ed8; font-weight: bold;">₹${booking.totalPrice || booking.ride?.price || 0}</td>
              </tr>
              <tr>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Vehicle:</td>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.ride?.carName || 'Shared Vehicle'} (${booking.ride?.vehicleNumber || 'Standard Car'})</td>
              </tr>
              <tr>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Driver Name:</td>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${driver.name}</td>
              </tr>
              ${driver.phone ? `
                <tr>
                  <td style="padding: 12px; font-weight: bold;">Driver Phone:</td>
                  <td style="padding: 12px;">${driver.phone}</td>
                </tr>
              ` : ''}
            </table>

            ${booking.specialRequests ? `
              <div style="background-color: #fffbeb; border-left: 4px solid #f59e0b; padding: 12px; border-radius: 4px; margin: 16px 0;">
                <b style="color: #b45309; font-size: 13px; text-transform: uppercase;">Special Instructions / Requests:</b>
                <p style="margin: 4px 0 0; color: #78350f;">"${booking.specialRequests}"</p>
              </div>
            ` : ''}

            <p style="color: #475569; font-size: 13.5px; line-height: 1.6;">Please arrive at the starting point 5-10 minutes prior to departure. You can use the in-app chat for coordination.</p>
          </div>
          ${emailFooter}
        `);

        driverSubject = `New EcoPool Booking: ${booking.pickupLocation || booking.ride?.from} → ${booking.dropLocation || booking.ride?.to}`;
        driverEmailBody = makeContainer(`
          ${emailHeader("New Passenger Booking", "RIDE_ID: " + (booking.rideId || "N/A").substring(0,8).toUpperCase())}
          <div style="padding: 24px; background-color: #ffffff;">
            <p style="margin-top: 0; font-size: 16px;">Hi <b>${driver.name || "Driver"}</b>,</p>
            <p style="color: #475569;">A new passenger has booked a spot in your offering:</p>
            
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8fafc; border-radius: 6px;">
              <tr>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold; width: 35%;">Passenger Name:</td>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${passenger.name} (${passenger.email})</td>
              </tr>
              <tr>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Route Segment:</td>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.pickupLocation} ➔ ${booking.dropLocation}</td>
              </tr>
              <tr>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Date &amp; Time:</td>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.ride?.date} at ${booking.ride?.time}</td>
              </tr>
              ${booking.type === 'parcel' ? `
                <tr>
                  <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Package:</td>
                  <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.parcelInfo?.itemType || 'Parcel'} (${booking.parcelInfo?.weight || 0} kg)</td>
                </tr>
                <tr>
                  <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Description:</td>
                  <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.parcelInfo?.description || 'N/A'}</td>
                </tr>
              ` : `
                <tr>
                  <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Seats Booked:</td>
                  <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.seats} seat(s)</td>
                </tr>
                ${booking.selectedSeatLabels ? `
                  <tr>
                    <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Selected Seats:</td>
                    <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.selectedSeatLabels.join(", ")}</td>
                  </tr>
                ` : ''}
              `}
              <tr>
                <td style="padding: 12px; font-weight: bold;">Earnings for this segment:</td>
                <td style="padding: 12px; color: #16a34a; font-weight: bold;">₹${booking.totalPrice}</td>
              </tr>
            </table>

            ${booking.specialRequests ? `
              <div style="background-color: #fffbeb; border-left: 4px solid #f59e0b; padding: 12px; border-radius: 4px; margin: 16px 0;">
                <b style="color: #b45309; font-size: 13px; text-transform: uppercase;">Passenger Special Requests:</b>
                <p style="margin: 4px 0 0; color: #78350f;">"${booking.specialRequests}"</p>
              </div>
            ` : ''}

            <p style="color: #475569; font-size: 13.5px; line-height: 1.6;">You can coordinate with your passenger using the real-time chat in the EcoPool dashboard.</p>
          </div>
          ${emailFooter}
        `);
      } else if (type === "cancelled_by_passenger") {
        passengerSubject = `EcoPool Booking Cancelled: ${booking.pickupLocation} → ${booking.dropLocation}`;
        passengerEmailBody = makeContainer(`
          ${emailHeader("Booking Cancelled Successfully", "STATUS: CANCELLED")}
          <div style="padding: 24px; background-color: #ffffff;">
            <p style="margin-top: 0; font-size: 16px;">Hi <b>${passenger.name || "Customer"}</b>,</p>
            <p style="color: #475569;">At your request, your Booking for the segment <b>${booking.pickupLocation} ➔ ${booking.dropLocation}</b> has been cancelled.</p>
            
            <div style="background-color: #f1f5f9; padding: 16px; border-radius: 6px; margin: 16px 0;">
              <p style="margin: 0 0 8px; font-size: 14px;"><b>Cancellation Details:</b></p>
              <p style="margin: 4px 0; font-size: 13px; color: #475569;"><b>Reason:</b> ${cancelReason || "No reason specified"}</p>
              <p style="margin: 4px 0; font-size: 13px; color: #475569;"><b>Refund Applied:</b> ₹${booking.totalPrice} has been credited back to your EcoPool wallet.</p>
            </div>
          </div>
          ${emailFooter}
        `);

        driverSubject = `Passenger Cancellation: ${booking.pickupLocation} → ${booking.dropLocation}`;
        driverEmailBody = makeContainer(`
          ${emailHeader("Passenger Cancelled Booking", "STATUS: SEATS_RELEASED")}
          <div style="padding: 24px; background-color: #ffffff;">
            <p style="margin-top: 0; font-size: 16px;">Hi <b>${driver.name || "Driver"}</b>,</p>
            <p style="color: #475569;">Please be notified that passenger <b>${passenger.name}</b> cancelled their segment on your upcoming active ride:</p>
            
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8fafc; border-radius: 6px;">
              <tr>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold; width: 35%;">Cancelled Member:</td>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${passenger.name}</td>
              </tr>
              <tr>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">Released Spot(s):</td>
                <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${booking.seats} seats are back on matching pool</td>
              </tr>
              <tr>
                <td style="padding: 12px; font-weight: bold;">Cancellation Reason:</td>
                <td style="padding: 12px;">${cancelReason || "Not specified."}</td>
              </tr>
            </table>

            <p style="color: #475569; font-size: 13.5px;">These seats have been re-listed into the active search options automatically.</p>
          </div>
          ${emailFooter}
        `);
      } else if (type === "cancelled_by_driver") {
        passengerSubject = `EcoPool Ride Cancelled by Driver: ${booking.pickupLocation} → ${booking.dropLocation}`;
        passengerEmailBody = makeContainer(`
          ${emailHeader("Ride Cancelled By Driver", "STATUS: REFUNDED")}
          <div style="padding: 24px; background-color: #ffffff;">
            <p style="margin-top: 0; font-size: 16px;">Hi <b>${passenger.name || "Customer"}</b>,</p>
            <p style="color: #e11d48; font-weight: bold;">We regret to inform you that the driver cancelled this entire scheduled trip.</p>
            
            <div style="background-color: #fef2f2; border-left: 4px solid #ef4444; padding: 16px; border-radius: 6px; margin: 16px 0;">
              <p style="margin: 0; font-size: 13.5px; color: #991b1b;"><b>Reason given by Driver:</b> "${cancelReason || "None given"}"</p>
              <p style="margin: 8px 0 0; font-size: 13px; color: #15803d; font-weight: 700;">✓ A full refund of ₹${booking.totalPrice} is credited instantly to your EcoPool wallet balance.</p>
            </div>
            
            <p style="color: #475569; font-size: 13.5px;">Please check our interactive ride dashboard to find other compatible carpool matches available.</p>
          </div>
          ${emailFooter}
        `);

        driverSubject = `Your EcoPool Ride Cancellation Confirmation`;
        driverEmailBody = makeContainer(`
          ${emailHeader("Your Ride is Cancelled", "STATUS: CANCEL_OK")}
          <div style="padding: 24px; background-color: #ffffff;">
            <p style="margin-top: 0; font-size: 16px;">Hi <b>${driver.name || "Driver"}</b>,</p>
            <p style="color: #475569;">You successfully cancelled your offered ride from <b>${booking.pickupLocation}</b> to <b>${booking.dropLocation}</b>.</p>
            <p style="color: #475569;">All registered passengers and segments were cancelled and fully refunded.</p>
            <p style="color: #64748b; font-size: 12px; font-style: italic;">Note: Excessive or late cancellations can lower your platform rating scores.</p>
          </div>
          ${emailFooter}
        `);
      }

      const senderEmail = process.env.BREVO_SENDER_EMAIL || "samadabbasjafri67@gmail.com";
      console.log(`Starting Brevo email dispatch with sender: ${senderEmail}`);

      const promises = [];

      // Send to Passenger
      if (passenger.email) {
        promises.push(
          fetch("https://api.brevo.com/v3/smtp/email", {
            method: "POST",
            headers: {
              "accept": "application/json",
              "api-key": apiKey,
              "content-type": "application/json"
            },
            body: JSON.stringify({
              sender: { name: "EcoPool Carpool", email: senderEmail },
              to: [{ email: passenger.email, name: passenger.name || "Passenger" }],
              subject: passengerSubject,
              htmlContent: passengerEmailBody
            })
          }).then(async (r) => {
            const data = await r.json();
            if (!r.ok) {
              console.warn(`Brevo passenger email dispatch returned status ${r.status}: ${JSON.stringify(data)}`);
              return { r_ok: false, target: "passenger", error: data };
            }
            return { r_ok: true, target: "passenger", data };
          })
        );
      }

      // Send to Driver
      if (driver.email) {
        promises.push(
          fetch("https://api.brevo.com/v3/smtp/email", {
            method: "POST",
            headers: {
              "accept": "application/json",
              "api-key": apiKey,
              "content-type": "application/json"
            },
            body: JSON.stringify({
              sender: { name: "EcoPool Carpool", email: senderEmail },
              to: [{ email: driver.email, name: driver.name || "Driver" }],
              subject: driverSubject,
              htmlContent: driverEmailBody
            })
          }).then(async (r) => {
            const data = await r.json();
            if (!r.ok) {
              console.warn(`Brevo driver email dispatch returned status ${r.status}: ${JSON.stringify(data)}`);
              return { r_ok: false, target: "driver", error: data };
            }
            return { r_ok: true, target: "driver", data };
          })
        );
      }

      const results = await Promise.all(promises);

      // Check if any email attempt returned a Brevo API failure
      const failed = results.find(res => !res.r_ok);
      if (failed) {
        console.warn(
          `Brevo email dispatch failed. For real emails, configure BREVO_API_KEY & BREVO_SENDER_EMAIL correctly. Failing target: ${failed.target}. Error details: ${JSON.stringify(failed.error)}`
        );
        return res.json({
          success: true,
          simulated: true,
          message: `Brevo sending failed for ${failed.target} (falling back to simulation). Error: ${JSON.stringify(failed.error)}`
        });
      }

      return res.json({ success: true, results });

    } catch (error: any) {
      console.error("Failed to send Brevo notification:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
