/**
 * Compresses and resizes an image to keep it safe for Firestore storage (under 1MB limit).
 * Resizes the image to fit within maxWidth x maxHeight and compresses it using JPEG.
 */
export const compressImage = (dataUrl: string, maxWidth = 600, maxHeight = 600): Promise<string> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      // Calculate new dimensions
      if (width > height) {
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }
      }

      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(dataUrl);
        return;
      }

      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);
      
      // Compress to JPEG with 0.6 quality
      const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.6);
      resolve(compressedDataUrl);
    };
    img.onerror = (err) => {
      reject(err);
    };
    img.src = dataUrl;
  });
};
