export interface User {
  username: string;
  password?: string;
  role: 'user' | 'admin' | 'driver';
  registrationDate?: string;
  totalBookings?: number;
  carbonSaved?: number;
  totalRides?: number;
  points?: number;
  badges?: string[];
  subscription?: { plan: string; expiry: string | null };
  profilePhoto?: string | null;
  phone?: string;
  email?: string;
  isVerified?: boolean;
  verificationDocuments?: any[];
  verificationStatus?: string;
  vehicleDetails?: any;
  isEV?: boolean;
  batteryCapacity?: number | null;
  rating?: number;
  verificationSubmittedAt?: string;
  reviewedAt?: string;
  rejectionReason?: string;
  rejectedAt?: string;
  fullName?: string;
  aadharNumber?: string;
  vehicleNumber?: string;
  licenseNumber?: string;
  licenseImage?: string | null;
  registrationImage?: string | null;
  carName?: string;
  carType?: 'bike' | 'hatchback' | 'sedan' | 'suv' | 'muv' | 'luxury' | 'other';
  carImage?: string | null;
  notificationsEnabled?: boolean;
  notificationPreferences?: {
    newRideMatches: boolean;
    bookingUpdates: boolean;
    sosAlerts: boolean;
    promotionalMessages: boolean;
  };
  pushToken?: string | null;
  status?: 'online' | 'busy' | 'offline';
  currentLocation?: {
    lat: number;
    lng: number;
    timestamp: string;
  };
  lastActiveAt?: string;
  walletBalance?: number;
  referralCode?: string;
  referredBy?: string | null;
  totalCashbackEarned?: number;
  isFlagged?: boolean;
  fraudScore?: number; // 0 to 100, 0 is best
  cancellationCount?: number;
  suspiciousActivityCount?: number;
  lastFraudCheckAt?: string;
  trustLevel?: 'trusted' | 'neutral' | 'suspicious' | 'blocked';
  frequentLocations?: Array<{
    id: string;
    label: 'Home' | 'College' | 'Work' | 'Other';
    address: string;
    icon?: string;
  }>;
  learnedPreferences?: {
    prefersAC?: number; // scale 0 to 1
    prefersEV?: number;
    prefersLowPrice?: number;
    prefersWomenOnly?: number;
    frequentRideType?: 'passenger' | 'parcel';
  };
  driverEarnings?: {
    today: number;
    thisWeek: number;
    thisMonth: number;
    total: number;
    weeklyHistory: Array<{ day: string; amount: number }>;
  };
}

export interface WalletTransaction {
  id: string;
  userId: string;
  amount: number;
  type: 'credit' | 'debit';
  reason: 'ride_payment' | 'cashback_ride' | 'cashback_referral' | 'top_up' | 'refund';
  createdAt: string;
}

export interface Location {
  lat: number;
  lng: number;
  timestamp: string;
}

export interface Ride {
  id: string | number;
  driver: string;
  from: string;
  to: string;
  date: string;
  time: string;
  price: number;
  seats: number;
  bookings: any[];
  type: 'ride' | 'parcel';
  luggageCapacity?: 'none' | 'small' | 'medium' | 'large';
  parcelDetails?: {
    maxWeight: number; // in kg
    maxSize: 'small' | 'medium' | 'large';
    description?: string;
  };
  isRecurring?: boolean;
  recurringPattern?: string[];
  isEV?: boolean;
  vehiclePoolType?: 'car' | 'bike' | 'ev';
  helmetAvailable?: boolean;
  batteryRange?: string | number | null;
  amenities?: string[];
  dynamicPricing?: any;
  createdAt?: string;
  driverVerified?: boolean;
  driverPhone?: string | null;
  driverEmail?: string | null;
  matchScore?: number;
  averageRating?: number;
  ratingCount?: number;
  vehicleNumber?: string;
  carName?: string;
  carType?: 'bike' | 'hatchback' | 'sedan' | 'suv' | 'muv' | 'luxury' | 'other';
  carImage?: string | null;
  womenOnly?: boolean;
  fromCoords?: { lat: number, lng: number };
  waypoints?: Array<{
    address: string;
    coords?: { lat: number, lng: number };
  }>;
  optimizationTags?: Array<'fastest' | 'cheapest' | 'eco'>;
  currentLocation?: Location;
}

export interface Booking {
  id: string;
  ride: Ride;
  seats: number;
  pickupLocation: string;
  dropLocation: string;
  luggageSize?: 'none' | 'small' | 'medium' | 'large';
  seatPreference?: 'front' | 'back_window' | 'back_middle';
  selectedSeats?: string[];
  selectedSeatLabels?: string[];
  seatGenders?: Record<string, 'any' | 'female' | 'male'>;
  type: 'passenger' | 'parcel';
  parcelInfo?: {
    weight: number;
    description: string;
    itemType: string;
  };
  specialRequests?: string;
  totalPrice: number;
  bookingType: string;
  scheduleDate: string | null;
  scheduleTime: string | null;
  bookedAt: string;
  status: string;
  pickupStatus: string;
  passenger: string;
  passengerName?: string;
  passengerPhoto?: string | null;
  passengerVerified?: boolean;
  passengerReady?: boolean;
  driverId: string;
  payment?: any;
  paymentIntentId?: string;
  pickupVerifiedAt?: string;
  currentLocation?: Location;
  isFlagged?: boolean;
  fraudReason?: string;
  cancellationReason?: string;
}

export interface Rating {
  id: string;
  rideId: string | number;
  rater: string;
  ratedUser: string;
  userRole: string;
  overall: number;
  punctuality: number;
  driving: number;
  vehicle: number;
  behavior: number;
  review: string;
  createdAt: string;
  updatedAt?: string;
  rideFrom?: string;
  rideTo?: string;
  rideDate?: string;
  role?: string;
}

export interface Company {
  id: number;
  name: string;
  code: string;
  admin: string;
  employees: string[];
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  rideId: string | number;
  sender: string;
  receiver: string;
  message: string;
  timestamp: string;
  read: boolean;
}

export interface Feedback {
  id?: string;
  userId: string;
  userName: string;
  type: 'feedback' | 'issue';
  message: string;
  createdAt: string;
  status: 'pending' | 'resolved';
}

export interface RideRequest {
  id: string;
  passengerId: string;
  from: string;
  to: string;
  date: string;
  time: string;
  status: 'pending' | 'matched' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface LostReport {
  id?: string;
  userId: string;
  item: string;
  rideId: string;
  driverContact: string;
  status: 'Reported' | 'Contacting Driver' | 'Item Found' | 'Returned' | 'Resolved';
  createdAt: string;
  driverName?: string;
  comments?: string;
}
