import React from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Header } from './components/Header';
import { AuthSection } from './components/AuthSection';
import { SearchSection } from './components/SearchSection';
import { RideMatchingSection } from './components/RideMatchingSection';
import { OfferSection } from './components/OfferSection';
import { MyRidesSection } from './components/MyRidesSection';
import { ProfileSection } from './components/ProfileSection';
import { AdminSection } from './components/AdminSection';
import { EVAnalyticsSection } from './components/EVAnalyticsSection';
import { CorporateSection } from './components/CorporateSection';
import { SubscriptionSection } from './components/SubscriptionSection';
import { DriverVerificationSection } from './components/DriverVerificationSection';
import { FeedbackSection } from './components/FeedbackSection';
import { LostFoundSection } from './components/LostFoundSection';
import { TransportHub } from './components/TransportHub';
import { UPIPayment } from './components/UPIPayment';
import { ChatBot } from './components/ChatBot';
import { BookingForm } from './components/BookingForm';
import { SOSButton } from './components/SOSButton';
import { WalletSection } from './components/WalletSection';
import { LoadingSpinner } from './components/LoadingSpinner';
import { FraudService } from './services/fraudService';
import { NotificationService } from './services/notificationService';

import { ADMIN_USERNAME, TRANSLATIONS } from './constants';
import { User, Ride, Booking, Rating, ChatMessage } from './types';
import { auth, db, loginWithGoogle, logout as firebaseLogout, onAuthStateChanged, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc, collection, addDoc, query, where, onSnapshot, serverTimestamp, handleFirestoreError, OperationType, increment, onSnapshotsInSync } from './firebase';

export default function App() {
  const [currentUser, setCurrentUser] = React.useState<string | null>(null);
  const [isDbConnected, setIsDbConnected] = React.useState(true);
  const [isQuotaExceeded, setIsQuotaExceeded] = React.useState(false);

  // Listen for firestore quota exceeded events to display a helpful banner
  React.useEffect(() => {
    const handleQuotaExceeded = () => {
      setIsQuotaExceeded(true);
    };
    window.addEventListener('firestore-quota-exceeded', handleQuotaExceeded);
    return () => {
      window.removeEventListener('firestore-quota-exceeded', handleQuotaExceeded);
    };
  }, []);

  // Global connection health check
  React.useEffect(() => {
    // onSnapshotsInSync triggers when a batch of snapshots from the server is processed
    const unsub = onSnapshotsInSync(db, () => {
      setIsDbConnected(true);
    });

    // Check online status
    const handleOnline = () => setIsDbConnected(true);
    const handleOffline = () => setIsDbConnected(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      unsub();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  const [userProfile, setUserProfile] = React.useState<User | null>(null);
  const [activeSection, setActiveSection] = React.useState("authSection");
  const [language, setLanguage] = React.useState('en');
  const [notification, setNotification] = React.useState({ message: '', color: '#43a047', visible: false });
  const [loading, setLoading] = React.useState(true);
  const [rideBeingBooked, setRideBeingBooked] = React.useState<Ride | null>(null);
  const [bookingDetails, setBookingDetails] = React.useState<Partial<Booking> | null>(null);
  const [isCompletingBooking, setIsCompletingBooking] = React.useState(false);
  const [activeRidesForTracking, setActiveRidesForTracking] = React.useState<string[]>([]);
  const [initialPoolType, setInitialPoolType] = React.useState<'all' | 'car' | 'bike' | 'ev'>('all');

  // Simulation sync for drivers who are not in MyRidesSection but have active rides
  React.useEffect(() => {
    if (activeRidesForTracking.length > 0) {
      const activeRides = activeRidesForTracking.map(id => ({ id, bookings: [{ pickupStatus: 'on_the_way' }], fromCoords: { lat: 28.6139, lng: 77.2090 } } as any));
      // For global sync, we need full ride objects which we don't have here easily 
      // without fetching. But MyRidesSection handles it for the primary driver flow.
    }
  }, [activeRidesForTracking]);

  // Global ride departure reminder scheduler using the browser's Notification API
  React.useEffect(() => {
    if (!currentUser) return;

    const checkReminders = async () => {
      try {
        const stored = localStorage.getItem('ecopool_active_reminders');
        if (!stored) return;

        const reminders: any[] = JSON.parse(stored);
        let updated = false;
        const now = Date.now();

        for (const rem of reminders) {
          // Process active and non-notified reminders for current logged-in user
          if (rem.userId !== currentUser || rem.notified) continue;

          // Target time is exactly 1 hour before departure (or immediately if scheduled in less than an hour)
          if (now >= rem.targetTime) {
            // Check if it's too old (e.g. over 2 hours post-departure) to prevent stale popups
            const departureTimeStr = `${rem.date}T${rem.time}`;
            const departureMs = new Date(departureTimeStr).getTime();
            const twoHoursMs = 2 * 60 * 60 * 1000;

            if (now < departureMs + twoHoursMs) {
              const title = language === 'hi' ? 'यात्रा स्मरणपत्र (EcoPool)' : 'EcoPool Ride Reminder';
              const body = language === 'hi'
                ? `आपकी सवारी ${rem.from} से ${rem.to} तक 1 घंटे में शुरू हो रही है (${rem.time})!`
                : `Your booked ride from ${rem.from} to ${rem.to} departs in 1 hour (${rem.time})!`;

              NotificationService.sendNotification(title, {
                body,
                tag: `reminder_${rem.rideId}`,
                requireInteraction: true
              });
            }

            rem.notified = true;
            updated = true;
          }
        }

        if (updated) {
          localStorage.setItem('ecopool_active_reminders', JSON.stringify(reminders));
        }
      } catch (e) {
        console.error("Error processing reminders: ", e);
      }
    };

    // Check immediately and then every 15 seconds
    checkReminders();
    const interval = setInterval(checkReminders, 15000);
    return () => clearInterval(interval);
  }, [currentUser, language]);

  const isAdmin = userProfile?.role === 'admin' || userProfile?.email === 'samadabbasjafri67@gmail.com' || userProfile?.email === 'abbasjafri333@gmail.com';

  const showNotification = (msg: string, color = "#43a047") => {
    setNotification({ message: msg, color, visible: true });
    setTimeout(() => setNotification(prev => ({ ...prev, visible: false })), 2500);
  };

  React.useEffect(() => {
    let profileUnsubscribe: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      if (profileUnsubscribe) {
        profileUnsubscribe();
        profileUnsubscribe = null;
      }

      if (user) {
        setCurrentUser(user.uid);
        
        // Real-time user profile listener
        profileUnsubscribe = onSnapshot(doc(db, 'users', user.uid), async (userDoc) => {
          if (userDoc.exists()) {
            const profileData = userDoc.data() as User;
            setUserProfile(profileData);
            // Cache locally for offline/quota recovery
            try {
              localStorage.setItem(`ecopool_cached_profile_${user.uid}`, JSON.stringify(profileData));
            } catch (e) {
              console.warn("Could not write local profile cache", e);
            }
            setIsDbConnected(true);
            setLoading(false);
            if (activeSection === "authSection") {
              setActiveSection("searchSection");
            }
          } else {
            // Create user profile if it doesn't exist
            const newUser: User = {
              username: user.displayName || user.email?.split('@')[0] || 'User',
              email: user.email || '',
              role: (user.email === 'samadabbasjafri67@gmail.com' || user.email === 'abbasjafri333@gmail.com') ? 'admin' : 'user',
              registrationDate: new Date().toISOString(),
              totalRides: 0,
              carbonSaved: 0,
              points: 100,
              badges: ["New User"],
              subscription: { plan: 'free', expiry: null },
              isVerified: false,
              verificationStatus: 'none',
              walletBalance: 0,
              totalCashbackEarned: 0,
              referralCode: (user.displayName?.substring(0, 3) || 'ECO').toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase()
            };

            const storedReferral = localStorage.getItem('eco_referral');
            if (storedReferral) {
              newUser.referredBy = storedReferral;
              localStorage.removeItem('eco_referral');
            }

            try {
              await setDoc(doc(db, 'users', user.uid), newUser);
              // The snapshot listener above will pick up this new document
            } catch (error) {
              console.error("Profile creation error:", error);
              showNotification("Failed to initialize profile", "#e53935");
            }
          }
        }, (error) => {
          console.error("Profile listener error:", error);
          
          const isQuota = error.message.toLowerCase().includes('quota') || 
                          error.message.toLowerCase().includes('exceeded') || 
                          error.message.toLowerCase().includes('resource exhausted');
          if (isQuota) {
            setIsQuotaExceeded(true);
          }

          // Offline fallback recovery
          try {
            const cached = localStorage.getItem(`ecopool_cached_profile_${user.uid}`);
            if (cached) {
              const data = JSON.parse(cached);
              setUserProfile(data);
              setIsDbConnected(false);
              setLoading(false);
              if (activeSection === "authSection") {
                setActiveSection("searchSection");
              }
              showNotification(
                language === 'hi' 
                  ? "कोटा समाप्त! ऑफ़लाइन कैश डेटा के साथ चल रहा है।" 
                  : "Database quota exceeded! Running EcoPool using locally cached details.", 
                "#ff9800"
              );
              return;
            }
          } catch (cachedErr) {
            console.error("Cached profile recovery failed", cachedErr);
          }

          // If no cache exists, manufacture a realistic temporary user profile to prevent lock-out
          const tempUser: User = {
            username: user.displayName || user.email?.split('@')[0] || 'User',
            email: user.email || '',
            role: (user.email === 'samadabbasjafri67@gmail.com' || user.email === 'abbasjafri333@gmail.com') ? 'admin' : 'user',
            registrationDate: new Date().toISOString(),
            totalRides: 3,
            carbonSaved: 12.5,
            points: 150,
            badges: ["Offline Mode"],
            subscription: { plan: 'free', expiry: null },
            isVerified: true,
            verificationStatus: 'approved',
            walletBalance: 150,
            totalCashbackEarned: 20,
            referralCode: 'ECO-OFFLINE'
          };
          setUserProfile(tempUser);
          setIsDbConnected(false);
          setLoading(false);
          if (activeSection === "authSection") {
            setActiveSection("searchSection");
          }

          if (error.message.includes('unavailable')) {
            setIsDbConnected(false);
          } else {
            // Handle error gracefully, suppressed from crashing because it was already set up above
            try {
              handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
            } catch (err) {
              console.warn("Firestore error logged and caught cleanly");
            }
          }
        });
      } else {
        setCurrentUser(null);
        setUserProfile(null);
        setActiveSection("authSection");
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (profileUnsubscribe) profileUnsubscribe();
    };
  }, []);

  // Background Location Tracking for Drivers
  React.useEffect(() => {
    if (!currentUser) return;

    // Listen for active bookings where current user is the driver
    const q = query(
      collection(db, 'bookings'), 
      where('driverId', '==', currentUser),
      where('pickupStatus', 'in', ['on_the_way', 'arrived', 'started'])
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const rideIds = Array.from(new Set(snapshot.docs.map(doc => doc.data().rideId as string)));
      setActiveRidesForTracking(rideIds);
    });

    return () => unsubscribe();
  }, [currentUser]);

  React.useEffect(() => {
    if (!currentUser || activeRidesForTracking.length === 0) return;

    const lastUpdateRef = { time: 0, lat: 0, lng: 0 };

    const watchId = navigator.geolocation.watchPosition(
      async (position) => {
        const { latitude: lat, longitude: lng } = position.coords;
        const now = Date.now();

        // Throttle updates: 10s or 20m
        const timeDiff = now - lastUpdateRef.time;
        const distMoved = lastUpdateRef.lat !== 0 ? 
          Math.sqrt(Math.pow(lat - lastUpdateRef.lat, 2) + Math.pow(lng - lastUpdateRef.lng, 2)) * 111320 : // Approx meters
          100;

        if (timeDiff > 10000 || distMoved > 20) {
          const newLoc = {
            lat,
            lng,
            timestamp: new Date().toISOString()
          };

          try {
            const updatePromises = activeRidesForTracking.map(rideId => 
              updateDoc(doc(db, 'rides', rideId), { currentLocation: newLoc })
            );
            await Promise.all(updatePromises);
            lastUpdateRef.time = now;
            lastUpdateRef.lat = lat;
            lastUpdateRef.lng = lng;
          } catch (error) {
            console.error("Background location update failed:", error);
          }
        }
      },
      (error) => console.error("Background Geolocation error:", error),
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [currentUser, activeRidesForTracking]);

  const login = async () => {
    try {
      await loginWithGoogle();
      showNotification("Logged in successfully!");
    } catch (error) {
      showNotification("Login failed!", "#e53935");
    }
    return true;
  };

  const logout = async () => {
    try {
      await firebaseLogout();
      showNotification("Logged out successfully!");
    } catch (error) {
      showNotification("Logout failed!", "#e53935");
    }
  };

  const updateUserProfile = async (updatedData: any) => {
    if (!currentUser) return false;
    try {
      await updateDoc(doc(db, 'users', currentUser), updatedData);
      setUserProfile(prev => prev ? { ...prev, ...updatedData } : null);
      showNotification("Profile updated successfully!");
      return true;
    } catch (error) {
      showNotification("Update failed!", "#e53935");
      return false;
    }
  };

  const submitUserVerification = async (docs: any[]) => {
    if (!currentUser) return false;
    const update = {
      verificationStatus: 'pending',
      verificationDocuments: docs,
      verificationSubmittedAt: new Date().toISOString()
    };
    try {
      await updateDoc(doc(db, 'users', currentUser), update);
      setUserProfile(prev => prev ? { ...prev, ...update } : null);
      showNotification("Verification submitted! Pending approval.", "#ff9800");
      return true;
    } catch (error) {
      showNotification("Submission failed!", "#e53935");
      return false;
    }
  };

  const approveUserVerification = async (uid: string) => {
    const update = {
      isVerified: true,
      verificationStatus: 'approved',
      reviewedAt: new Date().toISOString()
    };
    try {
      await updateDoc(doc(db, 'users', uid), update);
      showNotification(`User verified!`);
      return true;
    } catch (error) {
      showNotification("Approval failed!", "#e53935");
      return false;
    }
  };

  const rejectUserVerification = async (uid: string) => {
    const update = {
      isVerified: false,
      verificationStatus: 'rejected',
      reviewedAt: new Date().toISOString()
    };
    try {
      await updateDoc(doc(db, 'users', uid), update);
      showNotification(`User verification rejected.`);
      return true;
    } catch (error) {
      showNotification("Rejection failed!", "#e53935");
      return false;
    }
  };

  const removeUser = async (uid: string) => {
    try {
      // 1. Delete user document
      await deleteDoc(doc(db, 'users', uid));
      
      // 2. Delete rides offered by this user
      const ridesQ = query(collection(db, 'rides'), where('driver', '==', uid));
      const ridesSnapshot = await getDocs(ridesQ);
      const deleteRidesPromises = ridesSnapshot.docs.map(d => deleteDoc(doc(db, 'rides', d.id)));
      await Promise.all(deleteRidesPromises);

      showNotification("User and their rides removed successfully!");
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `users/${uid}`);
      showNotification("Failed to remove user!", "#e53935");
      return false;
    }
  };

  const generateOTP = async (bookingId: string, rideId: string | number, passenger: string, driver: string) => {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    // In a real app, we'd store this in a secure collection
    // For now, we'll just return it or store it in the booking
    await updateDoc(doc(db, 'bookings', bookingId), { otp, otpExpiry: new Date(Date.now() + 15 * 60 * 1000).toISOString() });
    return otp;
  };

  const verifyOTP = async (bookingId: string, enteredOTP: string) => {
    const bookingDoc = await getDoc(doc(db, 'bookings', bookingId));
    if (!bookingDoc.exists()) return { success: false, message: "No booking found" };
    const data = bookingDoc.data();
    if (new Date() > new Date(data.otpExpiry)) return { success: false, message: "OTP expired" };
    if (data.otp === enteredOTP) {
      await updateDoc(doc(db, 'bookings', bookingId), { pickupStatus: 'verified', pickupVerifiedAt: new Date().toISOString() });
      return { success: true, message: "OTP verified!" };
    }
    return { success: false, message: "Invalid OTP" };
  };

  const submitRating = async (data: any) => {
    try {
      await addDoc(collection(db, 'ratings'), {
        ...data,
        rater: currentUser,
        createdAt: new Date().toISOString()
      });
      showNotification("Rating submitted!");
      return true;
    } catch (error) {
      showNotification("Rating failed!", "#e53935");
      return false;
    }
  };

  const getChatMessages = (rideId: string | number, u1: string, u2: string, callback: (msgs: ChatMessage[]) => void) => {
    if (!currentUser) return () => {};
    const q = query(
      collection(db, 'chats'), 
      where('rideId', '==', rideId),
      where('participants', 'array-contains', currentUser)
    );
    return onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as ChatMessage))
        .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      callback(msgs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'chats');
    });
  };

  const sendChatMessage = async (rideId: string | number, sender: string, receiver: string, message: string) => {
    try {
      await addDoc(collection(db, 'chats'), {
        rideId, sender, receiver, message,
        participants: [sender, receiver],
        timestamp: new Date().toISOString(),
        read: false
      });
      return true;
    } catch (error) {
      return false;
    }
  };

  const startBooking = async (ride: Ride) => {
    if (!currentUser) return;
    setRideBeingBooked(ride);
    setActiveSection("bookingFormSection");
  };

  const confirmBookingDetails = (details: Partial<Booking>) => {
    setBookingDetails(details);
    setActiveSection("paymentSection");
  };

  const completeBooking = async (paymentId: string) => {
    if (!currentUser || !rideBeingBooked || !bookingDetails) return;

    // Check for blocked status
    if (userProfile?.trustLevel === 'blocked') {
      showNotification(language === 'hi' ? 'जालसाजी की जांच के कारण आपका खाता ब्लॉक कर दिया गया है' : 'Your account has been blocked due to fraud checks', '#e53935');
      return;
    }

    // Check for spam
    const isSpam = await FraudService.checkBookingSpam(currentUser);
    if (isSpam) {
      showNotification(language === 'hi' ? 'बहुत तेज़ बुकिंग! कृपया रुकें।' : 'Too many bookings! Please slow down.', '#e53935');
      return;
    }

    setIsCompletingBooking(true);
    try {
      const bookingData = {
        ...bookingDetails,
        rideId: rideBeingBooked.id,
        ride: rideBeingBooked,
        passenger: currentUser,
        passengerName: userProfile?.username || 'User',
        passengerPhoto: userProfile?.profilePhoto || null,
        passengerVerified: userProfile?.isVerified || false,
        driverId: rideBeingBooked.driver,
        seats: bookingDetails.seats || 1,
        pickupLocation: bookingDetails.pickupLocation || rideBeingBooked.from,
        dropLocation: bookingDetails.dropLocation || rideBeingBooked.to,
        specialRequests: bookingDetails.specialRequests || "",
        totalPrice: bookingDetails.totalPrice || rideBeingBooked.price,
        status: 'confirmed',
        pickupStatus: 'scheduled',
        bookedAt: new Date().toISOString(),
        paymentId: paymentId
      };
      const createdBookingRef = await addDoc(collection(db, 'bookings'), bookingData);
      const bookingWithId = { ...bookingData, id: createdBookingRef.id };

      // Dispatch Brevo email notifications to Passenger & Driver in background
      try {
        const driverEmail = rideBeingBooked.driverEmail || null;
        let driverName = rideBeingBooked.driverName || 'Rider';
        let driverPhone = rideBeingBooked.driverPhone || null;

        const sendEmailPromise = async () => {
          let resolvedDriverEmail = driverEmail;
          let resolvedDriverName = driverName;
          let resolvedDriverPhone = driverPhone;

          if (!resolvedDriverEmail) {
            try {
              const driverSnap = await getDoc(doc(db, 'users', rideBeingBooked.driver));
              if (driverSnap.exists()) {
                const dData = driverSnap.data();
                resolvedDriverEmail = dData.email || null;
                resolvedDriverName = dData.username || 'Rider';
                resolvedDriverPhone = dData.phone || null;
              }
            } catch (err) {
              console.error("Failed to query driver data for email dispatch:", err);
            }
          }

          const resolvedPassengerEmail = userProfile?.email || null;
          const resolvedPassengerName = userProfile?.username || 'Customer';

          if (resolvedPassengerEmail || resolvedDriverEmail) {
            const prunedBooking = {
              id: bookingWithId.id,
              type: bookingWithId.type,
              pickupLocation: bookingWithId.pickupLocation,
              dropLocation: bookingWithId.dropLocation,
              totalPrice: bookingWithId.totalPrice,
              seats: bookingWithId.seats,
              selectedSeatLabels: bookingWithId.selectedSeatLabels,
              specialRequests: bookingWithId.specialRequests,
              parcelInfo: bookingWithId.parcelInfo,
              ride: {
                from: rideBeingBooked.from,
                to: rideBeingBooked.to,
                date: rideBeingBooked.date,
                time: rideBeingBooked.time,
                price: rideBeingBooked.price,
                carName: rideBeingBooked.carName,
                vehicleNumber: rideBeingBooked.vehicleNumber
              }
            };

            const payload = {
              type: "confirmed",
              booking: prunedBooking,
              passenger: {
                name: resolvedPassengerName,
                email: resolvedPassengerEmail
              },
              driver: {
                name: resolvedDriverName,
                email: resolvedDriverEmail,
                phone: resolvedDriverPhone
              }
            };

            await fetch("/api/send-booking-notification", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(payload)
            });
          }
        };

        sendEmailPromise().catch(err => console.error("Error in sending Brevo background email task:", err));
      } catch (backgroundErr) {
        console.error("Error launching Brevo email background promise:", backgroundErr);
      }
      
      await updateDoc(doc(db, 'rides', rideBeingBooked.id as string), {
        seats: (rideBeingBooked.seats || 0) - (bookingDetails.seats || 1)
      });

      // --- Wallet & Cashback Logic ---
      const amountPaid = bookingDetails.totalPrice || rideBeingBooked.price;
      const cashbackAmount = Math.round(amountPaid * 0.05); // 5% cashback

      if (cashbackAmount > 0) {
        // 1. Update user wallet and cashback stats
        await updateDoc(doc(db, 'users', currentUser), {
          walletBalance: increment(cashbackAmount),
          totalCashbackEarned: increment(cashbackAmount)
        });

        // 2. Log Transaction
        await addDoc(collection(db, 'transactions'), {
          userId: currentUser,
          amount: cashbackAmount,
          type: 'credit',
          reason: 'cashback_ride',
          createdAt: new Date().toISOString()
        });

        showNotification(`${language === 'hi' ? 'कैशबैक मिला' : 'Cashback earned'}: ₹${cashbackAmount}`, '#10b981');
      }

      // --- Referral Reward Logic (First Ride Only) ---
      if (userProfile?.referredBy && userProfile.totalRides === 0) {
        const rewardAmount = 50;
        const referrerId = userProfile.referredBy; // Assumes referredBy is the UID for simplicity in this demo

        // Find referrer by their ID (actually referredBy should probably store their referral code or UID)
        // If it's UID:
        try {
          const referrerDoc = await getDoc(doc(db, 'users', referrerId));
          if (referrerDoc.exists()) {
             // Credit Referrer
             await updateDoc(doc(db, 'users', referrerId), {
               walletBalance: increment(rewardAmount)
             });
             await addDoc(collection(db, 'transactions'), {
               userId: referrerId,
               amount: rewardAmount,
               type: 'credit',
               reason: 'cashback_referral',
               createdAt: new Date().toISOString()
             });

             // Credit referred user too
             await updateDoc(doc(db, 'users', currentUser), {
               walletBalance: increment(rewardAmount)
             });
             await addDoc(collection(db, 'transactions'), {
               userId: currentUser,
               amount: rewardAmount,
               type: 'credit',
               reason: 'cashback_referral',
               createdAt: new Date().toISOString()
             });
             showNotification(language === 'hi' ? 'रेफरल बोनस मिला' : 'Referral bonus applied!', '#10b981');
          }
        } catch (e) {
          console.error("Referral bonus adjustment failed", e);
        }
      }

      await updateDoc(doc(db, 'users', currentUser), {
        totalRides: increment(1),
        totalBookings: increment(1)
      });
      // --- End Wallet Logic ---

      showNotification(TRANSLATIONS[language].paymentSuccess);
      setRideBeingBooked(null);
      setBookingDetails(null);
      setActiveSection("myRidesSection");
    } catch (error) {
      showNotification(TRANSLATIONS[language].paymentFailed, "#e53935");
    } finally {
      setIsCompletingBooking(false);
    }
  };

  if (loading) {
    return <LoadingSpinner fullScreen label={language === 'hi' ? 'लोड हो रहा है...' : 'Loading EcoPool...'} />;
  }

  return (
    <div className="min-h-screen flex flex-col">
      <AnimatePresence>
        {isQuotaExceeded && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-red-600 text-white py-3 px-4 font-semibold text-xs md:text-sm flex flex-col md:flex-row items-center justify-between gap-3 overflow-hidden shadow-md border-b border-red-700"
          >
            <div className="flex items-center gap-2">
              <span className="text-base">⚠️</span>
              <div>
                <strong>
                  {language === 'hi' 
                    ? 'फायरस्टोर दैनिक कोटा सीमा समाप्त हो गई है!' 
                    : 'Firestore Daily Quota Limit Exceeded!'}
                </strong>
                <p className="text-[11px] opacity-90 mt-0.5 leading-relaxed font-normal">
                  {language === 'hi'
                    ? 'आपके डेटाबेस (Spark Plan) की सीमा पूरी हो चुकी है। अपग्रेड डायलॉग खोलने या डेटाबेस प्रबंधित करने के लिए नीचे दिए गए बटन पर क्लिक करें।'
                    : "The free daily read unit limit for this Firestore database ('Free daily read units per project') has been reached. Quota will reset tomorrow."}
                </p>
              </div>
            </div>
            <a 
              href="https://console.firebase.google.com/project/gen-lang-client-0011886582/firestore/databases/ai-studio-e451c540-5235-4c12-b4ab-e38db22d117f/data?openUpgradeDialog=true"
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-white text-red-700 hover:bg-red-50 text-xs px-3 py-1.5 rounded-lg font-bold transition-all shrink-0 uppercase tracking-wide shadow-sm text-center"
            >
              {language === 'hi' ? 'डेटाबेस अपग्रेड/समीक्षा करें' : 'Review / Upgrade Database'}
            </a>
          </motion.div>
        )}
        {!isDbConnected && !isQuotaExceeded && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-amber-500 text-white text-[10px] py-1 px-4 font-black flex items-center justify-center gap-2 overflow-hidden"
          >
            <span className="animate-pulse">●</span>
            {language === 'hi' ? 'कनेक्शन धीमा है या उपलब्ध नहीं है - आप ऑफ़लाइन जा सकते हैं' : 'Connection is slow or unavailable - Working offline'}
          </motion.div>
        )}
      </AnimatePresence>
      <Header 
        currentUser={currentUser} 
        onLogout={logout} 
        onShowSection={setActiveSection} 
        language={language} 
        isAdmin={isAdmin}
        activeSection={activeSection}
      />

      <AnimatePresence mode="wait">
        {notification.visible && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            id="notification" 
            style={{ backgroundColor: notification.color }}
          >
            {notification.message}
          </motion.div>
        )}
      </AnimatePresence>

      <main className="flex-grow">
        <div className="container">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {activeSection === "authSection" && (
                <AuthSection onLogin={login} language={language} />
              )}
              {currentUser && (
                <>
                  {activeSection === "searchSection" && (
                    <SearchSection 
                      currentUser={currentUser} 
                      showNotification={showNotification} 
                      onStartBooking={startBooking} 
                      language={language} 
                      onNavigateToSection={(target) => setActiveSection(target)}
                      initialPoolType={initialPoolType}
                      clearInitialPoolType={() => setInitialPoolType('all')}
                    />
                  )}
                  {activeSection === "transportHubSection" && (
                    <TransportHub 
                      language={language}
                      onNavigateToSection={(target) => setActiveSection(target)}
                      onSelectPoolTypePreset={(type) => setInitialPoolType(type)}
                    />
                  )}
                  {activeSection === "rideMatchingSection" && (
                    <RideMatchingSection 
                      currentUser={currentUser} 
                      showNotification={showNotification} 
                      onStartBooking={startBooking} 
                      language={language} 
                    />
                  )}
                  {activeSection === "offerSection" && userProfile && (
                    <OfferSection 
                      currentUser={currentUser} 
                      user={userProfile}
                      showNotification={showNotification} 
                      language={language} 
                    />
                  )}
                  {activeSection === "myRidesSection" && (
                    <MyRidesSection 
                      currentUser={currentUser}
                      showNotification={showNotification}
                      generateOTP={generateOTP}
                      verifyOTP={verifyOTP}
                      submitRating={submitRating}
                      getDriverRatingSummary={(u) => ({overall:0})} // Will be updated in component
                      getRideRatings={(id) => []} // Will be updated in component
                      canUserRateRide={(id, role, other) => ({canRate: true})} // Simplified
                      sendChatMessage={sendChatMessage}
                      getChatMessages={getChatMessages}
                      language={language}
                    />
                  )}
                  {activeSection === "profileSection" && userProfile && (
                    <ProfileSection 
                      currentUser={currentUser} 
                      user={userProfile}
                      showNotification={showNotification} 
                      updateUserProfile={updateUserProfile} 
                      submitUserVerification={submitUserVerification} 
                      language={language} 
                    />
                  )}
                  {activeSection === "adminSection" && isAdmin && (
                    <AdminSection 
                      currentUser={currentUser!} 
                      showNotification={showNotification} 
                      approveUserVerification={approveUserVerification} 
                      rejectUserVerification={rejectUserVerification}
                      removeUser={removeUser}
                      language={language} 
                    />
                  )}
                  {activeSection === "evAnalyticsSection" && (
                    <EVAnalyticsSection 
                      currentUser={currentUser} 
                      showNotification={showNotification} 
                      language={language} 
                    />
                  )}
                  {activeSection === "corporateSection" && (
                    <CorporateSection 
                      currentUser={currentUser} 
                      showNotification={showNotification} 
                      language={language} 
                    />
                  )}
                  {activeSection === "subscriptionSection" && userProfile && (
                    <SubscriptionSection 
                      currentUser={currentUser} 
                      user={userProfile}
                      showNotification={showNotification} 
                      updateUserProfile={updateUserProfile} 
                      language={language} 
                    />
                  )}
                  {activeSection === "walletSection" && (
                    <WalletSection 
                      currentUser={currentUser} 
                      language={language} 
                      showNotification={showNotification}
                    />
                  )}
                  {activeSection === "driverVerificationSection" && userProfile && (
                    <DriverVerificationSection 
                      currentUser={currentUser!} 
                      user={userProfile}
                      showNotification={showNotification} 
                      submitUserVerification={submitUserVerification}
                      language={language} 
                    />
                  )}
                  {activeSection === "feedbackSection" && (
                    <FeedbackSection 
                      currentUser={currentUser} 
                      userName={userProfile?.username || 'User'}
                      showNotification={showNotification} 
                      language={language} 
                    />
                  )}
                  {activeSection === "lostFoundSection" && (
                    <LostFoundSection 
                      currentUser={currentUser} 
                      showNotification={showNotification}
                      language={language}
                    />
                  )}
                  {activeSection === "bookingFormSection" && rideBeingBooked && (
                    <div className="py-8">
                      <BookingForm 
                        ride={rideBeingBooked} 
                        language={language}
                        onConfirm={confirmBookingDetails}
                        onCancel={() => {
                          setRideBeingBooked(null);
                          setActiveSection("searchSection");
                        }}
                      />
                    </div>
                  )}
                  {activeSection === "paymentSection" && rideBeingBooked && bookingDetails && (
                    <div className="py-8">
                      {isCompletingBooking && (
                        <LoadingSpinner fullScreen label={language === 'hi' ? 'बुकिंग पूरी की जा रही है...' : 'Completing your booking...'} />
                      )}
                      <UPIPayment 
                        amount={bookingDetails.totalPrice || rideBeingBooked.price} 
                        language={language}
                        onSuccess={completeBooking}
                        showNotification={showNotification}
                        onCancel={() => {
                          setActiveSection("bookingFormSection");
                        }}
                      />
                    </div>
                  )}
                </>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {currentUser && <ChatBot language={language} />}
      {currentUser && <SOSButton language={language} showNotification={showNotification} />}

      <div className="fixed top-4 left-4 z-[1001]">
        <button 
          onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
          className="bg-white/80 backdrop-blur px-3 py-1 rounded-full border border-slate-200 shadow-sm text-xs font-bold hover:bg-white transition-colors"
        >
          {language === 'en' ? '🇮🇳 HI' : '🇺🇸 EN'}
        </button>
      </div>
    </div>
  );
}
