import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { 
  initializeFirestore, 
  collection as nativeCollection, 
  doc as nativeDoc, 
  getDoc as nativeGetDoc, 
  getDocs as nativeGetDocs, 
  setDoc as nativeSetDoc, 
  updateDoc as nativeUpdateDoc, 
  deleteDoc as nativeDeleteDoc, 
  query as nativeQuery, 
  where as nativeWhere, 
  onSnapshot as nativeOnSnapshot, 
  addDoc as nativeAddDoc, 
  increment as nativeIncrement,
  orderBy as nativeOrderBy,
  limit as nativeLimit,
  arrayUnion as nativeArrayUnion,
  arrayRemove as nativeArrayRemove,
  writeBatch as nativeWriteBatch,
  serverTimestamp, 
  Timestamp, 
  getDocFromServer, 
  onSnapshotsInSync 
} from 'firebase/firestore';

// Import the Firebase configuration
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase SDK
const app = initializeApp(firebaseConfig);

// Clear transient quota state on load so refreshing attempts online connection
if (typeof window !== 'undefined') {
  localStorage.removeItem('firestore_quota_exceeded');
}

// Initialize Firestore with settings to handle potential network restrictions
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
  ignoreUndefinedProperties: true,
}, firebaseConfig.firestoreDatabaseId);

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Auth helpers
export const loginWithGoogle = () => signInWithPopup(auth, googleProvider);
export const logout = () => signOut(auth);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

// Global detection helper
function isQuotaError(error: unknown): boolean {
  if (!error) return false;
  const errMsg = error instanceof Error ? error.message : String(error);
  const serialized = JSON.stringify(errMsg).toLowerCase();
  return serialized.includes('quota') || serialized.includes('exceeded') || serialized.includes('resource exhausted') || serialized.includes('limit');
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMsg = error instanceof Error ? error.message : String(error);
  const errInfo: FirestoreErrorInfo = {
    error: errMsg,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  };

  const isQuota = isQuotaError(error);

  if (typeof window !== 'undefined' && isQuota) {
    localStorage.setItem('firestore_quota_exceeded', 'true');
    window.dispatchEvent(new CustomEvent('firestore-quota-exceeded', { detail: errInfo }));
  }

  console.error('Firestore Error: ', JSON.stringify(errInfo));

  if (isQuota) {
    console.warn('EcoPool Firestore Quota Limit Exceeded. App will run in local cached offline mode.');
    return;
  }

  throw new Error(JSON.stringify(errInfo));
}

// --- LOCAL STORAGE FALLBACK SIMULATION DATABASE MODEL ---

function getSeededData(colName: string): any[] {
  const nowStr = new Date().toISOString();
  const formatToday = nowStr.split('T')[0];
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const formatTomorrow = tomorrow.toISOString().split('T')[0];

  if (colName === 'users') {
    return [
      {
        uid: 'driver_sharma',
        id: 'driver_sharma',
        username: 'Rohan Sharma',
        role: 'driver',
        phone: '+91-98765-43210',
        email: 'rohan.sharma@gmail.com',
        isVerified: true,
        rating: 4.8,
        totalRides: 24,
        vehicleDetails: { carName: 'Honda City', carType: 'sedan', vehicleNumber: 'DL-3C-AS-1234' },
        walletBalance: 12500,
        registrationDate: nowStr,
        carbonSaved: 54,
        points: 420,
        badges: ["Top Rated", "Punctual"]
      },
      {
        uid: 'driver_reema',
        id: 'driver_reema',
        username: 'Reema Sen',
        role: 'driver',
        phone: '+91-95555-12345',
        email: 'reema.sen@gmail.com',
        isVerified: true,
        rating: 4.9,
        totalRides: 42,
        isEV: true,
        vehicleDetails: { carName: 'Tata Nexon EV', carType: 'suv', vehicleNumber: 'UP-16-EV-9988' },
        walletBalance: 32000,
        registrationDate: nowStr,
        carbonSaved: 112,
        points: 890,
        badges: ["Eco Driver", "Verified Plus"]
      },
      {
        uid: 'driver_kapoor',
        id: 'driver_kapoor',
        username: 'Aditya Kapoor',
        role: 'driver',
        phone: '+91-90001-90002',
        email: 'aditya.k@gmail.com',
        isVerified: true,
        rating: 4.7,
        totalRides: 15,
        isEV: true,
        vehicleDetails: { carName: 'Ather 450X', vehicleNumber: 'UP-16-BA-5555' },
        walletBalance: 4500,
        registrationDate: nowStr,
        carbonSaved: 32,
        points: 210,
        badges: ["Two Wheeler Pro"]
      },
      {
        uid: 'driver_priya',
        id: 'driver_priya',
        username: 'Priya Verma',
        role: 'driver',
        phone: '+91-92345-67890',
        email: 'priya.v@gmail.com',
        isVerified: true,
        rating: 5.0,
        totalRides: 8,
        isEV: true,
        vehicleDetails: { carName: 'MG ZS EV', carType: 'suv', vehicleNumber: 'DL-1C-EV-0007' },
        walletBalance: 9800,
        registrationDate: nowStr,
        carbonSaved: 22,
        points: 130,
        badges: ["Smooth Ride", "Safety First"]
      }
    ];
  }

  if (colName === 'rides') {
    return [
      {
        id: 'ride_seed_1',
        driver: 'driver_sharma',
        driverName: 'Rohan Sharma',
        driverVerified: true,
        driverPhone: '+91-98765-43210',
        driverEmail: 'rohan.sharma@gmail.com',
        from: 'Delhi University, North Campus',
        to: 'Connaught Place, New Delhi',
        date: formatToday,
        time: '14:30',
        price: 120,
        seats: 4,
        bookings: [],
        type: 'ride',
        vehiclePoolType: 'car',
        carName: 'Honda City',
        carType: 'sedan',
        vehicleNumber: 'DL-3C-AS-1234',
        isEV: false,
        averageRating: 4.8,
        ratingCount: 24,
        createdAt: nowStr
      },
      {
        id: 'ride_seed_2',
        driver: 'driver_reema',
        driverName: 'Reema Sen',
        driverVerified: true,
        driverPhone: '+91-95555-12345',
        driverEmail: 'reema.sen@gmail.com',
        from: 'Indirapuram, Ghaziabad',
        to: 'Cyber City, Gurugram',
        date: formatToday,
        time: '08:30',
        price: 280,
        seats: 3,
        bookings: [],
        type: 'ride',
        vehiclePoolType: 'ev',
        carName: 'Tata Nexon EV',
        carType: 'suv',
        vehicleNumber: 'UP-16-EV-9988',
        isEV: true,
        averageRating: 4.9,
        ratingCount: 42,
        createdAt: nowStr
      },
      {
        id: 'ride_seed_3',
        driver: 'driver_kapoor',
        driverName: 'Aditya Kapoor',
        driverVerified: true,
        driverPhone: '+91-90001-90002',
        driverEmail: 'aditya.k@gmail.com',
        from: 'Noida Sector 62',
        to: 'Connaught Place, New Delhi',
        date: formatTomorrow,
        time: '10:00',
        price: 150,
        seats: 2,
        bookings: [],
        type: 'ride',
        vehiclePoolType: 'bike',
        carName: 'Ather 450X',
        carType: 'other',
        vehicleNumber: 'UP-16-BA-5555',
        isEV: true,
        averageRating: 4.7,
        ratingCount: 15,
        helmetAvailable: true,
        createdAt: nowStr
      },
      {
        id: 'ride_seed_4',
        driver: 'driver_priya',
        driverName: 'Priya Verma',
        driverVerified: true,
        driverPhone: '+91-92345-67890',
        driverEmail: 'priya.v@gmail.com',
        from: 'Dwarka Sector 21',
        to: 'Okhla Phase 3',
        date: formatTomorrow,
        time: '09:15',
        price: 200,
        seats: 3,
        bookings: [],
        type: 'ride',
        vehiclePoolType: 'ev',
        carName: 'MG ZS EV',
        carType: 'suv',
        vehicleNumber: 'DL-1C-EV-0007',
        isEV: true,
        averageRating: 5.0,
        ratingCount: 8,
        createdAt: nowStr
      }
    ];
  }

  if (colName === 'ratings') {
    return [
      {
        id: 'rating_1',
        rideId: 'ride_seed_1',
        rater: 'user_rahul',
        ratedUser: 'driver_sharma',
        userRole: 'driver',
        overall: 5,
        punctuality: 5,
        driving: 5,
        vehicle: 5,
        behavior: 5,
        review: 'Excellent ride! Rohan was perfectly on time and drove very safely.',
        createdAt: nowStr
      },
      {
        id: 'rating_2',
        rideId: 'ride_seed_2',
        rater: 'user_deepika',
        ratedUser: 'driver_reema',
        userRole: 'driver',
        overall: 5,
        punctuality: 5,
        driving: 4,
        vehicle: 5,
        behavior: 5,
        review: 'Super clean EV, very silent ride. Reema is highly professional.',
        createdAt: nowStr
      }
    ];
  }

  return [];
}

function getLocalCollection(collectionName: string): any[] {
  const data = localStorage.getItem(`ecopool_db_${collectionName}`);
  if (!data) {
    const defaultData = getSeededData(collectionName);
    localStorage.setItem(`ecopool_db_${collectionName}`, JSON.stringify(defaultData));
    return defaultData;
  }
  try {
    return JSON.parse(data);
  } catch (err) {
    const defaultData = getSeededData(collectionName);
    localStorage.setItem(`ecopool_db_${collectionName}`, JSON.stringify(defaultData));
    return defaultData;
  }
}

function saveLocalCollection(collectionName: string, items: any[]) {
  localStorage.setItem(`ecopool_db_${collectionName}`, JSON.stringify(items));
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('local-db-update', { detail: { collection: collectionName } }));
  }
}

function applyQueryConstraints(items: any[], q: any): any[] {
  let filtered = [...items];
  if (!q || !q._queryConstraints) return filtered;

  for (const constraint of q._queryConstraints) {
    if (constraint._customConstraint) {
      const { type, fieldPath, opStr, value } = constraint._customConstraint;
      if (type === 'where') {
        filtered = filtered.filter(item => {
          const itemVal = item[fieldPath];
          if (opStr === '==') return itemVal === value;
          if (opStr === '!=') return itemVal !== value;
          if (opStr === '>') return itemVal > value;
          if (opStr === '>=') return itemVal >= value;
          if (opStr === '<') return itemVal < value;
          if (opStr === '<=') return itemVal <= value;
          if (opStr === 'array-contains') return Array.isArray(itemVal) && itemVal.includes(value);
          if (opStr === 'in') return Array.isArray(value) && value.includes(itemVal);
          return true;
        });
      }
    }
  }

  for (const constraint of q._queryConstraints) {
    if (constraint._customConstraint) {
      const { type, fieldPath, directionStr } = constraint._customConstraint;
      if (type === 'orderBy') {
        filtered.sort((a, b) => {
          const valA = a[fieldPath];
          const valB = b[fieldPath];
          if (valA < valB) return directionStr === 'asc' ? -1 : 1;
          if (valA > valB) return directionStr === 'asc' ? 1 : -1;
          return 0;
        });
      }
    }
  }

  for (const constraint of q._queryConstraints) {
    if (constraint._customConstraint) {
      const { type, limitNum } = constraint._customConstraint;
      if (type === 'limit') {
        filtered = filtered.slice(0, limitNum);
      }
    }
  }

  return filtered;
}

// --- MOCK SNAPSHOT REPRESENTATIONS ---

export class MockDocumentSnapshot {
  id: string;
  _data: any;
  ref: any;
  constructor(id: string, data: any, ref: any) {
    this.id = id;
    this._data = data;
    this.ref = ref;
  }
  exists() {
    return this._data !== undefined && this._data !== null;
  }
  data() {
    return this._data ? { ...this._data, id: this.id, uid: this.id } : undefined;
  }
}

export class MockQuerySnapshot {
  docs: MockDocumentSnapshot[];
  empty: boolean;
  size: number;
  constructor(docs: MockDocumentSnapshot[]) {
    this.docs = docs;
    this.empty = docs.length === 0;
    this.size = docs.length;
  }
  forEach(callback: (doc: MockDocumentSnapshot) => void) {
    this.docs.forEach(callback);
  }
  docChanges() {
    return [];
  }
}

// --- WRAPPED FIREBASE INTERFACES ---

export function collection(db: any, path: string) {
  try {
    const ref = nativeCollection(db, path);
    (ref as any)._customPath = path;
    (ref as any)._isCollection = true;
    return ref;
  } catch (error) {
    return {
      _customPath: path,
      _isCollection: true,
      path
    } as any;
  }
}

export function query(queryRef: any, ...queryConstraints: any[]) {
  try {
    const q = nativeQuery(queryRef, ...queryConstraints);
    (q as any)._customPath = queryRef._customPath || queryRef.path;
    (q as any)._queryConstraints = queryConstraints;
    return q;
  } catch (error) {
    return {
      _customPath: queryRef._customPath || queryRef.path,
      _queryConstraints: queryConstraints
    } as any;
  }
}

export function where(fieldPath: string, opStr: string, value: any) {
  try {
    const constraint = nativeWhere(fieldPath, opStr as any, value);
    (constraint as any)._customConstraint = { type: 'where', fieldPath, opStr, value };
    return constraint;
  } catch (error) {
    return {
      _customConstraint: { type: 'where', fieldPath, opStr, value }
    } as any;
  }
}

export function orderBy(fieldPath: string, directionStr?: 'asc' | 'desc') {
  try {
    const constraint = nativeOrderBy(fieldPath, directionStr);
    (constraint as any)._customConstraint = { type: 'orderBy', fieldPath, directionStr: directionStr || 'asc' };
    return constraint;
  } catch (error) {
    return {
      _customConstraint: { type: 'orderBy', fieldPath, directionStr: directionStr || 'asc' }
    } as any;
  }
}

export function limit(limitNum: number) {
  try {
    const constraint = nativeLimit(limitNum);
    (constraint as any)._customConstraint = { type: 'limit', limitNum };
    return constraint;
  } catch (error) {
    return {
      _customConstraint: { type: 'limit', limitNum }
    } as any;
  }
}

export function doc(db: any, collectionPath: string, ...pathSegments: string[]) {
  const docId = pathSegments.join('/');
  try {
    if (localStorage.getItem('firestore_quota_exceeded') === 'true') {
      return {
        _isDocRef: true,
        collectionPath,
        id: docId,
        path: `${collectionPath}/${docId}`
      } as any;
    }
    const ref = nativeDoc(db, collectionPath, ...pathSegments);
    (ref as any)._customCollectionPath = collectionPath;
    (ref as any)._customId = docId;
    return ref;
  } catch (error) {
    localStorage.setItem('firestore_quota_exceeded', 'true');
    return {
      _isDocRef: true,
      collectionPath,
      id: docId,
      path: `${collectionPath}/${docId}`
    } as any;
  }
}

export async function getDoc(docRef: any) {
  const isLocal = localStorage.getItem('firestore_quota_exceeded') === 'true' || docRef._isMockRef || !docRef.firestore;
  const colPath = docRef._customCollectionPath || docRef.collectionPath;
  const docId = docRef._customId || docRef.id;

  if (isLocal) {
    const items = getLocalCollection(colPath);
    const matched = items.find(item => item.id === docId || item.uid === docId);
    return new MockDocumentSnapshot(docId, matched, docRef);
  }

  try {
    return await nativeGetDoc(docRef);
  } catch (error) {
    if (isQuotaError(error)) {
      localStorage.setItem('firestore_quota_exceeded', 'true');
      const items = getLocalCollection(colPath);
      const matched = items.find(item => item.id === docId || item.uid === docId);
      return new MockDocumentSnapshot(docId, matched, docRef);
    }
    throw error;
  }
}

export async function getDocs(q: any) {
  const isLocal = localStorage.getItem('firestore_quota_exceeded') === 'true' || q._isMockRef || !q.firestore;
  const colPath = q._customPath || q.path;

  if (isLocal) {
    const items = getLocalCollection(colPath);
    const filtered = applyQueryConstraints(items, q);
    const docs = filtered.map(item => new MockDocumentSnapshot(item.uid || item.id, item, q));
    return new MockQuerySnapshot(docs);
  }

  try {
    return await nativeGetDocs(q);
  } catch (error) {
    if (isQuotaError(error)) {
      localStorage.setItem('firestore_quota_exceeded', 'true');
      const items = getLocalCollection(colPath);
      const filtered = applyQueryConstraints(items, q);
      const docs = filtered.map(item => new MockDocumentSnapshot(item.uid || item.id, item, q));
      return new MockQuerySnapshot(docs);
    }
    throw error;
  }
}

export async function setDoc(docRef: any, data: any, options?: any) {
  const isLocal = localStorage.getItem('firestore_quota_exceeded') === 'true' || docRef._isMockRef || !docRef.firestore;
  const colPath = docRef._customCollectionPath || docRef.collectionPath;
  const docId = docRef._customId || docRef.id;

  if (isLocal) {
    const items = getLocalCollection(colPath);
    const existingIndex = items.findIndex(item => item.id === docId || item.uid === docId);
    let finalData = { ...data };
    if (existingIndex >= 0) {
      if (options?.merge) {
        finalData = { ...items[existingIndex], ...data };
      }
      items[existingIndex] = { ...finalData, id: docId };
    } else {
      items.push({ ...finalData, id: docId });
    }
    saveLocalCollection(colPath, items);
    return;
  }

  try {
    return await nativeSetDoc(docRef, data, options);
  } catch (error) {
    if (isQuotaError(error)) {
      localStorage.setItem('firestore_quota_exceeded', 'true');
      const items = getLocalCollection(colPath);
      const existingIndex = items.findIndex(item => item.id === docId || item.uid === docId);
      let finalData = { ...data };
      if (existingIndex >= 0) {
        if (options?.merge) {
          finalData = { ...items[existingIndex], ...data };
        }
        items[existingIndex] = { ...finalData, id: docId };
      } else {
        items.push({ ...finalData, id: docId });
      }
      saveLocalCollection(colPath, items);
      return;
    }
    throw error;
  }
}

export async function updateDoc(docRef: any, ...args: any[]) {
  const isLocal = localStorage.getItem('firestore_quota_exceeded') === 'true' || docRef._isMockRef || !docRef.firestore;
  const colPath = docRef._customCollectionPath || docRef.collectionPath;
  const docId = docRef._customId || docRef.id;

  let dataToUpdate: any = {};
  if (args.length === 1 && typeof args[0] === 'object' && args[0] !== null) {
    dataToUpdate = args[0];
  } else {
    for (let i = 0; i < args.length; i += 2) {
      if (typeof args[i] === 'string') {
        dataToUpdate[args[i]] = args[i + 1];
      }
    }
  }

  if (isLocal) {
    const items = getLocalCollection(colPath);
    const existingIndex = items.findIndex(item => item.id === docId || item.uid === docId);
    if (existingIndex >= 0) {
      const current = items[existingIndex];
      const updated = { ...current };
      Object.keys(dataToUpdate).forEach(key => {
        const val = dataToUpdate[key];
        if (val && typeof val === 'object' && val._customIncrement !== undefined) {
          updated[key] = (updated[key] || 0) + val._customIncrement;
        } else if (val && typeof val === 'object' && val._customArrayUnion !== undefined) {
          const arr = Array.isArray(updated[key]) ? updated[key] : [];
          const unionElems = val._customArrayUnion;
          const unionSet = new Set(arr);
          unionElems.forEach((el: any) => unionSet.add(el));
          updated[key] = Array.from(unionSet);
        } else if (val && typeof val === 'object' && val._customArrayRemove !== undefined) {
          const arr = Array.isArray(updated[key]) ? updated[key] : [];
          const removeElems = val._customArrayRemove;
          updated[key] = arr.filter((el: any) => !removeElems.includes(el));
        } else {
          updated[key] = val;
        }
      });
      items[existingIndex] = updated;
      saveLocalCollection(colPath, items);
    }
    return;
  }

  try {
    return await (nativeUpdateDoc as any)(docRef, ...args);
  } catch (error) {
    if (isQuotaError(error)) {
      localStorage.setItem('firestore_quota_exceeded', 'true');
      const items = getLocalCollection(colPath);
      const existingIndex = items.findIndex(item => item.id === docId || item.uid === docId);
      if (existingIndex >= 0) {
        const current = items[existingIndex];
        const updated = { ...current };
        Object.keys(dataToUpdate).forEach(key => {
          const val = dataToUpdate[key];
          if (val && typeof val === 'object' && val._customIncrement !== undefined) {
            updated[key] = (updated[key] || 0) + val._customIncrement;
          } else if (val && typeof val === 'object' && val._customArrayUnion !== undefined) {
            const arr = Array.isArray(updated[key]) ? updated[key] : [];
            const unionElems = val._customArrayUnion;
            const unionSet = new Set(arr);
            unionElems.forEach((el: any) => unionSet.add(el));
            updated[key] = Array.from(unionSet);
          } else if (val && typeof val === 'object' && val._customArrayRemove !== undefined) {
            const arr = Array.isArray(updated[key]) ? updated[key] : [];
            const removeElems = val._customArrayRemove;
            updated[key] = arr.filter((el: any) => !removeElems.includes(el));
          } else {
            updated[key] = val;
          }
        });
        items[existingIndex] = updated;
        saveLocalCollection(colPath, items);
      }
      return;
    }
    throw error;
  }
}

export async function addDoc(collectionRef: any, data: any) {
  const isLocal = localStorage.getItem('firestore_quota_exceeded') === 'true' || collectionRef._isMockRef || !collectionRef.firestore;
  const colPath = collectionRef._customPath || collectionRef.path;

  if (isLocal) {
    const items = getLocalCollection(colPath);
    const id = `item_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const newItem = { ...data, id };
    items.push(newItem);
    saveLocalCollection(colPath, items);
    return { id, path: `${colPath}/${id}` } as any;
  }

  try {
    return await nativeAddDoc(collectionRef, data);
  } catch (error) {
    if (isQuotaError(error)) {
      localStorage.setItem('firestore_quota_exceeded', 'true');
      const items = getLocalCollection(colPath);
      const id = `item_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const newItem = { ...data, id };
      items.push(newItem);
      saveLocalCollection(colPath, items);
      return { id, path: `${colPath}/${id}` } as any;
    }
    throw error;
  }
}

export async function deleteDoc(docRef: any) {
  const isLocal = localStorage.getItem('firestore_quota_exceeded') === 'true' || docRef._isMockRef || !docRef.firestore;
  const colPath = docRef._customCollectionPath || docRef.collectionPath;
  const docId = docRef._customId || docRef.id;

  if (isLocal) {
    const items = getLocalCollection(colPath);
    const updated = items.filter(item => item.id !== docId && item.uid !== docId);
    saveLocalCollection(colPath, updated);
    return;
  }

  try {
    return await nativeDeleteDoc(docRef);
  } catch (error) {
    if (isQuotaError(error)) {
      localStorage.setItem('firestore_quota_exceeded', 'true');
      const items = getLocalCollection(colPath);
      const updated = items.filter(item => item.id !== docId && item.uid !== docId);
      saveLocalCollection(colPath, updated);
      return;
    }
    throw error;
  }
}

export function onSnapshot(ref: any, ...args: any[]) {
  let callback: any = null;
  let errorCallback: any = null;

  if (typeof args[0] === 'function') {
    callback = args[0];
    errorCallback = args[1];
  } else if (typeof args[1] === 'function') {
    callback = args[1];
    errorCallback = args[2];
  }

  const isLocal = localStorage.getItem('firestore_quota_exceeded') === 'true' || ref._isMockRef || !ref.firestore;
  const isDocument = ref.type === 'document' || ref._isDocRef || !!ref._customCollectionPath || !!ref.collectionPath;
  let colPath = '';
  let docId = '';

  if (isDocument) {
    if (ref._customCollectionPath || ref.collectionPath) {
      colPath = ref._customCollectionPath || ref.collectionPath;
      docId = ref._customId || ref.id;
    } else if (ref.path) {
      const parts = ref.path.split('/');
      colPath = parts[0];
      docId = parts.slice(1).join('/');
    }
  } else {
    colPath = ref._customPath || ref.path;
  }

  const runLocalQuery = () => {
    if (isDocument) {
      const items = getLocalCollection(colPath);
      const matched = items.find(item => item.id === docId || item.uid === docId);
      const docSnap = new MockDocumentSnapshot(docId, matched, ref);
      callback(docSnap);
    } else {
      const items = getLocalCollection(colPath);
      const filtered = applyQueryConstraints(items, ref);
      const docs = filtered.map(item => new MockDocumentSnapshot(item.uid || item.id, item, ref));
      callback(new MockQuerySnapshot(docs));
    }
  };

  if (isLocal) {
    runLocalQuery();

    const updateListener = (e: any) => {
      if (e.detail?.collection === colPath) {
        runLocalQuery();
      }
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('local-db-update', updateListener);
    }

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('local-db-update', updateListener);
      }
    };
  }

  const wrappedErrorCallback = (err: any) => {
    if (isQuotaError(err)) {
      console.warn("Async quota limit detected in onSnapshot, transitioning to local cached database.", err);
      localStorage.setItem('firestore_quota_exceeded', 'true');
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('local-db-update', { detail: { collection: colPath } }));
      }
      runLocalQuery();
    } else if (errorCallback) {
      errorCallback(err);
    }
  };

  const modifiedArgs = [...args];
  if (typeof args[0] === 'function') {
    modifiedArgs[1] = wrappedErrorCallback;
  } else if (typeof args[1] === 'function') {
    modifiedArgs[2] = wrappedErrorCallback;
  }

  try {
    return (nativeOnSnapshot as any)(ref, ...modifiedArgs);
  } catch (error) {
    if (isQuotaError(error)) {
      localStorage.setItem('firestore_quota_exceeded', 'true');
      runLocalQuery();

      const updateListener = (e: any) => {
        if (e.detail?.collection === colPath) {
          runLocalQuery();
        }
      };

      if (typeof window !== 'undefined') {
        window.addEventListener('local-db-update', updateListener);
      }

      return () => {
        if (typeof window !== 'undefined') {
          window.removeEventListener('local-db-update', updateListener);
        }
      };
    }
    if (errorCallback) {
      errorCallback(error);
      return () => {};
    }
    throw error;
  }
}

export function increment(n: number) {
  try {
    const inc = nativeIncrement(n);
    (inc as any)._customIncrement = n;
    return inc;
  } catch (error) {
    return { _customIncrement: n } as any;
  }
}

export function arrayUnion(...elements: any[]) {
  try {
    const union = nativeArrayUnion(...elements);
    (union as any)._customArrayUnion = elements;
    return union;
  } catch (error) {
    return { _customArrayUnion: elements } as any;
  }
}

export function arrayRemove(...elements: any[]) {
  try {
    const remove = nativeArrayRemove(...elements);
    (remove as any)._customArrayRemove = elements;
    return remove;
  } catch (error) {
    return { _customArrayRemove: elements } as any;
  }
}

class CustomWriteBatch {
  private _db: any;
  private _ops: Array<{ type: 'set' | 'update' | 'delete', docRef: any, args: any[] }> = [];
  constructor(db: any) {
    this._db = db;
  }
  set(docRef: any, data: any, options?: any) {
    this._ops.push({ type: 'set', docRef, args: [data, options] });
  }
  update(docRef: any, ...args: any[]) {
    this._ops.push({ type: 'update', docRef, args });
  }
  delete(docRef: any) {
    this._ops.push({ type: 'delete', docRef, args: [] });
  }
  async commit() {
    const isLocal = localStorage.getItem('firestore_quota_exceeded') === 'true';
    if (isLocal) {
      this.executeLocally();
      return;
    }
    try {
      const nativeBatch = nativeWriteBatch(this._db);
      for (const op of this._ops) {
        if (op.type === 'set') {
          nativeBatch.set(op.docRef, op.args[0], op.args[1]);
        } else if (op.type === 'update') {
          (nativeBatch as any).update(op.docRef, op.args[0], ...op.args.slice(1));
        } else if (op.type === 'delete') {
          nativeBatch.delete(op.docRef);
        }
      }
      await nativeBatch.commit();
    } catch (error) {
      if (isQuotaError(error)) {
        localStorage.setItem('firestore_quota_exceeded', 'true');
        console.warn("Write batch failed due to quota, falling back to local operations.");
        this.executeLocally();
        return;
      }
      throw error;
    }
  }

  private executeLocally() {
    for (const op of this._ops) {
      if (op.type === 'set') {
        setDoc(op.docRef, op.args[0], op.args[1]);
      } else if (op.type === 'update') {
        updateDoc(op.docRef, ...op.args);
      } else if (op.type === 'delete') {
        deleteDoc(op.docRef);
      }
    }
  }
}

export function writeBatch(db: any) {
  return new CustomWriteBatch(db) as any;
}

export {
  serverTimestamp,
  onAuthStateChanged,
  onSnapshotsInSync
};

export type { FirebaseUser };
