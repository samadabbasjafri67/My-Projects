import React from 'react';
import { Wallet, ArrowUpCircle, ArrowDownCircle, Gift, Share2, Copy, History, Plus, CreditCard } from 'lucide-react';
import { TRANSLATIONS } from '../constants';
import { User, WalletTransaction } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import { db, collection, query, where, onSnapshot, orderBy, handleFirestoreError, OperationType, addDoc, doc, updateDoc, increment, getDocs } from '../firebase';
import { SimulatedWalletPaymentModal } from './SimulatedWalletPaymentModal';

interface WalletSectionProps {
  currentUser: string;
  language: string;
  showNotification: (msg: string, color: string) => void;
}

export const WalletSection: React.FC<WalletSectionProps> = ({
  currentUser,
  language,
  showNotification
}) => {
  const [user, setUser] = React.useState<User | null>(null);
  const [transactions, setTransactions] = React.useState<WalletTransaction[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [isToppingUp, setIsToppingUp] = React.useState(false);
  const [topUpAmount, setTopUpAmount] = React.useState('');
  const [showPaymentModal, setShowPaymentModal] = React.useState(false);
  const [pendingTopUpAmount, setPendingTopUpAmount] = React.useState<number | null>(null);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  React.useEffect(() => {
    if (!currentUser) return;

    // Listen to user profile
    const userUnsub = onSnapshot(doc(db, 'users', currentUser), (docSnap) => {
      if (docSnap.exists()) {
        const userData = docSnap.data() as User;
        // Generate referral code if missing
        if (!userData.referralCode) {
          const code = (userData.username.substring(0, 3) + Math.random().toString(36).substring(2, 6)).toUpperCase();
          updateDoc(docSnap.ref, { referralCode: code });
        }
        setUser(userData);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${currentUser}`);
    });

    // Listen to transactions
    const q = query(
      collection(db, 'transactions'),
      where('userId', '==', currentUser),
      orderBy('createdAt', 'desc')
    );
    const transUnsub = onSnapshot(q, (snapshot) => {
      const trans = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as WalletTransaction));
      setTransactions(trans);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'transactions');
      setLoading(false);
    });

    return () => {
      userUnsub();
      transUnsub();
    };
  }, [currentUser]);

  const initiateTopUp = () => {
    const amount = parseFloat(topUpAmount);
    if (isNaN(amount) || amount <= 0) {
      showNotification(language === 'hi' ? 'कृपया मान्य राशि दर्ज करें' : 'Please enter a valid amount', '#e53935');
      return;
    }
    setPendingTopUpAmount(amount);
    setShowPaymentModal(true);
  };

  const handleTopUpSuccess = async () => {
    if (pendingTopUpAmount === null) return;
    const amount = pendingTopUpAmount;
    setIsToppingUp(true);
    setShowPaymentModal(false);
    try {
      // 1. Update User Balance
      await updateDoc(doc(db, 'users', currentUser), {
        walletBalance: increment(amount)
      });

      // 2. Add Transaction Record
      await addDoc(collection(db, 'transactions'), {
        userId: currentUser,
        amount,
        type: 'credit',
        reason: 'top_up',
        createdAt: new Date().toISOString()
      });

      showNotification(language === 'hi' ? `₹${amount} सफलतापूर्वक जोड़े गए` : `₹${amount} added successfully`, '#10b981');
      setTopUpAmount('');
      setPendingTopUpAmount(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'transactions');
    } finally {
      setIsToppingUp(false);
    }
  };

  const copyReferral = () => {
    if (user?.referralCode) {
      navigator.clipboard.writeText(user.referralCode);
      showNotification(language === 'hi' ? 'रेफरल कोड कॉपी किया गया' : 'Referral code copied!', '#3b82f6');
    }
  };

  const handleShareReferral = async () => {
    if (!user?.referralCode) return;
    
    const shareTitle = language === 'hi' ? 'EcoPool से जुड़ें' : 'Join EcoPool';
    const shareText = language === 'hi' 
      ? `EcoPool से जुड़ें और मेरे रेफरल कोड का उपयोग करें: ${user.referralCode}। जुड़ने पर ₹50 पाएं!`
      : `Join EcoPool and use my referral code: ${user.referralCode}. Get ₹50 bonus on joining!`;
    const shareUrl = window.location.origin;

    const copyToClipboard = async () => {
      try {
        await navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
        showNotification(language === 'hi' ? 'रेफरल लिंक कॉपी किया गया' : 'Referral link copied to clipboard!', '#10b981');
      } catch (err) {
        console.error("Error copying to clipboard:", err);
        showNotification(language === 'hi' ? 'साझा करने में विफल' : "Failed to share", "#e53935");
      }
    };

    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl,
        });
      } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') return;
        console.error("Error sharing:", err);
        await copyToClipboard();
      }
    } else {
      await copyToClipboard();
    }
  };

  if (loading) return <div className="flex justify-center p-12"><LoadingSpinner /></div>;

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      {/* Wallet Card Header */}
      <div className="relative overflow-hidden bg-gradient-to-br from-blue-700 to-indigo-800 rounded-2xl p-8 shadow-xl text-white">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Wallet size={120} />
        </div>
        
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2 opacity-80">
            <Wallet size={16} />
            <span className="text-xs font-bold uppercase tracking-wider">{t.walletBalance}</span>
          </div>
          <div className="text-5xl font-black mb-6">₹{(user?.walletBalance || 0).toLocaleString()}</div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/10">
              <div className="flex items-center gap-2 text-xs opacity-80 mb-1">
                <Gift size={14} />
                <span>{t.totalCashback}</span>
              </div>
              <div className="text-xl font-bold">₹{(user?.totalCashbackEarned || 0).toLocaleString()}</div>
            </div>
            
            <div className="flex items-center justify-center">
               <button 
                onClick={() => document.getElementById('topUpInput')?.focus()}
                className="bg-white text-blue-700 px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest shadow-lg hover:bg-blue-50 transition-all active:scale-95"
               >
                 {t.topUp}
               </button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Top Up Section */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between">
          <div>
            <h3 className="text-lg font-black text-slate-900 mb-2 flex items-center gap-2">
              <CreditCard size={20} className="text-blue-600" />
              {t.topUp}
            </h3>
            <p className="text-xs text-slate-500 mb-6 font-medium">Add funds to your wallet for hassle-free ride payments.</p>
            
            <div className="relative mb-4">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">₹</span>
              <input 
                id="topUpInput"
                type="number" 
                value={topUpAmount}
                onChange={(e) => setTopUpAmount(e.target.value)}
                placeholder="Enter amount"
                className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-slate-100 focus:border-blue-500 transition-colors font-bold outline-none"
              />
            </div>
          </div>
          <button 
            id="initiate-topup-btn"
            onClick={initiateTopUp}
            disabled={isToppingUp || showPaymentModal}
            className="w-full bg-slate-900 text-white font-black py-3 rounded-xl hover:bg-slate-800 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isToppingUp ? <LoadingSpinner size="sm" /> : <Plus size={18} />}
            {t.topUp}
          </button>
        </div>

        {/* Refer and Earn */}
        <div className="bg-emerald-50 p-6 rounded-2xl border border-emerald-100 flex flex-col justify-between">
          <div>
            <h3 className="text-lg font-black text-emerald-900 mb-2 flex items-center gap-2">
              <Gift size={20} className="text-emerald-600" />
              {t.referAndEarn}
            </h3>
            <p className="text-xs text-emerald-700/70 mb-6 font-medium">{t.referralText}</p>
            
            <div className="bg-white border border-emerald-200 p-4 rounded-xl flex items-center justify-between mb-4">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase block mb-0.5">{t.yourReferralCode}</span>
                <span className="text-xl font-black tracking-widest text-slate-800">{user?.referralCode || '-------'}</span>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={copyReferral}
                  className="p-2 hover:bg-slate-50 rounded-lg transition-colors text-slate-500"
                >
                  <Copy size={20} />
                </button>
                <button 
                  onClick={handleShareReferral}
                  className="p-2 hover:bg-slate-50 rounded-lg transition-colors text-slate-500"
                >
                  <Share2 size={20} />
                </button>
              </div>
            </div>
          </div>
          <div className="text-[10px] text-emerald-600 font-black italic text-center">
            Rewards are automatically credited when your friend completes their first ride!
          </div>
        </div>
      </div>

      {/* Transaction History */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-50 flex items-center justify-between">
          <h3 className="font-black text-slate-900 flex items-center gap-2">
            <History size={18} className="text-slate-400" />
            {t.transactionHistory}
          </h3>
        </div>
        
        <div className="divide-y divide-slate-50">
          {transactions.length > 0 ? transactions.map((tx) => (
            <div key={tx.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-4">
                <div className={`p-2 rounded-xl ${tx.type === 'credit' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                  {tx.type === 'credit' ? <ArrowUpCircle size={24} /> : <ArrowDownCircle size={24} />}
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900">
                    {tx.reason === 'cashback_ride' && t.cashbackEarned}
                    {tx.reason === 'ride_payment' && t.ridePayment}
                    {tx.reason === 'top_up' && t.amountAdded}
                    {tx.reason === 'cashback_referral' && t.referralBonus}
                    {tx.reason === 'refund' && 'Refunded'}
                  </div>
                  <div className="text-[10px] text-slate-400 font-medium">
                    {new Date(tx.createdAt).toLocaleDateString()} • {new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
              <div className={`text-sm font-black ${tx.type === 'credit' ? 'text-emerald-600' : 'text-slate-900'}`}>
                {tx.type === 'credit' ? '+' : '-'} ₹{tx.amount.toLocaleString()}
              </div>
            </div>
          )) : (
            <div className="p-12 text-center text-slate-400 font-medium text-sm">
              {t.noTransactions}
            </div>
          )}
        </div>
      </div>

      {showPaymentModal && pendingTopUpAmount !== null && (
        <SimulatedWalletPaymentModal
          amount={pendingTopUpAmount}
          language={language}
          onSuccess={handleTopUpSuccess}
          onClose={() => {
            setShowPaymentModal(false);
            setPendingTopUpAmount(null);
          }}
          showNotification={showNotification}
        />
      )}
    </div>
  );
};
