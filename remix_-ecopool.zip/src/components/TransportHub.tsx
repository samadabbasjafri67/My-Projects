import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Car, Bike, Train, Bus, ExternalLink, ArrowRight, CornerDownRight, Compass, Info, Sparkles } from 'lucide-react';
import { TRANSLATIONS } from '../constants';

interface TransportHubProps {
  language: string;
  onNavigateToSection: (section: string) => void;
  onSelectPoolTypePreset: (poolType: 'all' | 'car' | 'bike' | 'ev') => void;
}

export const TransportHub: React.FC<TransportHubProps> = ({
  language,
  onNavigateToSection,
  onSelectPoolTypePreset
}) => {
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;
  const [activeFrameUrl, setActiveFrameUrl] = React.useState<string | null>(null);
  const [activeFrameTitle, setActiveFrameTitle] = React.useState<string | null>(null);

  const handleRouteRedirect = (poolType: 'all' | 'car' | 'bike' | 'ev') => {
    onSelectPoolTypePreset(poolType);
    onNavigateToSection("searchSection");
  };

  const openInAppWebview = (url: string, title: string) => {
    setActiveFrameUrl(url);
    setActiveFrameTitle(title);
  };

  const closeWebview = () => {
    setActiveFrameUrl(null);
    setActiveFrameTitle(null);
  };

  return (
    <div id="transport-hub-container" className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      {/* Title Panel */}
      <div className="bg-gradient-to-tr from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 md:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 bottom-0 opacity-10 translate-x-8 translate-y-8 select-none pointer-events-none">
          <Compass size={320} className="animate-spin-slow" />
        </div>
        <div className="relative z-10 max-w-xl space-y-3">
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-500/10 text-blue-300 text-xs font-black uppercase tracking-widest rounded-full border border-blue-400/20">
            <Sparkles size={12} /> {language === 'hi' ? 'स्मार्ट पारगमन' : 'Smart Transit Ecosystem'}
          </span>
          <h1 className="text-3xl md:text-4xl font-black tracking-tight leading-none bg-gradient-to-r from-white via-slate-100 to-indigo-100 bg-clip-text text-transparent">
            {language === 'hi' ? 'स्मार्ट ट्रांसपोर्ट हब' : 'Transit Hub & Alternatives'}
          </h1>
          <p className="text-slate-300 text-sm leading-relaxed font-semibold">
            {language === 'hi' 
              ? 'कारपूल उपलब्ध न होने पर सहज यात्रा के लिए अन्य सार्वजनिक परिवहन और वैकल्पिक साधनों की खोज करें।'
              : 'Our unified smart transport gateway helps you find real-time alternative commuting routes, or transition to metro and bus transit easily.'}
          </p>
        </div>
      </div>

      {/* Grid of Transit Modes */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: Carpool Rides */}
        <motion.div 
          whileHover={{ y: -4 }}
          className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="bg-blue-50 p-4 rounded-2xl text-blue-600 border border-blue-100">
                <Car size={32} />
              </div>
              <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100 uppercase tracking-wide">
                {language === 'hi' ? 'सक्रिय' : 'Active'}
              </span>
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-extrabold text-slate-900">
                {language === 'hi' ? 'कारपूल राइड्स खोजें' : 'Carpool Rides'}
              </h3>
              <p className="text-slate-500 text-xs font-bold leading-relaxed">
                {language === 'hi' 
                  ? 'अपने समुदाय के साथ यात्रा शेयर करें और पर्यावरण बचाएं। हमारे सभी सक्रिय मार्गों पर कारपूल राइड उपलब्ध हैं।'
                  : 'Check active carpool listings, interact with verified commuters, and share your city rides securely.'}
              </p>
            </div>
          </div>
          <div className="mt-6">
            <button
              onClick={() => handleRouteRedirect('all')}
              className="w-full flex items-center justify-between px-4 py-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-black uppercase tracking-wider rounded-xl transition-all shadow-sm"
            >
              <span>{language === 'hi' ? 'कारपूल राइड्स पर जाएं' : 'Search Carpools'}</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </motion.div>

        {/* Card 2: Bike Pool */}
        <motion.div 
          whileHover={{ y: -4 }}
          className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="bg-amber-50 p-4 rounded-2xl text-amber-600 border border-amber-100">
                <Bike size={32} />
              </div>
              <span className="text-xs font-black text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-100 uppercase tracking-wide">
                ⭐ {language === 'hi' ? 'लोकप्रिय विकल्प' : 'Popular alternative'}
              </span>
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-extrabold text-slate-900">
                {language === 'hi' ? 'त्वरित बाइक पूल' : 'Bike Pool Option'}
              </h3>
              <p className="text-slate-500 text-xs font-bold leading-relaxed">
                {language === 'hi' 
                  ? 'कार्यालय मार्ग पर किफायती और सबसे तेज़ परिवहन विकल्प। सुरक्षा सर्वोपरि - अतिरिक्त हेलमेट उपलब्ध।'
                  : 'Navigate heavy peak-hour traffic in style. Commute with certified poolers providing high-standard safety helmets.'}
              </p>
            </div>
          </div>
          <div className="mt-6">
            <button
              onClick={() => handleRouteRedirect('bike')}
              className="w-full flex items-center justify-between px-4 py-3 bg-amber-600 hover:bg-amber-700 text-white text-xs font-black uppercase tracking-wider rounded-xl transition-all shadow-sm shadow-amber-100"
            >
              <span>{language === 'hi' ? 'सक्रिय बाइक पूल देखें' : 'Search Bike Pools'}</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </motion.div>

        {/* Card 3: Delhi Metro */}
        <motion.div 
          whileHover={{ y: -4 }}
          className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="bg-red-50 p-4 rounded-2xl text-red-600 border border-red-100">
                <Train size={32} />
              </div>
              <span className="text-xs font-black text-red-600 bg-red-50 px-2.5 py-1 rounded-full border border-red-100 uppercase tracking-wide">
                🚇 {language === 'hi' ? 'दिल्ली मेट्रो' : 'Delhi Metro'}
              </span>
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-extrabold text-slate-900">
                {language === 'hi' ? 'मेट्रो रूट और समय-सारणी' : 'Delhi Metro Routes (DMRC)'}
              </h3>
              <p className="text-slate-500 text-xs font-bold leading-relaxed">
                {language === 'hi' 
                  ? 'अत्यधिक विश्वसनीय दिल्ली मेट्रो लाइन। सीधे स्टेशन रूट नक्शे का पता लगाएं या अपनी यात्रा का समय नियोजित करें।'
                  : 'Avoid peak congestion. Plan transfers, live train timings, ticket fares, and transit directions.'}
              </p>
            </div>
          </div>
          <div className="mt-6 grid grid-cols-2 gap-3">
            <button
              onClick={() => openInAppWebview("https://delhimetrorail.com/", language === 'hi' ? 'दिल्ली मेट्रो' : 'Delhi Metro Board')}
              className="px-3 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-black uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5"
            >
              📱 {language === 'hi' ? 'इन-ऐप खोलें' : 'View In-App'}
            </button>
            <a
              href="https://delhimetrorail.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-3 bg-red-600 hover:bg-red-700 text-white text-xs font-black uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-sm text-center"
            >
              <span>{language === 'hi' ? 'वेबसाइट खोलें' : 'Open Website'}</span>
              <ExternalLink size={14} />
            </a>
          </div>
        </motion.div>

        {/* Card 4: DTC Bus Routes */}
        <motion.div 
          whileHover={{ y: -4 }}
          className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="bg-indigo-50 p-4 rounded-2xl text-indigo-600 border border-indigo-100">
                <Bus size={32} />
              </div>
              <span className="text-xs font-black text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full border border-indigo-100 uppercase tracking-wide">
                🚌 DTC Bus Network
              </span>
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-extrabold text-slate-900">
                {language === 'hi' ? 'डीटीसी बस मार्ग' : 'Delhi Bus Routes / DTC'}
              </h3>
              <p className="text-slate-500 text-xs font-bold leading-relaxed">
                {language === 'hi' 
                  ? 'दिल्ली परिवहन निगम (DTC) रूट खोजक। लाइव मार्ग स्टॉप, नंबर और बस कनेक्टिविटी को आसानी से ट्रेस करें।'
                  : 'Check operational bus routes, schedules, stops, and localized DTC transport connection points.'}
              </p>
            </div>
          </div>
          <div className="mt-6 grid grid-cols-2 gap-3">
            <button
              onClick={() => openInAppWebview("https://www.dtcbusroutes.in/bus/route/search/", language === 'hi' ? 'डीटीसी बस मार्ग' : 'DTC Bus Routes')}
              className="px-3 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-black uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5"
            >
              📱 {language === 'hi' ? 'इन-ऐप खोलें' : 'View In-App'}
            </button>
            <a
              href="https://www.dtcbusroutes.in/bus/route/search/"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-sm text-center"
            >
              <span>{language === 'hi' ? 'वेबसाइट खोलें' : 'Open Website'}</span>
              <ExternalLink size={14} />
            </a>
          </div>
        </motion.div>
      </div>

      {/* Multi-modal Travel Guidelines Info Box */}
      <div className="bg-slate-50 border border-slate-200 rounded-3xl p-6">
        <div className="flex gap-4">
          <div className="bg-blue-100 text-blue-700 p-2.5 rounded-2xl h-fit">
            <Info size={24} />
          </div>
          <div className="space-y-1.5">
            <h4 className="text-sm font-black text-slate-900 uppercase tracking-wide">
              🌿 {language === 'hi' ? 'मल्टीमोडल पारगमन की शक्ति क्यों?' : 'Why Multimodal Commuting Key?'}
            </h4>
            <p className="text-xs text-slate-600 font-bold leading-relaxed">
              {language === 'hi'
                ? 'कारपूल या बाइक पूल राइड तथा मेट्रो या बस प्रणालियों का मिश्रण कर आप यातायात की अंतिम मील कनेक्टिविटी का समाधान अत्यंत लागत और कम कार्बन उत्सर्जन के साथ कर सकते हैं।'
                : 'Combining customized car/bike pooling for first/last-mile connectivity with robust mass transits (Delhi Metro or Bus) reduces road congestion, cuts journey cost by 35%+, and slashes high fuel carbon emissions.'}
            </p>
          </div>
        </div>
      </div>

      {/* In-app Webview Modal / Overlay Frame */}
      <AnimatePresence>
        {activeFrameUrl && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-md flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="bg-white rounded-3xl w-full max-w-5xl h-[85vh] md:h-[90vh] shadow-2xl overflow-hidden flex flex-col border border-slate-200"
            >
              {/* Overlay Header */}
              <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
                  <span className="text-xs font-black uppercase tracking-wider text-slate-400">
                    🌍 {language === 'hi' ? 'इन-ऐप वेब व्यू:' : 'In-App Webview:'}
                  </span>
                  <p className="text-xs font-bold text-white bg-slate-800 px-3 py-1 rounded">
                    {activeFrameTitle}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <a 
                    href={activeFrameUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 py-1.5 px-3 bg-blue-600 hover:bg-blue-700 text-[10px] font-black uppercase text-white rounded-lg transition-all"
                  >
                    <span>{language === 'hi' ? 'सफारी/क्रोम में खोलें' : 'Open Direct'}</span>
                    <ExternalLink size={12} />
                  </a>
                  <button 
                    onClick={closeWebview}
                    className="text-slate-400 hover:text-white font-extrabold text-sm px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700/80 rounded-lg transition-all"
                  >
                    ✕ {language === 'hi' ? 'बंद करें' : 'Close'}
                  </button>
                </div>
              </div>

              {/* Informative Iframe Guide Block */}
              <div className="bg-amber-50 border-b border-amber-100 px-6 py-3 flex items-start gap-2">
                <span className="text-amber-800 text-sm">💡</span>
                <p className="text-[11px] font-bold text-amber-900 leading-normal">
                  {language === 'hi'
                    ? 'नोट: सुरक्षा कारणों से कुछ आधिकारिक पोर्टल सीधे एम्बेडेड फ्रेम में लोड होने पर प्रतिबंध लगा सकते हैं (CSP)। यदि नीचे साइट न दिखे, तो शीर्ष पर "वेबसाइट खोलें" या "सफारी/क्रोम में खोलें" बटन दबाएं।'
                    : 'Security Notice: Official portals sometimes restrict external iframe embeds. If the screen is blank or blockaded, click "Open Direct" to launch the page in a safe, standard external tab.'}
                </p>
              </div>

              {/* The Actual Webframe */}
              <div className="flex-1 bg-slate-100 relative">
                <iframe 
                  src={activeFrameUrl}
                  title={activeFrameTitle || "Transport Route Portal"}
                  className="w-full h-full border-0"
                  sandbox="allow-scripts allow-same-origin allow-forms"
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
