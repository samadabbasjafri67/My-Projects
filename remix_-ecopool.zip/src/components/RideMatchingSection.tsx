import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TRANSLATIONS } from '../constants';
import { Ride, RideRequest } from '../types';
import { db, collection, addDoc, query, where, onSnapshot, handleFirestoreError, OperationType, deleteDoc, doc } from '../firebase';
import { LoadingSpinner } from './LoadingSpinner';
import { MapPin, Calendar, Clock, Search, Trash2, CheckCircle2, Navigation, Car, ShieldCheck, Star } from 'lucide-react';
import { NotificationService } from '../services/notificationService';

interface RideMatchingSectionProps {
  currentUser: string;
  showNotification: (msg: string, color?: string) => void;
  onStartBooking: (ride: Ride) => void;
  language: string;
}

export const RideMatchingSection: React.FC<RideMatchingSectionProps> = ({ currentUser, showNotification, onStartBooking, language }) => {
  const [from, setFrom] = React.useState("");
  const [to, setTo] = React.useState("");
  const [date, setDate] = React.useState("");
  const [time, setTime] = React.useState("");
  const [isPosting, setIsPosting] = React.useState(false);
  const [myRequests, setMyRequests] = React.useState<RideRequest[]>([]);
  const [allRides, setAllRides] = React.useState<Ride[]>([]);
  const [loading, setLoading] = React.useState(true);
  const notifiedMatchesRef = React.useRef<Set<string>>(new Set());

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  // Real-time notification logic
  React.useEffect(() => {
    if (myRequests.length === 0 || allRides.length === 0) return;

    myRequests.forEach(req => {
      const matches = getMatches(req);
      matches.forEach(match => {
        const matchKey = `${req.id}_${match.id}`;
        if (!notifiedMatchesRef.current.has(matchKey)) {
          showNotification(
            language === 'hi' 
              ? `नया मैच मिला: ${match.from} से ${match.to}` 
              : `New match found: ${match.from} to ${match.to} (${match.matchScore}% match!)`,
            "#10b981"
          );
          
          NotificationService.sendNotification(language === 'hi' ? 'नया राइड मैच मिला!' : 'New Ride Match Found!', {
            body: language === 'hi' 
              ? `${match.from} से ${match.to} के लिए मैच उपलब्ध है` 
              : `A match is available for your request from ${match.from} to ${match.to}`,
            tag: `match_${req.id}`
          } as any);

          notifiedMatchesRef.current.add(matchKey);
        }
      });
    });
  }, [allRides, myRequests, language]);

  React.useEffect(() => {
    // Listen to my requests
    const qRequests = query(collection(db, 'rideRequests'), where('passengerId', '==', currentUser));
    const unsubscribeRequests = onSnapshot(qRequests, (snapshot) => {
      const requests = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as RideRequest));
      setMyRequests(requests);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'rideRequests');
    });

    // Listen to all active rides for matching
    const qRides = query(collection(db, 'rides'), where('seats', '>', 0));
    const unsubscribeRides = onSnapshot(qRides, (snapshot) => {
      const rides = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Ride));
      setAllRides(rides);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'rides');
    });

    return () => {
      unsubscribeRequests();
      unsubscribeRides();
    };
  }, [currentUser]);

  const postRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!from || !to || !date || !time) {
      showNotification("Please fill all fields", "#e53935");
      return;
    }

    setIsPosting(true);
    try {
      await addDoc(collection(db, 'rideRequests'), {
        passengerId: currentUser,
        from,
        to,
        date,
        time,
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      showNotification("Ride request posted successfully!");
      setFrom("");
      setTo("");
      setDate("");
      setTime("");
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'rideRequests');
    } finally {
      setIsPosting(false);
    }
  };

  const deleteRequest = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'rideRequests', id));
      showNotification("Request deleted");
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'rideRequests');
    }
  };

  const getMatches = (request: RideRequest) => {
    return allRides.filter(ride => {
      // Basic matching logic: same date and route (case-insensitive partial match)
      const sameDate = ride.date === request.date;
      const fromMatch = ride.from.toLowerCase().includes(request.from.toLowerCase()) || request.from.toLowerCase().includes(ride.from.toLowerCase());
      const toMatch = ride.to.toLowerCase().includes(request.to.toLowerCase()) || request.to.toLowerCase().includes(ride.to.toLowerCase());
      
      return sameDate && fromMatch && toMatch;
    }).map(ride => {
      // Calculate a simple match score
      let score = 70;
      if (ride.from.toLowerCase() === request.from.toLowerCase()) score += 15;
      if (ride.to.toLowerCase() === request.to.toLowerCase()) score += 15;
      
      // Time proximity (very simple)
      const rideHour = parseInt(ride.time.split(':')[0]);
      const reqHour = parseInt(request.time.split(':')[0]);
      if (Math.abs(rideHour - reqHour) <= 1) score += 10;

      return { ...ride, matchScore: score };
    }).sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0));
  };

  return (
    <div id="rideMatchingSection" className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">{t.rideMatching}</h2>
          <div className="flex items-center gap-2 mt-1">
            <p className="text-slate-500">{language === 'hi' ? 'अपनी यात्रा के लिए रीयल-टाइम मिलान खोजें' : 'Find real-time matches for your journey'}</p>
            <span className="flex items-center gap-1.5 px-2 py-0.5 bg-blue-50 text-blue-600 rounded-full text-[10px] font-black border border-blue-100 animate-pulse">
              <span className="w-1 h-1 bg-blue-500 rounded-full"></span>
              LIVE ARBITRAGE ACTIVE
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Post Request Form */}
        <div className="lg:col-span-1">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm sticky top-24">
            <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Navigation className="text-primary" size={20} />
              {t.postRequest}
            </h3>
            <form onSubmit={postRequest} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">{t.from}</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    placeholder={t.from} 
                    value={from} 
                    onChange={(e) => setFrom(e.target.value)} 
                    className="pl-10 w-full"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">{t.to}</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    placeholder={t.to} 
                    value={to} 
                    onChange={(e) => setTo(e.target.value)} 
                    className="pl-10 w-full"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">{t.date}</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="date" 
                      value={date} 
                      onChange={(e) => setDate(e.target.value)} 
                      className="pl-10 w-full"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">{t.time}</label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="time" 
                      value={time} 
                      onChange={(e) => setTime(e.target.value)} 
                      className="pl-10 w-full"
                    />
                  </div>
                </div>
              </div>
              <button 
                type="submit" 
                disabled={isPosting}
                className="w-full py-3 bg-primary hover:bg-primary-dark text-white rounded-xl font-bold shadow-lg shadow-blue-200 transition-all flex items-center justify-center gap-2 mt-4"
              >
                {isPosting ? <LoadingSpinner size="sm" color="white" /> : <Search size={18} />}
                {t.postRequest}
              </button>
            </form>
          </div>
        </div>

        {/* Active Requests & Matches */}
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <CheckCircle2 className="text-emerald-500" size={20} />
            {t.activeRequests}
          </h3>

          {loading ? (
            <div className="py-20 flex flex-col items-center justify-center">
              <LoadingSpinner />
            </div>
          ) : myRequests.length === 0 ? (
            <div className="text-center py-20 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
              <p className="text-slate-500">{language === 'hi' ? 'कोई सक्रिय अनुरोध नहीं' : 'No active requests'}</p>
            </div>
          ) : (
            <div className="space-y-6">
              <AnimatePresence mode="popLayout">
                {myRequests.map((req) => {
                  const matches = getMatches(req);
                  return (
                    <motion.div 
                      key={req.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"
                    >
                      <div className="p-6 bg-slate-50 border-b border-slate-200 flex justify-between items-start">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-black text-slate-900">{req.from}</span>
                            <Navigation size={14} className="text-slate-400" />
                            <span className="text-sm font-black text-slate-900">{req.to}</span>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-slate-500 font-medium">
                            <span className="flex items-center gap-1"><Calendar size={12} /> {req.date}</span>
                            <span className="flex items-center gap-1"><Clock size={12} /> {req.time}</span>
                          </div>
                        </div>
                        <button 
                          onClick={() => deleteRequest(req.id)}
                          className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>

                      <div className="p-6 space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                              <Search size={16} className="text-primary" />
                              {t.matchesFound} ({matches.length})
                            </h4>
                            <p className="text-[10px] text-slate-400 mt-0.5">Matching by route and ±1 hour proximity</p>
                          </div>
                          {matches.length > 0 && (
                            <span className="bg-emerald-100 text-emerald-700 text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider animate-pulse">
                              Real-Time
                            </span>
                          )}
                        </div>

                        {matches.length === 0 ? (
                          <div className="py-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200">
                            <p className="text-xs text-slate-500 px-4">{t.noMatches}</p>
                          </div>
                        ) : (
                          <div className="space-y-3">
                            {matches.map((ride) => (
                              <motion.div 
                                key={ride.id}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                className="flex items-center justify-between p-4 rounded-xl border border-slate-100 hover:border-primary/30 hover:bg-primary/5 transition-all group"
                              >
                                <div className="flex items-center gap-4">
                                  <div className="bg-white p-2 rounded-lg shadow-sm border border-slate-100">
                                    <Car size={20} className="text-primary" />
                                  </div>
                                  <div>
                                    <div className="text-sm font-bold text-slate-900 flex items-center gap-2">
                                      {ride.carName || 'Eco Ride'}
                                      <div className="flex items-center gap-1 bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full border border-amber-100">
                                        <Star size={10} className="fill-amber-500 text-amber-500" />
                                        <span className="text-[9px] font-black uppercase tracking-tighter">
                                          {t.smartMatchScore}: {ride.matchScore}%
                                        </span>
                                      </div>
                                    </div>
                                    <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                                      <ShieldCheck size={12} className="text-emerald-500" />
                                      {ride.driverVerified ? 'Verified Driver' : 'Community Driver'} • ₹{ride.price}
                                    </div>
                                  </div>
                                </div>
                                <button 
                                  onClick={() => onStartBooking(ride)}
                                  className="px-4 py-2 bg-primary text-white rounded-lg font-bold text-xs shadow-md shadow-blue-100 hover:bg-primary-dark transition-all active:scale-95"
                                >
                                  {t.matchNow}
                                </button>
                              </motion.div>
                            ))}
                          </div>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
