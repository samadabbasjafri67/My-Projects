import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { TrendingUp, DollarSign, Calendar, Target, Award, ChevronRight } from 'lucide-react';
import { User } from '../types';

interface DriverEarningsDashboardProps {
  user: User;
  language: string;
}

export const DriverEarningsDashboard: React.FC<DriverEarningsDashboardProps> = ({ user, language }) => {
  const earnings = user.driverEarnings || {
    today: 0,
    thisWeek: 0,
    thisMonth: 0,
    total: 0,
    weeklyHistory: [
      { day: 'Mon', amount: 0 },
      { day: 'Tue', amount: 0 },
      { day: 'Wed', amount: 0 },
      { day: 'Thu', amount: 0 },
      { day: 'Fri', amount: 0 },
      { day: 'Sat', amount: 0 },
      { day: 'Sun', amount: 0 }
    ]
  };

  const isHindi = language === 'hi';

  const stats = [
    {
      label: isHindi ? 'आज की कमाई' : 'Today\'s Earnings',
      value: `₹${earnings.today}`,
      icon: <DollarSign className="w-5 h-5 text-emerald-600" />,
      sub: isHindi ? 'आज' : 'Today',
      color: 'bg-emerald-50'
    },
    {
      label: isHindi ? 'इस सप्ताह' : 'This Week',
      value: `₹${earnings.thisWeek}`,
      icon: <Calendar className="w-5 h-5 text-blue-600" />,
      sub: isHindi ? '7 दिन' : '7 Days',
      color: 'bg-blue-50'
    },
    {
      label: isHindi ? 'कुल सवारी' : 'Total Rides',
      value: user.totalRides || 0,
      icon: <Target className="w-5 h-5 text-purple-600" />,
      sub: isHindi ? 'लाइफटाइम' : 'Lifetime',
      color: 'bg-purple-50'
    },
    {
      label: isHindi ? 'अनुमानित बोनस' : 'Est. Bonus',
      value: `₹${Math.floor(earnings.thisMonth * 0.05)}`,
      icon: <Award className="w-5 h-5 text-amber-600" />,
      sub: isHindi ? 'अनलॉक करें' : 'Unlock',
      color: 'bg-amber-50'
    }
  ];

  return (
    <div className="bg-white rounded-[2.5rem] p-6 border border-slate-100 shadow-sm space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <TrendingUp className="text-emerald-500" />
            {isHindi ? 'कमाई डैशबोर्ड' : 'Earnings Dashboard'}
          </h3>
          <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mt-1">
            {isHindi ? 'आपका प्रदर्शन इस सप्ताह' : 'Your performance this week'}
          </p>
        </div>
        <button className="p-2 bg-slate-50 rounded-xl text-slate-400 hover:text-slate-600 transition-colors">
          <ChevronRight size={20} />
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, idx) => (
          <div key={idx} className={`${stat.color} p-4 rounded-3xl border border-white shadow-sm hover:scale-[1.02] transition-transform cursor-pointer`}>
            <div className="flex items-center gap-2 mb-3">
              <div className="bg-white p-1.5 rounded-xl shadow-sm">
                {stat.icon}
              </div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{stat.sub}</span>
            </div>
            <div className="text-xl font-black text-slate-900">{stat.value}</div>
            <div className="text-[10px] font-bold text-slate-500 mt-0.5">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">
            {isHindi ? 'साप्ताहिक रुझान' : 'Weekly Trends'}
          </h4>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
              <span className="text-[10px] font-bold text-slate-500">{isHindi ? 'कमाई' : 'Earnings'}</span>
            </div>
          </div>
        </div>

        <div className="h-[250px] w-full bg-slate-50/50 rounded-3xl p-4 border border-slate-50">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={earnings.weeklyHistory}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="day" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
                dy={10}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
              />
              <Tooltip 
                cursor={{ fill: '#f8fafc', radius: 10 }}
                contentStyle={{ 
                  borderRadius: '16px', 
                  border: 'none', 
                  boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                  padding: '12px'
                }}
                labelStyle={{ fontWeight: 900, marginBottom: '4px', fontSize: '10px', textTransform: 'uppercase', color: '#64748b' }}
                itemStyle={{ fontWeight: 900, color: '#059669', fontSize: '14px' }}
              />
              <Bar 
                dataKey="amount" 
                radius={[10, 10, 10, 10]} 
                barSize={32}
              >
                {earnings.weeklyHistory.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={entry.amount > 0 ? '#10b981' : '#e2e8f0'} 
                    className="hover:opacity-80 transition-opacity"
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-indigo-600 p-6 rounded-[2rem] text-white flex justify-between items-center relative overflow-hidden group">
          <div className="relative z-10">
            <h4 className="text-[10px] font-black uppercase tracking-[0.2em] mb-1 opacity-80">
              {isHindi ? 'अगला लक्ष्य' : 'Next Milestone'}
            </h4>
            <div className="text-2xl font-black mb-2">50 {isHindi ? 'सवारी' : 'Rides'}</div>
            <div className="w-48 bg-white/20 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-white h-full transition-all duration-1000" 
                style={{ width: `${Math.min((user.totalRides || 0) / 50 * 100, 100)}%` }}
              ></div>
            </div>
            <p className="text-[10px] font-bold mt-2 opacity-70">
              {isHindi ? '₹500 बोनस पाने के लिए 12 और सवारी' : `${50 - (user.totalRides || 0)} more rides for ₹500 bonus`}
            </p>
          </div>
          <div className="bg-white/10 p-4 rounded-3xl rotate-12 group-hover:rotate-0 transition-transform">
             <Award size={40} className="text-indigo-200" />
          </div>
          <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-white/5 rounded-full blur-2xl"></div>
        </div>

        <div className="bg-slate-900 p-6 rounded-[2rem] text-white flex flex-col justify-center relative overflow-hidden">
           <h4 className="text-[10px] font-black uppercase tracking-[0.2em] mb-1 opacity-60">
             {isHindi ? 'कुल संचित बचत' : 'Total Lifetime Savings'}
           </h4>
           <div className="text-3xl font-black text-emerald-400">₹{earnings.total}</div>
           <p className="text-[10px] font-bold text-slate-400 mt-2">
             {isHindi ? 'आपने इको-फ्रेंडली सवारी के माध्यम से कमाया है' : 'Earned through eco-friendly riding strategy'}
           </p>
           <div className="absolute right-0 top-0 w-24 h-24 bg-emerald-500/10 blur-[60px]"></div>
        </div>
      </div>
    </div>
  );
};
