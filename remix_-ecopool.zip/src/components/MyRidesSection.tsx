import React from 'react';
import { Navigation, Phone, MessageSquare, Check, CheckCheck } from 'lucide-react';
import { TRANSLATIONS, AMENITIES } from '../constants';
import { Ride, Booking, Rating, ChatMessage, User } from '../types';
import { LiveTracking } from './LiveTracking';
import { LoadingSpinner } from './LoadingSpinner';
import { RideReceiptModal } from './RideReceiptModal';
import { db, collection, query, where, onSnapshot, doc, getDoc, getDocs, updateDoc, addDoc, handleFirestoreError, OperationType } from '../firebase';
import { FraudService } from '../services/fraudService';

interface MyRidesSectionProps {
  currentUser: string;
  showNotification: (msg: string, color?: string) => void;
  generateOTP: (bookingId: string, rideId: string | number, passenger: string, driver: string) => Promise<string>;
  verifyOTP: (bookingId: string, enteredOTP: string) => Promise<{ success: boolean; message: string }>;
  submitRating: (data: any) => Promise<boolean>;
  getDriverRatingSummary: (username: string) => any;
  getRideRatings: (rideId: string | number) => Rating[];
  canUserRateRide: (rideId: string | number, role: string, otherUser: string) => any;
  sendChatMessage: (rideId: string | number, sender: string, receiver: string, msg: string) => Promise<boolean>;
  getChatMessages: (rideId: string | number, u1: string, u2: string, callback: (msgs: ChatMessage[]) => void) => () => void;
  language: string;
}

import { NotificationService } from '../services/notificationService';
import { DriverSimulationService } from '../services/driverSimulationService';

export const MyRidesSection: React.FC<MyRidesSectionProps> = ({
  currentUser,
  showNotification,
  generateOTP,
  verifyOTP,
  submitRating,
  getDriverRatingSummary,
  getRideRatings,
  canUserRateRide,
  sendChatMessage,
  getChatMessages,
  language
}) => {
  const [myRides, setMyRides] = React.useState<any[]>([]);
  const [activeTab, setActiveTab] = React.useState("offered");
  const [historyRides, setHistoryRides] = React.useState<any[]>([]);
  const [driverOTPInput, setDriverOTPInput] = React.useState(["", "", "", "", "", ""]);
  const [otpVerificationResult, setOtpVerificationResult] = React.useState<any>(null);
  const [showRatingModal, setShowRatingModal] = React.useState(false);
  const [ratingData, setRatingData] = React.useState<any>(null);
  const [showChat, setShowChat] = React.useState(false);
  const [chatRide, setChatRide] = React.useState<any>(null);
  const [chatMessages, setChatMessages] = React.useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = React.useState("");
  const [showDriverContact, setShowDriverContact] = React.useState<string | null>(null);
  const [driverProfiles, setDriverProfiles] = React.useState<{[key: string]: User}>({});
  const [trackingInfo, setTrackingInfo] = React.useState<{ ride: Ride; bookingId?: string } | null>(null);
  const [showCancelModal, setShowCancelModal] = React.useState(false);
  const [cancelReason, setCancelReason] = React.useState("");
  const [bookingToCancel, setBookingToCancel] = React.useState<{ bookingId: string; rideId: string; seats: number } | null>(null);
  const [rideToCancel, setRideToCancel] = React.useState<Ride | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [isActionLoading, setIsActionLoading] = React.useState(false);
  const [unreadCounts, setUnreadCounts] = React.useState<{[key: string]: number}>({});
  const [showReceiptModal, setShowReceiptModal] = React.useState(false);
  const [selectedBookingForReceipt, setSelectedBookingForReceipt] = React.useState<any>(null);
  const chatUnsubscribeRef = React.useRef<(() => void) | null>(null);

  const [scheduledReminders, setScheduledReminders] = React.useState<any[]>([]);

  React.useEffect(() => {
    try {
      const stored = localStorage.getItem('ecopool_active_reminders');
      if (stored) {
        setScheduledReminders(JSON.parse(stored));
      }
    } catch (e) {
      console.error("Error reading reminders from localStorage", e);
    }
  }, []);

  const hasReminder = (rideId: string | number) => {
    return scheduledReminders.some(rem => rem.rideId === rideId && rem.userId === currentUser && !rem.notified);
  };

  const handleToggleReminder = async (ride: any) => {
    try {
      const permission = await NotificationService.requestPermission(currentUser);
      if (!permission) {
        showNotification(t.reminderPermissionRequired || "Notification permission is required to set reminders.", "#e53935");
        return;
      }

      const rideId = ride.id;
      const isAlreadySet = hasReminder(rideId);

      let updatedReminders = [...scheduledReminders];

      if (isAlreadySet) {
        // Cancel reminder
        updatedReminders = updatedReminders.filter(rem => !(rem.rideId === rideId && rem.userId === currentUser));
        localStorage.setItem('ecopool_active_reminders', JSON.stringify(updatedReminders));
        setScheduledReminders(updatedReminders);
        showNotification(t.reminderCancelled || "Reminder cancelled for this ride.", "#ff9800");
      } else {
        // Set reminder
        const departureStr = `${ride.date}T${ride.time}`;
        const departureTime = new Date(departureStr);
        const now = Date.now();

        if (isNaN(departureTime.getTime())) {
          showNotification(language === 'hi' ? "अमान्य प्रस्थान समय!" : "Invalid departure date/time!", "#e53935");
          return;
        }

        if (departureTime.getTime() <= now) {
          showNotification(language === 'hi' ? "यह सवारी पहले ही प्रस्थान कर चुकी है!" : "This ride has already departed!", "#e53935");
          return;
        }

        const oneHourMs = 1 * 60 * 60 * 1000;
        const targetTime = departureTime.getTime() - oneHourMs;

        // If departure in < 1 hour, trigger soon/now
        const resolvedTargetTime = targetTime < now ? now : targetTime;

        const newReminder = {
          rideId,
          userId: currentUser,
          from: ride.from,
          to: ride.to,
          date: ride.date,
          time: ride.time,
          targetTime: resolvedTargetTime,
          notified: false
        };

        updatedReminders.push(newReminder);
        localStorage.setItem('ecopool_active_reminders', JSON.stringify(updatedReminders));
        setScheduledReminders(updatedReminders);

        if (resolvedTargetTime === now) {
          showNotification(language === 'hi' ? "स्मरणपत्र तैयार! सवारी 1 घंटे से भी कम समय में प्रस्थान करेगी।" : "Reminder set! The ride departs in less than an hour.", "#10b981");
        } else {
          showNotification(t.reminderSet || "Reminder set! We will notify you 1 hour before departure.", "#10b981");
        }
      }
    } catch (e) {
      console.error("Error toggling reminder", e);
      showNotification("Error toggling reminder", "#e53935");
    }
  };

  // Sync simulations for offered rides
  React.useEffect(() => {
    if (activeTab === "offered" && myRides.length > 0) {
      DriverSimulationService.syncAllActiveSimulations(myRides);
    }
    return () => {
      // Clear/Stop simulation intervals for these rides on clean up
      if (myRides && myRides.length > 0) {
        myRides.forEach(r => {
          DriverSimulationService.stopSimulation(String(r.id));
        });
      }
    };
  }, [myRides, activeTab]);

  const toggleDriverContact = async (ride: any) => {
    if (showDriverContact === ride.id) {
      setShowDriverContact(null);
      return;
    }
    
    setShowDriverContact(ride.id);
    
    // If driver profile not already fetched, fetch it
    if (!driverProfiles[ride.driver] && ride.driver) {
      try {
        const userDoc = await getDoc(doc(db, 'users', ride.driver));
        if (userDoc.exists()) {
          setDriverProfiles(prev => ({
            ...prev,
            [ride.driver]: userDoc.data() as User
          }));
        }
      } catch (error) {
        console.error("Error fetching driver profile:", error);
      }
    }
  };

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  React.useEffect(() => {
    let unsubscribeRides: () => void;
    let unsubscribeBookings: () => void;

    if (activeTab === "offered") {
      setLoading(true);
      const qRides = query(collection(db, 'rides'), where('driver', '==', currentUser));
      unsubscribeRides = onSnapshot(qRides, (rideSnapshot) => {
        const rides = rideSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Ride));
        
        // Query bookings where current user is the driver
        const qBookings = query(collection(db, 'bookings'), where('driverId', '==', currentUser));
        unsubscribeBookings = onSnapshot(qBookings, (bookingSnapshot) => {
          const bookings = bookingSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
          
          const enhancedRides = rides.map(ride => {
            const rideBookings = bookings.filter(b => b.rideId === ride.id);
            const enhancedBookings = rideBookings.map(b => {
              return {
                name: b.passengerName || 'User',
                passengerId: b.passenger,
                seats: b.seats,
                pickup: b.ride?.from || '',
                drop: b.ride?.to || '',
                bookingId: b.id,
                pickupStatus: b.pickupStatus || 'scheduled',
                otp: b.otp,
                otpVerified: b.pickupStatus === 'verified',
                otpExpiry: b.otpExpiry,
                isVerified: b.passengerVerified || false,
                profilePhoto: b.passengerPhoto || null,
                selectedSeats: b.selectedSeats || null,
                selectedSeatLabels: b.selectedSeatLabels || null,
                seatGenders: b.seatGenders || null
              };
            });
            return { ...ride, bookings: enhancedBookings };
          });
          
          // Filter for upcoming offered rides
          const today = new Date().toISOString().split('T')[0];
          const upcomingOffered = enhancedRides.filter(r => r.date >= today);
          setMyRides(upcomingOffered);
          setLoading(false);
        }, (error) => {
          handleFirestoreError(error, OperationType.LIST, 'bookings');
          setLoading(false);
        });
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'rides');
        setLoading(false);
      });
    } else if (activeTab === "booked") {
      setLoading(true);
      const qBookings = query(collection(db, 'bookings'), where('passenger', '==', currentUser));
      unsubscribeBookings = onSnapshot(qBookings, (bookingSnapshot) => {
        const bookings = bookingSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
        const enhancedBookedRides = bookings.map(b => {
          const ride = b.ride;
          return {
            ...ride,
            id: b.rideId,
            userBooking: {
              seats: b.seats,
              pickup: ride?.from,
              bookingId: b.id,
              pickupStatus: b.pickupStatus || 'scheduled',
              otp: b.otp,
              otpVerified: b.pickupStatus === 'verified',
              otpExpiry: b.otpExpiry,
              status: b.status || 'confirmed',
              selectedSeats: b.selectedSeats || null,
              selectedSeatLabels: b.selectedSeatLabels || null,
              seatGenders: b.seatGenders || null
            }
          };
        });
        
        // Filter for upcoming booked rides
        const today = new Date().toISOString().split('T')[0];
        const upcomingBooked = enhancedBookedRides.filter(r => r.date >= today && r.userBooking.status !== 'cancelled');
        setMyRides(upcomingBooked);
        setLoading(false);
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'bookings');
        setLoading(false);
      });
    } else if (activeTab === "history") {
      setLoading(true);
      // Fetch all bookings for the user (as passenger)
      const qBookings = query(collection(db, 'bookings'), where('passenger', '==', currentUser));
      unsubscribeBookings = onSnapshot(qBookings, (bookingSnapshot) => {
        const bookings = bookingSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
        const enhancedHistoryRides = bookings.map(b => {
          const ride = b.ride;
          return {
            ...ride,
            id: b.rideId,
            price: b.totalPrice || ride?.price,
            userBooking: {
              seats: b.seats,
              pickup: ride?.from,
              bookingId: b.id,
              status: b.status || 'confirmed',
              selectedSeats: b.selectedSeats || null,
              selectedSeatLabels: b.selectedSeatLabels || null,
              seatGenders: b.seatGenders || null
            }
          };
        });
        
        // Filter for past or cancelled rides
        const today = new Date().toISOString().split('T')[0];
        const pastRides = enhancedHistoryRides.filter(r => r.date < today || r.userBooking.status === 'cancelled');
        // Sort by date descending
        pastRides.sort((a, b) => b.date.localeCompare(a.date));
        setHistoryRides(pastRides);
        setLoading(false);
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'bookings');
        setLoading(false);
      });
    }

    return () => {
      if (unsubscribeRides) unsubscribeRides();
      if (unsubscribeBookings) unsubscribeBookings();
      if (chatUnsubscribeRef.current) chatUnsubscribeRef.current();
    };
  }, [activeTab, currentUser]);

  React.useEffect(() => {
    if (!currentUser) return;
    const qUnread = query(
      collection(db, 'chats'),
      where('receiver', '==', currentUser),
      where('read', '==', false)
    );
    const unsubscribe = onSnapshot(qUnread, (snapshot) => {
      const counts: {[key: string]: number} = {};
      let totalUnread = 0;
      snapshot.docs.forEach(doc => {
        const data = doc.data();
        const key = `${data.rideId}_${data.sender}`;
        counts[key] = (counts[key] || 0) + 1;
        totalUnread++;
      });

      // If new messages arrived (totalUnread increased and not first load)
      const prevTotal = Object.values(unreadCounts).reduce((acc: number, curr: number) => acc + curr, 0) as number;
      if (totalUnread > prevTotal && prevTotal !== 0) {
        const latestMsg = snapshot.docs[snapshot.docs.length - 1]?.data();
        if (latestMsg) {
          NotificationService.sendNotification(language === 'hi' ? 'नया संदेश' : 'New Message', {
            body: latestMsg.message,
            tag: `chat_${latestMsg.rideId}`
          } as any);
        }
      }

      setUnreadCounts(counts);
    }, (error) => {
      console.error("Error listening to unread messages:", error);
    });
    return () => unsubscribe();
  }, [currentUser]);

  const markMessagesAsRead = async (rideId: string | number, otherUser: string) => {
    const qUnread = query(
      collection(db, 'chats'),
      where('rideId', '==', rideId),
      where('sender', '==', otherUser),
      where('receiver', '==', currentUser),
      where('read', '==', false)
    );
    try {
      const snapshot = await getDocs(qUnread);
      if (snapshot.empty) return;
      
      const { writeBatch } = await import('../firebase');
      const batch = writeBatch(db);
      snapshot.docs.forEach(d => {
        batch.update(d.ref, { read: true });
      });
      await batch.commit();
    } catch (error) {
      console.error("Error marking messages as read:", error);
    }
  };

  React.useEffect(() => {
    const fetchDriverProfiles = async () => {
      const allRides = [...myRides, ...historyRides];
      const driverIds = Array.from(new Set(allRides.map(r => r.driver)));
      const missingIds = driverIds.filter(id => !driverProfiles[id]);
      
      if (missingIds.length === 0) return;
      
      const newProfiles = { ...driverProfiles };
      let updated = false;
      for (const id of missingIds) {
        try {
          const userDoc = await getDoc(doc(db, 'users', id));
          if (userDoc.exists()) {
            newProfiles[id] = userDoc.data() as User;
            updated = true;
          }
        } catch (error) {
          console.error("Error fetching driver profile:", error);
        }
      }
      if (updated) {
        setDriverProfiles(newProfiles);
      }
    };
    
    if (myRides.length > 0 || historyRides.length > 0) {
      fetchDriverProfiles();
    }
  }, [myRides, historyRides, driverProfiles]);

  const handleGenerateOTP = async (ride: Ride, passengerName: string, passengerId: string) => {
    const booking = myRides.find(r => r.id === ride.id)?.bookings.find((b: any) => b.passengerId === passengerId);
    if (!booking) {
      showNotification("Booking record not found!", "#e53935");
      return;
    }
    await generateOTP(booking.bookingId, ride.id, passengerId, currentUser);
    showNotification(`OTP generated for ${passengerName}. The passenger has been notified.`, "#43a047");
  };

  const handleVerifyOTP = async (bookingId: string) => {
    const enteredOTP = driverOTPInput.join('');
    if (enteredOTP.length !== 6) {
      setOtpVerificationResult({ success: false, message: "Please enter 6-digit OTP" });
      return;
    }
    setIsActionLoading(true);
    try {
      const result = await verifyOTP(bookingId, enteredOTP);
      setOtpVerificationResult(result);
      if (result.success) {
        setDriverOTPInput(["", "", "", "", "", ""]);
      }
    } finally {
      setIsActionLoading(false);
    }
  };

  const openChat = (ride: Ride, otherUser: string, otherUserName?: string) => {
    if (chatUnsubscribeRef.current) {
      chatUnsubscribeRef.current();
    }
    const resolvedName = otherUserName || driverProfiles[otherUser]?.username || 'User';
    setChatRide({ ride, otherUser, otherUserName: resolvedName });
    chatUnsubscribeRef.current = getChatMessages(ride.id, currentUser, otherUser, (msgs) => {
      setChatMessages(msgs);
      // Mark as read when messages arrive and modal is open
      markMessagesAsRead(ride.id, otherUser);
    });
    setShowChat(true);
  };

  const closeChat = () => {
    if (chatUnsubscribeRef.current) {
      chatUnsubscribeRef.current();
      chatUnsubscribeRef.current = null;
    }
    setShowChat(false);
    setChatRide(null);
    setChatMessages([]);
  };

  const handleSendMessage = async () => {
    if (!chatInput.trim() || !chatRide) return;
    setIsActionLoading(true);
    try {
      await sendChatMessage(chatRide.ride.id, currentUser, chatRide.otherUser, chatInput);
      setChatInput("");
    } finally {
      setIsActionLoading(false);
    }
  };

  const updateJourneyStatus = async (bookingId: string, newStatus: string) => {
    setIsActionLoading(true);
    try {
      const updates: any = {
        pickupStatus: newStatus,
        statusUpdatedAt: new Date().toISOString()
      };
      
      if (newStatus === 'ended') {
        updates.status = 'completed';
        
        // Update earnings for driver
        const driverDoc = await getDoc(doc(db, 'users', currentUser));
        if (driverDoc.exists()) {
          const driverData = driverDoc.data() as User;
          const bookingDoc = await getDoc(doc(db, 'bookings', bookingId));
          const bookingData = bookingDoc.data() as Booking;
          const amount = bookingData.totalPrice || 0;
          
          // Apply commission based on subscription plan
          const planId = driverData.subscription?.plan || 'free';
          let commissionRate = 0.15; // default 15%
          if (planId === 'basic') commissionRate = 0.10; // 10%
          else if (planId === 'premium') commissionRate = 0.0; // 0%
          
          const commissionAmount = amount * commissionRate;
          const netAmount = amount - commissionAmount;
          
          const earnings = driverData.driverEarnings || {
            today: 0,
            thisWeek: 0,
            thisMonth: 0,
            total: 0,
            weeklyHistory: [
              { day: 'Mon', amount: 0 },
              { day: 'Tue', amount: 0 },
              { day: 'Wed', amount: 0 },
              { day: 'Thu', amount: 0 },
              { day: 'Fri', amount: 0 },
              { day: 'Sat', amount: 0 },
              { day: 'Sun', amount: 0 }
            ]
          };

          const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
          const todayName = days[new Date().getDay()];
          const historyIndex = earnings.weeklyHistory.findIndex((h: any) => h.day === todayName);
          
          if (historyIndex !== -1) {
            const newHistory = [...earnings.weeklyHistory];
            newHistory[historyIndex].amount += netAmount;
            earnings.weeklyHistory = newHistory;
          }

          earnings.today += netAmount;
          earnings.thisWeek += netAmount;
          earnings.thisMonth += netAmount;
          earnings.total += netAmount;

          await updateDoc(doc(db, 'users', currentUser), {
            driverEarnings: earnings,
            totalRides: (driverData.totalRides || 0) + 1
          });
        }
      }
      
      await updateDoc(doc(db, 'bookings', bookingId), updates);
      showNotification(language === 'hi' ? 'स्थिति अपडेट की गई' : "Status updated successfully");
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `bookings/${bookingId}`);
      showNotification(language === 'hi' ? 'अपडेट विफल रहा' : "Update failed", "#e53935");
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleCancelBooking = async () => {
    if ((!bookingToCancel && !rideToCancel) || !cancelReason.trim()) {
      showNotification(language === 'hi' ? 'कृपया रद्द करने का कारण बताएं' : "Please provide a reason for cancellation", "#e53935");
      return;
    }

    try {
      if (rideToCancel) {
        // Driver cancelling the entire ride
        // 1. Update ride status
        await updateDoc(doc(db, 'rides', rideToCancel.id as string), {
          status: 'cancelled',
          cancelReason: cancelReason,
          cancelledAt: new Date().toISOString()
        });

        // 2. Update all bookings for this ride
        const q = query(collection(db, 'bookings'), where('rideId', '==', rideToCancel.id));
        const snapshot = await getDocs(q);
        const batchPromises = snapshot.docs.map(bDoc => 
          updateDoc(doc(db, 'bookings', bDoc.id), {
            status: 'cancelled',
            cancelReason: `Driver cancelled: ${cancelReason}`,
            cancelledAt: new Date().toISOString(),
            cancelledBy: currentUser
          })
        );
        await Promise.all(batchPromises);

        // 3. Dispatch Brevo cancellation emails to all affected passengers in background
        snapshot.docs.forEach(async (bDoc) => {
          const bData = bDoc.data();
          if (bData.status === 'cancelled') return; // already cancelled
          
          try {
            let PassengerEmail = "";
            let PassengerName = bData.passengerName || "Customer";
            
            const pSnap = await getDoc(doc(db, 'users', bData.passenger));
            if (pSnap.exists()) {
              PassengerEmail = pSnap.data().email || "";
              PassengerName = pSnap.data().username || PassengerName;
            }

            let DriverEmail = rideToCancel.driverEmail || "";
            let DriverName = rideToCancel.driverName || "Driver";
            
            const dSnap = await getDoc(doc(db, 'users', rideToCancel.driver));
            if (dSnap.exists()) {
              DriverEmail = dSnap.data().email || DriverEmail;
              DriverName = dSnap.data().username || DriverName;
            }

            if (PassengerEmail || DriverEmail) {
              const bDetails = bData || {};
              const rDetails = bDetails.ride || {};
              const prunedBooking = {
                id: bDoc.id,
                type: bDetails.type,
                pickupLocation: bDetails.pickupLocation || rDetails.from,
                dropLocation: bDetails.dropLocation || rDetails.to,
                totalPrice: bDetails.totalPrice || rDetails.price,
                seats: bDetails.seats,
                selectedSeatLabels: bDetails.selectedSeatLabels,
                specialRequests: bDetails.specialRequests,
                parcelInfo: bDetails.parcelInfo,
                ride: {
                  from: rDetails.from,
                  to: rDetails.to,
                  date: rDetails.date,
                  time: rDetails.time,
                  price: rDetails.price,
                  carName: rDetails.carName,
                  vehicleNumber: rDetails.vehicleNumber
                }
              };

              await fetch("/api/send-booking-notification", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  type: "cancelled_by_driver",
                  booking: prunedBooking,
                  passenger: { name: PassengerName, email: PassengerEmail },
                  driver: { name: DriverName, email: DriverEmail },
                  cancelReason: cancelReason
                })
              });
            }
          } catch (e) {
            console.error("Error sending Brevo cancellation email to passenger on driver cancellation:", e);
          }
        });

        showNotification(language === 'hi' ? 'सवारी सफलतापूर्वक रद्द कर दी गई' : "Ride cancelled successfully");
        
        // Fraud check: Record cancellation for driver
        await FraudService.recordCancellation(currentUser, cancelReason);
      } else if (bookingToCancel) {
        // Passenger cancelling their booking
        // Retrieve booking first to get passenger and driver details
        const bookingSnap = await getDoc(doc(db, 'bookings', bookingToCancel.bookingId));
        let bookingDetailsData: any = null;
        if (bookingSnap.exists()) {
          bookingDetailsData = bookingSnap.data();
        }

        // 1. Update booking status
        await updateDoc(doc(db, 'bookings', bookingToCancel.bookingId), {
          status: 'cancelled',
          cancelReason: cancelReason,
          cancelledAt: new Date().toISOString(),
          cancelledBy: currentUser
        });

        // 2. Increment seats back in the ride
        const rideDoc = await getDoc(doc(db, 'rides', bookingToCancel.rideId));
        if (rideDoc.exists()) {
          const currentSeats = rideDoc.data().seats || 0;
          await updateDoc(doc(db, 'rides', bookingToCancel.rideId), {
            seats: currentSeats + bookingToCancel.seats
          });
        }

        // 3. Dispatch Brevo cancellation emails to both passenger and driver in background
        if (bookingDetailsData) {
          try {
            const sendPromise = async () => {
              let PassengerEmail = "";
              let PassengerName = bookingDetailsData.passengerName || "Customer";
              const pSnap = await getDoc(doc(db, 'users', bookingDetailsData.passenger));
              if (pSnap.exists()) {
                PassengerEmail = pSnap.data().email || "";
                PassengerName = pSnap.data().username || PassengerName;
              }

              let DriverEmail = bookingDetailsData.ride?.driverEmail || "";
              let DriverName = bookingDetailsData.ride?.driverName || "Driver";
              const dSnap = await getDoc(doc(db, 'users', bookingDetailsData.driverId));
              if (dSnap.exists()) {
                DriverEmail = dSnap.data().email || DriverEmail;
                DriverName = dSnap.data().username || DriverName;
              }

              if (PassengerEmail || DriverEmail) {
                const bDetails = bookingDetailsData || {};
                const rDetails = bDetails.ride || {};
                const prunedBooking = {
                  id: bookingSnap.id,
                  type: bDetails.type,
                  pickupLocation: bDetails.pickupLocation || rDetails.from,
                  dropLocation: bDetails.dropLocation || rDetails.to,
                  totalPrice: bDetails.totalPrice || rDetails.price,
                  seats: bDetails.seats,
                  selectedSeatLabels: bDetails.selectedSeatLabels,
                  specialRequests: bDetails.specialRequests,
                  parcelInfo: bDetails.parcelInfo,
                  ride: {
                    from: rDetails.from,
                    to: rDetails.to,
                    date: rDetails.date,
                    time: rDetails.time,
                    price: rDetails.price,
                    carName: rDetails.carName,
                    vehicleNumber: rDetails.vehicleNumber
                  }
                };

                await fetch("/api/send-booking-notification", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    type: "cancelled_by_passenger",
                    booking: prunedBooking,
                    passenger: { name: PassengerName, email: PassengerEmail },
                    driver: { name: DriverName, email: DriverEmail },
                    cancelReason: cancelReason
                  })
                });
              }
            };
            sendPromise().catch(e => console.error("Error sending passenger cancellation email:", e));
          } catch (e) {
            console.error("Failed to dispatch cancellation mail to Brevo:", e);
          }
        }

        showNotification(language === 'hi' ? 'बुकिंग सफलतापूर्वक रद्द कर दी गई' : "Booking cancelled successfully");
        
        // Fraud check: Record cancellation for passenger
        await FraudService.recordCancellation(currentUser, cancelReason);
      }

      setShowCancelModal(false);
      setCancelReason("");
      setBookingToCancel(null);
      setRideToCancel(null);
    } catch (error) {
      showNotification(language === 'hi' ? 'रद्द करने में विफल' : "Failed to cancel", "#e53935");
    }
  };

  const handleShareRide = async (ride: Ride) => {
    const shareTitle = t.shareText;
    const shareText = `${t.shareText}\n\n🚗 ${ride.from} → ${ride.to}\n📅 ${ride.date} at ${ride.time}\n💰 ₹${ride.price}\n👤 Driver: ${ride.driver}\n\nJoin me on EcoPool!`;
    const shareUrl = window.location.origin;

    const copyToClipboard = async () => {
      try {
        await navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
        showNotification(t.rideShared);
      } catch (err) {
        console.error("Error copying to clipboard:", err);
        showNotification(language === 'hi' ? 'साझा करने में विफल' : "Failed to share", "#e53935");
      }
    };

    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl,
        });
      } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') {
          // Silently handle user cancellation
          return;
        }
        console.error("Error sharing:", err);
        // Fallback to clipboard on error (like permission issues in iframe)
        await copyToClipboard();
      }
    } else {
      await copyToClipboard();
    }
  };

  const openRatingModal = (ride: Ride, userToRate: string, userRole: string) => {
    setRatingData({
      rideId: ride.id,
      rideFrom: ride.from,
      rideTo: ride.to,
      rideDate: ride.date,
      ratedUser: userToRate,
      userRole: userRole,
      overall: 0, punctuality: 0, driving: 0, vehicle: 0, behavior: 0, review: ""
    });
    setShowRatingModal(true);
  };

  const handleSubmitRatingData = async () => {
    if (!ratingData.overall) {
      showNotification("Please provide an overall rating!", "#e53935");
      return;
    }
    if (await submitRating(ratingData)) {
      setShowRatingModal(false);
      setRatingData(null);
    }
  };

  return (
    <div id="myRidesSection">
      <h2 className="text-xl font-bold mb-4">{t.myRides}</h2>
      
      <div className="tab-buttons mb-6">
        <button
          className={`tab-button ${activeTab === 'offered' ? 'active' : ''}`}
          onClick={() => setActiveTab("offered")}
        >
          {language === 'hi' ? 'सवारियां जो मैं दे रहा हूँ' : "Rides I'm Offering"}
        </button>
        <button
          className={`tab-button ${activeTab === 'booked' ? 'active' : ''}`}
          onClick={() => setActiveTab("booked")}
        >
          {language === 'hi' ? 'सवारियां जो मैंने बुक की हैं' : "Rides I've Booked"}
        </button>
        <button
          className={`tab-button ${activeTab === 'history' ? 'active' : ''}`}
          onClick={() => setActiveTab("history")}
        >
          {t.rideHistory}
        </button>
      </div>

      {/* Live Tracking Modal */}
      {trackingInfo && (
        <LiveTracking 
          ride={trackingInfo.ride} 
          currentUser={currentUser} 
          role={trackingInfo.ride.driver === currentUser ? 'driver' : 'passenger'} 
          bookingId={trackingInfo.bookingId}
          onClose={() => setTrackingInfo(null)} 
          language={language}
        />
      )}

      {/* Receipt Modal */}
      {showReceiptModal && selectedBookingForReceipt && (
        <RideReceiptModal 
          booking={selectedBookingForReceipt}
          language={language}
          onClose={() => {
            setShowReceiptModal(false);
            setSelectedBookingForReceipt(null);
          }}
        />
      )}

      <div id="myRidesList">
        {loading ? (
          <div className="py-20">
            <LoadingSpinner label={language === 'hi' ? 'सवारियां लोड की जा रही हैं...' : 'Loading your rides...'} />
          </div>
        ) : (
          activeTab === "history" ? (
          historyRides.length === 0 ? (
            <p className="text-center text-gray-500 py-10">{t.noPastRides}</p>
          ) : (
            historyRides.map(r => (
              <div key={r.userBooking?.bookingId || r.id} className="ride-card opacity-80">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      {r.from} → {r.to}
                    </h3>
                    <p className="text-sm text-gray-600">{r.date} {language === 'hi' ? 'को' : 'at'} {r.time}</p>
                    <div className="mt-1 flex items-center gap-2">
                      <span className="bg-blue-50 text-blue-700 text-[10px] px-2 py-0.5 rounded-full border border-blue-100 font-bold">
                        🚗 {driverProfiles[r.driver]?.totalRides || 0} {t.ridesCompleted}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-lg text-gray-700">₹{r.price}</div>
                    <div className={`text-[10px] uppercase font-bold ${r.userBooking?.status === 'cancelled' || r.status === 'cancelled' ? 'text-red-600' : 'text-gray-500'}`}>
                      {r.userBooking?.status || r.status}
                    </div>
                    {r.userBooking?.status === 'completed' && (
                      <button 
                        onClick={() => {
                          setSelectedBookingForReceipt(r);
                          setShowReceiptModal(true);
                        }}
                        className="mt-1 text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline flex items-center gap-1 justify-end"
                      >
                        📄 {language === 'hi' ? 'रसीद देखें' : 'View Receipt'}
                      </button>
                    )}
                  </div>
                </div>
                {(r.userBooking?.status === 'cancelled' || r.status === 'cancelled') && (r.userBooking?.cancelReason || r.cancelReason) && (
                  <div className="mt-2 p-2 bg-red-50 border border-red-100 rounded text-[10px] text-red-700">
                    <span className="font-bold">{language === 'hi' ? 'रद्द करने का कारण:' : 'Cancellation Reason:'}</span> {r.userBooking?.cancelReason || r.cancelReason}
                  </div>
                )}
                <div className="mt-2 text-xs text-gray-500 flex justify-between items-center">
                  <span>{t.driver}: {r.driver}</span>
                  <button 
                    className="text-blue-600 font-bold hover:underline"
                    onClick={() => openRatingModal(r, r.driver, 'driver')}
                  >
                    ⭐ {language === 'hi' ? 'रेट करें' : 'Rate'}
                  </button>
                </div>
              </div>
            ))
          )
        ) : myRides.length === 0 ? (
          <p className="text-center text-gray-500 py-10">
            {language === 'hi' 
              ? (activeTab === "offered" ? "कोई सवारी पेश नहीं की गई।" : "कोई सवारी बुक नहीं की गई।")
              : `No ${activeTab === "offered" ? "rides offered" : "rides booked"}.`
            }
          </p>
        ) : (
          myRides.map(r => (
            <div key={r.userBooking?.bookingId || r.id} className={`ride-card ${r.isEV ? 'ev-ride' : ''} ${r.womenOnly ? 'women-only' : ''}`}>
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="text-lg font-bold flex items-center gap-2">
                    {r.from} → {r.to}
                    {r.womenOnly && <span className="text-pink-500">👩‍💼</span>}
                    {r.isEV && <span className="bg-green-500 text-white text-[10px] px-2 py-0.5 rounded-full">EV</span>}
                  </h3>
                  <p className="text-sm text-gray-600">{r.date} {language === 'hi' ? 'को' : 'at'} {r.time}</p>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="bg-blue-50 text-blue-700 text-[10px] px-2 py-0.5 rounded-full border border-blue-100 font-bold">
                      🚗 {driverProfiles[r.driver]?.totalRides || 0} {t.ridesCompleted}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col gap-2 items-end">
                  <button 
                    className="bg-gray-100 text-gray-700 text-[10px] py-1 px-2 rounded flex items-center gap-1 hover:bg-gray-200"
                    onClick={() => handleShareRide(r)}
                  >
                    🔗 {t.shareRide}
                  </button>
                  {activeTab === "booked" && (
                    <button className="text-xs py-1 px-3 relative" onClick={() => openChat(r, r.driver, r.driverName || driverProfiles[r.driver]?.username || 'Driver')}>
                      {language === 'hi' ? 'ड्राइवर के साथ चैट करें' : 'Chat with Driver'}
                      {unreadCounts[`${r.id}_${r.driver}`] > 0 && (
                        <span className="absolute -top-2 -right-2 bg-red-500 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-sm font-black">
                          {unreadCounts[`${r.id}_${r.driver}`]}
                        </span>
                      )}
                    </button>
                  )}
                  {activeTab === "offered" && (
                    <button 
                      className="text-red-600 text-[10px] font-bold hover:underline"
                      onClick={() => {
                        setRideToCancel(r);
                        setShowCancelModal(true);
                      }}
                    >
                      {language === 'hi' ? 'सवारी रद्द करें' : 'Cancel Ride'}
                    </button>
                  )}
                </div>
              </div>

              {activeTab === "offered" ? (
                <div className="mt-4">
                  <h4 className="font-bold text-sm mb-2">{language === 'hi' ? 'बुकिंग:' : 'Bookings:'}</h4>
                  {r.bookings && r.bookings.length > 0 ? (
                    r.bookings.map((b: any, idx: number) => (
                      <div key={idx} className="bg-white p-3 rounded-lg border mb-2 shadow-sm">
                        <div className="flex justify-between items-center mb-2">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center font-bold text-blue-700">
                              {b.profilePhoto ? <img src={b.profilePhoto} className="w-full h-full rounded-full" /> : b.name.charAt(0).toUpperCase()}
                            </div>
                            <span className="font-semibold">{b.name}</span>
                            {b.isVerified && <span className="text-green-600 text-[10px]">✓ {t.verified}</span>}
                          </div>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${b.status === 'cancelled' ? 'bg-red-100 text-red-800' : b.pickupStatus === 'verified' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
                            {b.status === 'cancelled' ? (language === 'hi' ? 'रद्द' : 'Cancelled') : b.pickupStatus === 'verified' ? (language === 'hi' ? 'सत्यापित' : 'Verified') : (language === 'hi' ? 'लंबित' : 'Pending')}
                          </span>
                          {b.passengerReady && !b.otpVerified && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-green-600 text-white animate-pulse">
                              {language === 'hi' ? 'तैयार' : 'Ready'}
                            </span>
                          )}
                        </div>
                        {b.status === 'cancelled' && b.cancelReason && (
                          <div className="mb-2 p-2 bg-red-50 border border-red-100 rounded text-[10px] text-red-700">
                            <span className="font-bold">{language === 'hi' ? 'रद्द करने का कारण:' : 'Cancellation Reason:'}</span> {b.cancelReason}
                          </div>
                        )}
                        <p className="text-xs text-gray-600 mb-2">{b.seats} {language === 'hi' ? 'सीट(ें)' : 'seat(s)'} | {t.from}: {b.pickup} → {t.to}: {b.drop}</p>
                        
                        {b.selectedSeatLabels && Array.isArray(b.selectedSeatLabels) && b.selectedSeatLabels.length > 0 && (
                          <div className="flex flex-wrap gap-1.5 mb-2.5 items-center">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-50 border border-slate-100 rounded px-1.5 py-0.5">
                              💺 {language === 'hi' ? 'सीटें:' : 'Seats:'}
                            </span>
                            {b.selectedSeatLabels.map((label: string, index: number) => {
                              const seatId = b.selectedSeats ? b.selectedSeats[index] : '';
                              const gender = b.seatGenders && seatId ? b.seatGenders[seatId] : 'any';
                              
                              let genderLabel = "";
                              let genderBg = "bg-blue-50 border-blue-100 text-blue-700";
                              if (gender === 'female') {
                                genderLabel = " 🌸";
                                genderBg = "bg-pink-50 border-pink-100 text-pink-750";
                              } else if (gender === 'male') {
                                genderLabel = " 👨";
                                genderBg = "bg-slate-100 border-slate-205 text-slate-600";
                              }

                              return (
                                <span key={index} className={`text-[10px] font-black uppercase tracking-wide border rounded-lg px-2 py-0.5 shadow-2xs ${genderBg}`}>
                                  {label}{genderLabel}
                                </span>
                              );
                            })}
                          </div>
                        )}
                        
                        <div className="flex flex-wrap gap-2">
                          {b.status !== 'cancelled' && (
                            <>
                              {!b.otpVerified && (
                                <button 
                                  className="success-btn text-xs py-1 px-3"
                                  onClick={() => handleGenerateOTP(r, b.name, b.passengerId)}
                                  disabled={b.otp && !b.otpVerified}
                                >
                                  {b.otp ? (language === 'hi' ? 'ओटीपी भेजा गया' : "OTP Sent") : (language === 'hi' ? 'ओटीपी जेनरेट करें' : "Generate OTP")}
                                </button>
                              )}
                              <button className="secondary-btn text-xs py-1 px-3 relative" onClick={() => openChat(r, b.passengerId, b.name || 'Passenger')}>
                                {language === 'hi' ? 'चैट' : 'Chat'}
                                {unreadCounts[`${r.id}_${b.passengerId}`] > 0 && (
                                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-sm font-black">
                                    {unreadCounts[`${r.id}_${b.passengerId}`]}
                                  </span>
                                )}
                              </button>
                              <button 
                                className={`bg-blue-600 text-white text-xs py-1 px-4 rounded-lg font-bold shadow-md flex items-center gap-1 transition-all active:scale-95 ${b.pickupStatus === 'on_the_way' ? 'animate-pulse ring-2 ring-blue-300' : ''}`} 
                                onClick={() => setTrackingInfo({ ride: r, bookingId: b.bookingId })}
                              >
                                <Navigation className="w-3 h-3" />
                                {language === 'hi' ? 'लाइव ट्रैक' : 'Live Track'}
                              </button>
                              {b.otpVerified && (
                                <button className="warning-btn text-xs py-1 px-3" onClick={() => openRatingModal(r, b.name, 'passenger')}>{language === 'hi' ? 'यात्री को रेट करें' : 'Rate Passenger'}</button>
                              )}
                            </>
                          )}
                        </div>

                        {b.bookingId && (
                          <div className="mt-3 p-2 bg-blue-50 rounded border border-blue-100">
                            <p className="text-[10px] font-bold text-blue-800 mb-2 uppercase tracking-wider">{t.updateStatus}:</p>
                            <div className="flex flex-wrap gap-1">
                              {[
                                { id: 'on_the_way', label: t.statusOnTheWay },
                                { id: 'arrived', label: t.statusArrived },
                                { id: 'started', label: t.statusStarted },
                                { id: 'ended', label: t.statusEnded }
                              ].map(status => (
                                <button
                                  key={status.id}
                                  className={`text-[10px] py-1 px-2 rounded border transition-colors ${
                                    b.pickupStatus === status.id 
                                      ? 'bg-blue-600 text-white border-blue-600' 
                                      : 'bg-white text-blue-600 border-blue-200 hover:bg-blue-50'
                                  }`}
                                  onClick={() => updateJourneyStatus(b.bookingId, status.id)}
                                >
                                  {status.label}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}

                        {b.bookingId && !b.otpVerified && (
                          <div className="mt-3 p-3 bg-gray-50 rounded border border-dashed">
                            <p className="text-xs font-bold mb-2">{language === 'hi' ? 'पिकअप ओटीपी सत्यापित करें:' : 'Verify Pickup OTP:'}</p>
                            <div className="flex gap-1 mb-2">
                              {[0,1,2,3,4,5].map(i => (
                                <input
                                  key={i}
                                  type="text"
                                  maxLength={1}
                                  className="w-8 h-8 text-center border rounded"
                                  value={driverOTPInput[i]}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    if (!/^\d?$/.test(val)) return;
                                    const next = [...driverOTPInput];
                                    next[i] = val;
                                    setDriverOTPInput(next);
                                  }}
                                />
                              ))}
                            </div>
                            <button 
                              className={`w-full text-xs py-1 flex items-center justify-center gap-2 ${isActionLoading ? 'opacity-70 cursor-not-allowed' : ''}`} 
                              onClick={() => handleVerifyOTP(b.bookingId)}
                              disabled={isActionLoading}
                            >
                              {isActionLoading && <LoadingSpinner size="sm" />}
                              {language === 'hi' ? 'सत्यापित करें और पुष्टि करें' : 'Verify & Confirm'}
                            </button>
                            {otpVerificationResult && <p className={`text-[10px] mt-1 ${otpVerificationResult.success ? 'text-green-600' : 'text-red-600'}`}>{otpVerificationResult.message}</p>}
                          </div>
                        )}
                      </div>
                    ))
                  ) : <p className="text-xs text-gray-500 italic">{language === 'hi' ? 'अभी तक कोई बुकिंग नहीं।' : 'No bookings yet.'}</p>}
                </div>
              ) : (
                <div className="mt-4">
                  {r.userBooking?.pickupStatus === 'on_the_way' && (
                    <div className="mb-3 p-3 bg-blue-600 text-white rounded-xl shadow-lg animate-pulse flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="bg-white/20 p-2 rounded-full">
                          <Navigation className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-xs font-bold">{language === 'hi' ? 'ड्राइवर आ रहा है!' : 'Driver is on the way!'}</p>
                          <p className="text-[10px] opacity-90">
                            {r.currentLocation?.timestamp 
                              ? `${language === 'hi' ? 'अंतिम अपडेट:' : 'Last updated:'} ${new Date(r.currentLocation.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`
                              : (language === 'hi' ? 'अभी लाइव लोकेशन ट्रैक करें' : 'Track live location now')}
                          </p>
                        </div>
                      </div>
                      <button 
                        onClick={() => setTrackingInfo({ ride: r, bookingId: r.userBooking?.bookingId })}
                        className="bg-white text-blue-600 text-[10px] font-bold py-1.5 px-4 rounded-full shadow-sm active:scale-95 transition-all"
                      >
                        {language === 'hi' ? 'ट्रैक करें' : 'Track Now'}
                      </button>
                    </div>
                  )}
                  <div className="bg-white p-3 rounded-lg border mb-3 shadow-sm">
                    <h4 className="font-bold text-sm mb-2">{language === 'hi' ? 'मेरी बुकिंग विवरण:' : 'My Booking Details:'}</h4>
                    <p className="text-xs">{t.seats}: {r.userBooking?.seats || 1}</p>
                    {r.userBooking?.selectedSeatLabels && Array.isArray(r.userBooking.selectedSeatLabels) && r.userBooking.selectedSeatLabels.length > 0 && (
                      <div className="my-2 flex flex-wrap gap-1.5 items-center">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-50 border border-slate-100 rounded px-1.5 py-0.5">
                          💺 {language === 'hi' ? 'सीटें:' : 'Seats:'}
                        </span>
                        {r.userBooking.selectedSeatLabels.map((label: string, idx: number) => {
                          const seatId = r.userBooking.selectedSeats ? r.userBooking.selectedSeats[idx] : '';
                          const gender = r.userBooking.seatGenders && seatId ? r.userBooking.seatGenders[seatId] : 'any';
                          
                          let genderLabel = "";
                          let genderBg = "bg-blue-50 border-blue-100 text-blue-700";
                          if (gender === 'female') {
                            genderLabel = " 🌸";
                            genderBg = "bg-pink-50 border-pink-100 text-pink-750";
                          } else if (gender === 'male') {
                            genderLabel = " 👨";
                            genderBg = "bg-slate-100 border-slate-205 text-slate-600";
                          }

                          return (
                            <span key={idx} className={`text-[10px] font-black uppercase tracking-wide border rounded-lg px-2 py-0.5 shadow-2xs ${genderBg}`}>
                              {label}{genderLabel}
                            </span>
                          );
                        })}
                      </div>
                    )}
                    <p className="text-xs">{language === 'hi' ? 'पिकअप:' : 'Pickup:'} {r.userBooking?.pickup || (language === 'hi' ? 'निर्दिष्ट नहीं' : 'Not specified')}</p>
                    <p className="text-xs">{language === 'hi' ? 'स्थिति:' : 'Status:'} <span className="font-bold text-blue-600">
                      {
                        r.userBooking?.pickupStatus === 'on_the_way' ? t.statusOnTheWay :
                        r.userBooking?.pickupStatus === 'arrived' ? t.statusArrived :
                        r.userBooking?.pickupStatus === 'started' ? t.statusStarted :
                        r.userBooking?.pickupStatus === 'ended' ? t.statusEnded :
                        r.userBooking?.pickupStatus === 'scheduled' ? t.statusScheduled :
                        r.userBooking?.pickupStatus || t.statusScheduled
                      }
                    </span></p>
                    
                    {r.userBooking?.otp && !r.userBooking?.otpVerified && (
                      <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded text-center">
                        <p className="text-xs font-bold text-green-800 mb-1">{language === 'hi' ? 'पिकअप सत्यापन ओटीपी' : 'Pickup Verification OTP'}</p>
                        <div className="text-2xl font-bold tracking-widest text-green-700 my-2">{r.userBooking.otp}</div>
                        <p className="text-[10px] text-green-600">{language === 'hi' ? 'जब ड्राइवर आए तो इसे उनके साथ साझा करें।' : 'Share this with the driver when they arrive.'}</p>
                      </div>
                    )}
                    {r.userBooking?.otpVerified && (
                      <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded text-center">
                        <p className="text-xs font-bold text-green-800">✅ {language === 'hi' ? 'पिकअप सत्यापित' : 'Pickup Verified'}</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    <button className="success-btn text-xs py-1 px-3" onClick={() => toggleDriverContact(r)}>
                      {showDriverContact === r.id ? (language === 'hi' ? 'ड्राइवर संपर्क छिपाएं' : 'Hide Driver Contact') : (language === 'hi' ? 'ड्राइवर संपर्क दिखाएं' : 'Show Driver Contact')}
                    </button>
                    <button 
                      className={`bg-blue-600 text-white text-xs py-1 px-4 rounded-lg font-bold shadow-md flex items-center gap-1 transition-all active:scale-95 ${r.userBooking?.pickupStatus === 'on_the_way' ? 'animate-pulse ring-2 ring-blue-300' : ''}`} 
                      onClick={() => setTrackingInfo({ ride: r, bookingId: r.userBooking?.bookingId })}
                    >
                      <Navigation className="w-3 h-3" />
                      {language === 'hi' ? 'लाइव ट्रैक' : 'Live Track'}
                    </button>
                    <button 
                      onClick={() => handleToggleReminder(r)}
                      className={`text-xs py-1 px-3 rounded-lg font-bold flex items-center gap-1 transition-all active:scale-95 border ${
                        hasReminder(r.id) 
                          ? 'bg-amber-100 text-amber-800 border-amber-305 hover:bg-amber-200 shadow-sm' 
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50 shadow-sm'
                      }`}
                    >
                      <span>{hasReminder(r.id) ? '🔔' : '🕰️'}</span>
                      {hasReminder(r.id) ? (language === 'hi' ? 'स्मरणपत्र सेट है' : 'Reminder Set') : (t.remindMe || 'Remind Me')}
                    </button>
                    <button 
                      className="bg-red-600 text-white text-xs py-1 px-3 rounded-lg" 
                      onClick={() => {
                        setBookingToCancel({ 
                          bookingId: r.userBooking?.bookingId, 
                          rideId: r.id as string, 
                          seats: r.userBooking?.seats || 1 
                        });
                        setShowCancelModal(true);
                      }}
                    >
                      {language === 'hi' ? 'सवारी रद्द करें' : 'Cancel Ride'}
                    </button>
                    {r.userBooking?.otpVerified && (
                      <button className="warning-btn text-xs py-1 px-3" onClick={() => openRatingModal(r, r.driver, 'driver')}>⭐ {language === 'hi' ? 'ड्राइवर को रेट करें' : 'Rate Driver'}</button>
                    )}
                  </div>

                  {showDriverContact === r.id && (
                    <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm">
                      <h5 className="font-bold mb-2">{language === 'hi' ? 'ड्राइवर संपर्क जानकारी' : 'Driver Contact Information'}</h5>
                      <div className="space-y-1">
                        <p className="flex items-center gap-2">
                          <span className="font-bold w-16">{language === 'hi' ? 'नाम:' : 'Name:'}</span> 
                          <span>{r.driverName || r.driver}</span>
                        </p>
                        <p className="flex items-center gap-2">
                          <span className="font-bold w-16">{language === 'hi' ? 'फ़ोन:' : 'Phone:'}</span> 
                          <span>{r.driverPhone || driverProfiles[r.driver]?.phone || `+91-XXXX-XXX-${Math.floor(1000 + Math.random() * 9000)}`}</span>
                          {(r.driverPhone || driverProfiles[r.driver]?.phone) && (
                            <a 
                              href={`tel:${r.driverPhone || driverProfiles[r.driver]?.phone}`}
                              className="ml-2 text-blue-600 hover:text-blue-800"
                              title={language === 'hi' ? 'कॉल करें' : 'Call'}
                            >
                              <Phone className="w-4 h-4" />
                            </a>
                          )}
                        </p>
                        <p className="flex items-center gap-2">
                          <span className="font-bold w-16">{language === 'hi' ? 'ईमेल:' : 'Email:'}</span> 
                          <span>{r.driverEmail || driverProfiles[r.driver]?.email || `${(r.driverName || r.driver).toLowerCase().replace(/\s+/g, '')}@ecopool.anon`}</span>
                        </p>
                      </div>
                      {!r.driverPhone && (
                        <p className="text-[10px] text-gray-500 mt-2 italic">
                          {language === 'hi' ? '*गोपनीयता के लिए फोन नंबरों को गुमनाम कर दिया गया है।' : '*Phone numbers are anonymized for privacy.'}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))
        )
      )}
      </div>

      {/* Chat Modal */}
      {showChat && chatRide && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
          <div className="bg-white w-full max-w-md rounded-xl overflow-hidden shadow-2xl flex flex-col h-[500px]">
            <div className="bg-blue-700 text-white p-4 flex justify-between items-center">
              <h3 className="font-bold">{language === 'hi' ? `${chatRide.otherUserName || chatRide.otherUser} के साथ चैट करें` : `Chat with ${chatRide.otherUserName || chatRide.otherUser}`}</h3>
              <button onClick={closeChat} className="text-white hover:text-gray-200">✕</button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 bg-gray-50 flex flex-col gap-2">
              {chatMessages.map((msg, i) => (
                <div key={i} className={`max-w-[80%] p-3 rounded-xl text-sm ${msg.sender === currentUser ? 'bg-blue-600 text-white self-end rounded-br-none shadow-md' : 'bg-white border text-slate-700 self-start rounded-bl-none shadow-sm'}`}>
                  <div>{msg.message}</div>
                  <div className={`text-[10px] mt-1 flex items-center justify-end gap-1 ${msg.sender === currentUser ? 'text-blue-100' : 'text-slate-400'}`}>
                    {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    {msg.sender === currentUser && (
                      msg.read ? <CheckCheck size={12} className="text-emerald-300" /> : <Check size={12} className="opacity-70" />
                    )}
                  </div>
                </div>
              ))}
            </div>
            <div className="p-3 border-t flex gap-2">
              <input 
                type="text" 
                value={chatInput} 
                onChange={(e) => setChatInput(e.target.value)} 
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder={language === 'hi' ? 'एक संदेश लिखें...' : "Type a message..."}
                className="flex-1 p-2 border rounded-lg text-sm"
                disabled={isActionLoading}
              />
              <button 
                onClick={handleSendMessage} 
                disabled={isActionLoading}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg font-bold flex items-center justify-center min-w-[80px]"
              >
                {isActionLoading ? <LoadingSpinner size="sm" color="white" /> : (language === 'hi' ? 'भेजें' : 'Send')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rating Modal */}
      {showRatingModal && ratingData && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
          <div className="bg-white w-full max-w-md rounded-xl overflow-hidden shadow-2xl p-6 max-h-[90vh] overflow-y-auto">
            <h3 className="text-xl font-bold mb-2">{language === 'hi' ? `${ratingData.ratedUser} को रेट करें` : `Rate ${ratingData.ratedUser}`}</h3>
            <p className="text-sm text-gray-600 mb-4">{ratingData.rideFrom} → {ratingData.rideTo}</p>
            
            <div className="mb-6 text-center">
              <p className="font-bold mb-2">{language === 'hi' ? 'कुल रेटिंग *' : 'Overall Rating *'}</p>
              <div className="flex justify-center gap-2 text-3xl">
                {[1,2,3,4,5].map(s => (
                  <span key={s} onClick={() => setRatingData({...ratingData, overall: s})} className={`cursor-pointer ${ratingData.overall >= s ? 'text-amber-400' : 'text-gray-300'}`}>★</span>
                ))}
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <h4 className="font-bold text-sm">{language === 'hi' ? 'मानदंड:' : 'Criteria:'}</h4>
              {['punctuality', 'behavior', ...(ratingData.userRole === 'driver' ? ['driving', 'vehicle'] : [])].map(c => (
                <div key={c} className="flex justify-between items-center">
                  <span className="capitalize text-sm">{
                    c === 'punctuality' ? (language === 'hi' ? 'समय की पाबंदी' : 'punctuality') :
                    c === 'behavior' ? (language === 'hi' ? 'व्यवहार' : 'behavior') :
                    c === 'driving' ? (language === 'hi' ? 'ड्राइविंग' : 'driving') :
                    (language === 'hi' ? 'वाहन' : 'vehicle')
                  }</span>
                  <div className="flex gap-1 text-xl">
                    {[1,2,3,4,5].map(s => (
                      <span key={s} onClick={() => setRatingData({...ratingData, [c]: s})} className={`cursor-pointer ${ratingData[c] >= s ? 'text-amber-400' : 'text-gray-300'}`}>★</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <textarea 
              placeholder={language === 'hi' ? 'अपना अनुभव साझा करें (वैकल्पिक)...' : "Share your experience (optional)..."} 
              className="w-full h-24 mb-6"
              value={ratingData.review}
              onChange={(e) => setRatingData({...ratingData, review: e.target.value})}
            />

            <div className="flex gap-3">
              <button className="secondary-btn flex-1" onClick={() => setShowRatingModal(false)}>{language === 'hi' ? 'रद्द करें' : 'Cancel'}</button>
              <button className="flex-1" onClick={handleSubmitRatingData}>{language === 'hi' ? 'रेटिंग सबमिट करें' : 'Submit Rating'}</button>
            </div>
          </div>
        </div>
      )}

      {/* Cancellation Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
          <div className="bg-white w-full max-w-md rounded-xl overflow-hidden shadow-2xl p-6">
            <h3 className="text-xl font-bold mb-4">{language === 'hi' ? 'सवारी रद्द करें' : 'Cancel Ride'}</h3>
            <p className="text-sm text-gray-600 mb-4">
              {language === 'hi' 
                ? 'क्या आप वाकई इस सवारी को रद्द करना चाहते हैं? कृपया रद्द करने का कारण बताएं:' 
                : 'Are you sure you want to cancel this ride? Please provide a reason:'}
            </p>
            
            <textarea 
              placeholder={language === 'hi' ? 'रद्द करने का कारण...' : "Reason for cancellation..."} 
              className="w-full h-24 mb-6 p-2 border rounded-lg"
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
            />

            <div className="flex gap-3">
              <button className="secondary-btn flex-1" onClick={() => {
                setShowCancelModal(false);
                setCancelReason("");
                setBookingToCancel(null);
                setRideToCancel(null);
              }}>
                {language === 'hi' ? 'वापस जाएं' : 'Go Back'}
              </button>
              <button className="bg-red-600 text-white flex-1 rounded-lg font-bold" onClick={handleCancelBooking}>
                {language === 'hi' ? 'पुष्टि करें' : 'Confirm Cancellation'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
