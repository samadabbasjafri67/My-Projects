import React from 'react';
import { TRANSLATIONS } from '../constants';
import { User } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import { db, doc, onSnapshot, handleFirestoreError, OperationType } from '../firebase';
import { NotificationService } from '../services/notificationService';
import { Bell, BellOff, TrendingUp } from 'lucide-react';
import { DriverEarningsDashboard } from './DriverEarningsDashboard';
import { compressImage } from '../utils';

interface ProfileSectionProps {
  currentUser: string;
  user: User;
  showNotification: (msg: string, color?: string) => void;
  updateUserProfile: (data: any) => Promise<boolean>;
  submitUserVerification: (docs: any[]) => Promise<boolean>;
  language: string;
}

export const ProfileSection: React.FC<ProfileSectionProps> = ({
  currentUser,
  user,
  showNotification,
  updateUserProfile,
  submitUserVerification,
  language
}) => {
  const [isEditing, setIsEditing] = React.useState(false);
  const [editedProfile, setEditedProfile] = React.useState<any>({
    username: user.username,
    email: user.email || '',
    phone: user.phone || '',
    profilePhoto: user.profilePhoto || null
  });
  const [showVerification, setShowVerification] = React.useState(false);
  const [idProof, setIdProof] = React.useState<string | null>(null);
  const [saving, setSaving] = React.useState(false);
  const [driverStatus, setDriverStatus] = React.useState<'online' | 'busy' | 'offline'>(user.status || 'offline');

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  // Real-time location updates when online
  React.useEffect(() => {
    if (driverStatus !== 'online') return;

    let watchId: number;
    
    // Initial update
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude: lat, longitude: lng } = position.coords;
        updateUserProfile({
          currentLocation: { lat, lng, timestamp: new Date().toISOString() },
          lastActiveAt: new Date().toISOString()
        });
      },
      (err) => console.error("Error getting initial position", err)
    );

    // Watch position
    watchId = navigator.geolocation.watchPosition(
      async (position) => {
        const { latitude: lat, longitude: lng } = position.coords;
        await updateUserProfile({
          currentLocation: { lat, lng, timestamp: new Date().toISOString() },
          lastActiveAt: new Date().toISOString()
        });
      },
      (err) => console.error("Error watching position", err),
      { enableHighAccuracy: true, maximumAge: 30000, timeout: 20000 }
    );

    // Heartbeat to keep status active
    const heartbeat = setInterval(() => {
      updateUserProfile({
        lastActiveAt: new Date().toISOString()
      });
    }, 60000);

    return () => {
      navigator.geolocation.clearWatch(watchId);
      clearInterval(heartbeat);
    };
  }, [driverStatus]);

  React.useEffect(() => {
    setEditedProfile({
      username: user.username,
      email: user.email || '',
      phone: user.phone || '',
      profilePhoto: user.profilePhoto || null
    });
  }, [user]);

  const handleProfileSave = async () => {
    setSaving(true);
    try {
      if (await updateUserProfile(editedProfile)) {
        setIsEditing(false);
      }
    } finally {
      setSaving(false);
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setSaving(true);
    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const base64 = ev.target?.result as string;
        const compressedBase64 = await compressImage(base64, 400, 400); // profile picture can be smaller (400x400)
        setEditedProfile({ ...editedProfile, profilePhoto: compressedBase64 });
        showNotification(language === 'hi' ? 'प्रोफ़ाइल फ़ोटो संसाधित किया गया' : 'Profile photo processed successfully', '#10b981');
      } catch (err) {
        console.error("Error compressing profile image:", err);
        setEditedProfile({ ...editedProfile, profilePhoto: ev.target?.result });
      } finally {
        setSaving(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleIdUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setSaving(true);
    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const base64 = ev.target?.result as string;
        const compressedBase64 = await compressImage(base64);
        setIdProof(compressedBase64);
        showNotification(language === 'hi' ? 'पहचान प्रमाण सफलतापूर्वक संसाधित किया गया' : 'ID proof processed successfully', '#10b981');
      } catch (err) {
        console.error("Error compressing ID proof:", err);
        setIdProof(ev.target?.result as string);
      } finally {
        setSaving(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleVerificationSubmit = async () => {
    if (!idProof) {
      showNotification("Please upload an ID proof!", "#e53935");
      return;
    }
    setSaving(true);
    try {
      // Mock initializing earnings for newly verified drivers
      const earningsData = user.role === 'driver' && !user.driverEarnings ? {
        today: 1200,
        thisWeek: 8500,
        thisMonth: 32000,
        total: 154000,
        weeklyHistory: [
          { day: 'Mon', amount: 1500 },
          { day: 'Tue', amount: 1200 },
          { day: 'Wed', amount: 1800 },
          { day: 'Thu', amount: 900 },
          { day: 'Fri', amount: 2100 },
          { day: 'Sat', amount: 1000 },
          { day: 'Sun', amount: 0 }
        ]
      } : user.driverEarnings;

      if (await submitUserVerification([
        { type: 'idProof', data: idProof, uploadedAt: new Date().toISOString() },
        { type: 'earningsInit', data: earningsData }
      ])) {
        setShowVerification(false);
      }
    } finally {
      setSaving(false);
    }
  };

  const toggleNotifications = async () => {
    if (user.notificationsEnabled) {
      await updateUserProfile({ notificationsEnabled: false });
      showNotification(language === 'hi' ? 'सूचनाएं अक्षम कर दी गईं' : 'Notifications disabled', '#64748b');
    } else {
      const success = await NotificationService.requestPermission(currentUser);
      if (success) {
        showNotification(language === 'hi' ? 'सूचनाएं सक्षम कर दी गईं' : 'Notifications enabled', '#10b981');
        NotificationService.sendNotification(language === 'hi' ? 'Eco-Ride सूचनाएं' : 'Eco-Ride Notifications', {
          body: language === 'hi' ? 'आप अब महत्वपूर्ण अपडेट के लिए सूचनाएं प्राप्त करेंगे।' : 'You will now receive notifications for important updates.'
        });
      } else {
        showNotification(language === 'hi' ? 'सूचना अनुपलब्ध या अनुमति नकारी गई' : 'Notifications unsupported or permission denied', '#e53935');
      }
    }
  };

  const toggleDriverStatus = async () => {
    const newStatus = driverStatus === 'offline' ? 'online' : 'offline';
    setDriverStatus(newStatus);
    await updateUserProfile({ status: newStatus });
    showNotification(
      newStatus === 'online' 
        ? (language === 'hi' ? 'अब आप ऑनलाइन हैं' : 'You are now online')
        : (language === 'hi' ? 'आप अब ऑफ़लाइन हैं' : 'You are now offline'),
      newStatus === 'online' ? '#10b981' : '#64748b'
    );
  };

  return (
    <div id="profileSection">
      <h2 className="text-xl font-bold mb-4">{t.myProfile}</h2>

      <div className="verification-section mb-6">
        <div className="flex justify-between items-center mb-2">
          <h3 className="font-bold">{language === 'hi' ? 'खाता सत्यापन' : 'Account Verification'}</h3>
          {user.isVerified ? (
            <span className="verification-badge">✓ {t.verified}</span>
          ) : (
            <span className={`verification-badge ${user.verificationStatus === 'pending' ? 'pending' : ''}`}>
              {user.verificationStatus === 'pending' ? (language === 'hi' ? '⏳ लंबित' : '⏳ Pending') : (language === 'hi' ? 'सत्यापित नहीं' : 'Not Verified')}
            </span>
          )}
        </div>
        {!user.isVerified && user.verificationStatus !== 'pending' && !showVerification && (
          <div>
            <p className="text-sm text-gray-600 mb-3">{language === 'hi' ? 'विश्वास बनाने और अधिक सुविधाओं को अनलॉक करने के लिए अपना खाता सत्यापित करें।' : 'Verify your account to build trust and unlock more features.'}</p>
            <button onClick={() => setShowVerification(true)}>{language === 'hi' ? 'अभी सत्यापित करें' : 'Verify Now'}</button>
          </div>
        )}
        {showVerification && (
          <div className="mt-4 p-4 border rounded-lg bg-white">
            <h4 className="font-bold mb-2">{language === 'hi' ? 'पहचान प्रमाण अपलोड करें' : 'Upload ID Proof'}</h4>
            <p className="text-xs text-gray-500 mb-4">{language === 'hi' ? 'समर्थित: आधार, ड्राइविंग लाइसेंस, पासपोर्ट' : 'Supported: Aadhar, Driving License, Passport'}</p>
            <div className="file-upload mb-4">
              <input type="file" id="idProof" className="hidden" onChange={handleIdUpload} />
              <label htmlFor="idProof" className="cursor-pointer block">
                {idProof ? (language === 'hi' ? '✅ पहचान प्रमाण अपलोड किया गया' : '✅ ID Proof Uploaded') : (language === 'hi' ? '📁 पहचान प्रमाण अपलोड करने के लिए क्लिक करें' : '📁 Click to Upload ID Proof')}
              </label>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={handleVerificationSubmit} 
                disabled={saving}
                className={`flex-1 flex items-center justify-center gap-2 ${saving ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {saving && <LoadingSpinner size="sm" color="white" />}
                {language === 'hi' ? 'जमा करें' : 'Submit'}
              </button>
              <button onClick={() => setShowVerification(false)} className="secondary-btn flex-1" disabled={saving}>{language === 'hi' ? 'रद्द करें' : 'Cancel'}</button>
            </div>
          </div>
        )}
      </div>

      <div className="profile-stats mb-6">
        <div className="profile-stat-card">
          <div className="text-xs text-gray-500">{language === 'hi' ? 'कुल सवारी' : 'Total Rides'}</div>
          <div className="text-2xl font-bold">{user.totalRides || 0}</div>
        </div>
        <div className="profile-stat-card">
          <div className="text-xs text-gray-500">{language === 'hi' ? 'कार्बन बचाया' : 'Carbon Saved'}</div>
          <div className="text-2xl font-bold">{(user.carbonSaved || 0).toFixed(1)} kg</div>
        </div>
        <div className="profile-stat-card">
          <div className="text-xs text-gray-500">{language === 'hi' ? 'इको पॉइंट्स' : 'Eco Points'}</div>
          <div className="text-2xl font-bold">{user.points || 0}</div>
        </div>
      </div>

      {user.role === 'driver' && user.isVerified && (
        <div className="mb-8">
          <DriverEarningsDashboard user={user} language={language} />
        </div>
      )}

      {user.role === 'driver' && user.isVerified && (
        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className={`p-2 rounded-lg ${driverStatus === 'online' ? 'bg-emerald-50 text-emerald-600' : driverStatus === 'busy' ? 'bg-amber-50 text-amber-600' : 'bg-slate-50 text-slate-400'}`}>
               <div className={`w-3 h-3 rounded-full ${driverStatus === 'online' ? 'bg-emerald-500 animate-pulse' : driverStatus === 'busy' ? 'bg-amber-500' : 'bg-slate-400'}`}></div>
             </div>
             <div>
               <h4 className="text-sm font-bold text-slate-900">{language === 'hi' ? 'उपलब्धता स्थिति' : 'Availability Status'}</h4>
               <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">
                 {driverStatus === 'online' ? (language === 'hi' ? 'ऑनलाइन - सवारी के लिए तैयार' : 'Online - Ready for rides') 
                   : driverStatus === 'busy' ? (language === 'hi' ? 'व्यस्त - सवारी में' : 'Busy - In a ride')
                   : (language === 'hi' ? 'ऑफ़लाइन' : 'Offline')}
               </p>
             </div>
          </div>
          <button 
            onClick={toggleDriverStatus}
            disabled={driverStatus === 'busy'}
            className={`px-6 py-2 rounded-lg text-xs font-black uppercase tracking-wider transition-all ${driverStatus === 'online' ? 'bg-amber-500 text-white shadow-lg shadow-amber-100 hover:bg-amber-600' : driverStatus === 'busy' ? 'bg-slate-100 text-slate-400 cursor-not-allowed' : 'bg-primary text-white shadow-lg shadow-blue-100 hover:bg-blue-600'}`}
          >
            {driverStatus === 'online' ? (language === 'hi' ? 'ऑफ़लाइन हों' : 'Go Offline') : (language === 'hi' ? 'ऑनलाइन हों' : 'Go Online')}
          </button>
        </div>
      )}

      <div className="form-section">
        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm mb-6 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
               <div className={`p-2 rounded-lg ${user.notificationsEnabled ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-400'}`}>
                 {user.notificationsEnabled ? <Bell size={20} /> : <BellOff size={20} />}
               </div>
               <div>
                 <h4 className="text-sm font-bold text-slate-900">{language === 'hi' ? 'पुश सूचनाएं' : 'Push Notifications'}</h4>
                 <p className="text-[10px] text-slate-500 font-medium">
                   {user.notificationsEnabled 
                     ? (language === 'hi' ? 'सक्षम - आपको रीयलटाइम अलर्ट मिलेंगे' : 'Enabled - You will receive real-time alerts')
                     : (language === 'hi' ? 'अक्षम - अलर्ट प्राप्त करने के लिए चालू करें' : 'Disabled - Turn on to receive alerts')}
                 </p>
               </div>
            </div>
            <button 
              onClick={toggleNotifications}
              className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all ${user.notificationsEnabled ? 'bg-slate-100 text-slate-600 hover:bg-slate-200' : 'bg-primary text-white shadow-md shadow-blue-100'}`}
            >
              {user.notificationsEnabled ? (language === 'hi' ? 'बंद करें' : 'Turn Off') : (language === 'hi' ? 'चालू करें' : 'Turn On')}
            </button>
          </div>

          {user.notificationsEnabled && (
            <div className="border-t border-slate-50 pt-4 space-y-3">
              <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                {language === 'hi' ? 'सूचना प्राथमिकताएं' : 'Notification Preferences'}
              </h5>
              
              {[
                { key: 'newRideMatches', label: language === 'hi' ? 'नई सवारी मैच' : 'New Ride Matches' },
                { key: 'bookingUpdates', label: language === 'hi' ? 'बुकिंग अपडेट' : 'Booking Updates' },
                { key: 'sosAlerts', label: language === 'hi' ? 'SOS अलर्ट' : 'SOS Alerts' },
                { key: 'promotionalMessages', label: language === 'hi' ? 'प्रचार संदेश' : 'Promotional Messages' }
              ].map((pref) => (
                <div key={pref.key} className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">{pref.label}</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={user.notificationPreferences?.[pref.key as keyof typeof user.notificationPreferences] !== false}
                      onChange={async (e) => {
                        const newPrefs = {
                          ...(user.notificationPreferences || {
                            newRideMatches: true,
                            bookingUpdates: true,
                            sosAlerts: true,
                            promotionalMessages: true
                          }),
                          [pref.key]: e.target.checked
                        };
                        await updateUserProfile({ notificationPreferences: newPrefs });
                      }}
                    />
                    <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex justify-between items-center mb-4">
          <h3 className="font-bold">{language === 'hi' ? 'व्यक्तिगत जानकारी' : 'Personal Information'}</h3>
          {!isEditing ? (
            <button className="secondary-btn text-xs py-1 px-3" onClick={() => setIsEditing(true)}>{language === 'hi' ? 'प्रोफ़ाइल संपादित करें' : 'Edit Profile'}</button>
          ) : (
            <div className="flex gap-2">
              <button 
                className={`success-btn text-xs py-1 px-3 flex items-center gap-2 ${saving ? 'opacity-50 cursor-not-allowed' : ''}`} 
                onClick={handleProfileSave}
                disabled={saving}
              >
                {saving && <LoadingSpinner size="sm" color="white" />}
                {language === 'hi' ? 'सहेजें' : 'Save'}
              </button>
              <button className="secondary-btn text-xs py-1 px-3" onClick={() => setIsEditing(false)} disabled={saving}>{language === 'hi' ? 'रद्द करें' : 'Cancel'}</button>
            </div>
          )}
        </div>

        <div className="flex flex-col items-center mb-6">
          <div className="w-24 h-24 rounded-full bg-blue-100 flex items-center justify-center text-3xl font-bold text-blue-700 mb-3 overflow-hidden border-2 border-blue-200">
            {editedProfile.profilePhoto ? <img src={editedProfile.profilePhoto} className="w-full h-full object-cover" /> : editedProfile.username?.charAt(0).toUpperCase()}
          </div>
          {isEditing && (
            <div className="text-center">
              <input type="file" id="photo" className="hidden" onChange={handlePhotoUpload} />
              <label htmlFor="photo" className="text-xs text-blue-600 cursor-pointer hover:underline">{language === 'hi' ? 'फोटो बदलें' : 'Change Photo'}</label>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase">{language === 'hi' ? 'उपयोगकर्ता नाम' : 'Username'}</label>
            <input type="text" value={editedProfile.username} readOnly className="bg-gray-100" />
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase">{language === 'hi' ? 'ईमेल' : 'Email'}</label>
            <input 
              type="email" 
              value={editedProfile.email} 
              onChange={(e) => setEditedProfile({...editedProfile, email: e.target.value})} 
              readOnly={!isEditing}
              className={!isEditing ? 'bg-transparent border-none' : ''}
            />
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase">{language === 'hi' ? 'फ़ोन' : 'Phone'}</label>
            <input 
              type="tel" 
              value={editedProfile.phone || ''} 
              onChange={(e) => setEditedProfile({...editedProfile, phone: e.target.value})} 
              readOnly={!isEditing}
              placeholder={language === 'hi' ? 'अपना फ़ोन नंबर जोड़ें' : 'Add your phone number'}
              className={!isEditing ? 'bg-transparent border-none' : 'w-full p-2 border rounded-lg'}
            />
            {!editedProfile.phone && !isEditing && (
              <p className="text-[10px] text-red-500 mt-1 italic">
                {language === 'hi' ? '* सवारी पेश करने के लिए आवश्यक' : '* Required to offer rides'}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
