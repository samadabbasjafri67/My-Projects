import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeSVG } from 'qrcode.react';
import { 
  X, Check, Lock, ShieldCheck, CreditCard, 
  Smartphone, Wallet, Loader, School, CheckCircle2 
} from 'lucide-react';
import { LoadingSpinner } from './LoadingSpinner';

const GATEWAY_TRANSLATIONS: Record<string, Record<string, string>> = {
  en: {
    title: "EcoPool Simulated Gateway",
    subtitle: "Complete your wallet top-up securely",
    amountToPay: "Amount to Pay",
    paymentMethod: "Select Payment Method",
    upi: "UPI (Simulated)",
    card: "Debit/Credit Card (Simulated)",
    netbanking: "NetBanking (Simulated)",
    verifyAndPay: "Verify & Pay Simulated Amount",
    cancel: "Cancel",
    cardHolderName: "Cardholder Name",
    cardNumber: "Card Number",
    expiryDate: "Expiry Date (MM/YY)",
    cvv: "CVV",
    cardHolderPlaceholder: "e.g. Samad Abbas Jafri",
    cardNumberPlaceholder: "4111 2222 3333 4444",
    paySecurely: "Pay ₹{amount}",
    netbankingSelect: "Choose Your Simulated Bank",
    selectBank: "--Select Bank--",
    sbi: "State Bank of India (SBI)",
    hdfc: "HDFC Bank",
    icici: "ICICI Bank",
    axis: "Axis Bank",
    upiApps: "Popular UPI Options",
    upiIdLabel: "Simulated UPI ID",
    upiIdPlaceholder: "username@upi",
    authenticating: "Processing simulated transaction...",
    statusInitiated: "Initiating Secure Connection...",
    statusRouting: "Routing through Simulated Gateway...",
    statusVerifying: "Authorizing with simulated bank/UPI...",
    statusSuccess: "Payment authorized successfully!",
    scanQr: "Scan QR Code with any UPI App",
    orPayWithUpi: "Or use Quick App payment",
    successHeading: "Payment Successful!",
    successDesc: "Your wallet balance will be updated instantly."
  },
  hi: {
    title: "इकोपूल सिम्युलेटेड गेटवे",
    subtitle: "अपना वॉलेट सुरक्षित रूप से टॉप-अप करें",
    amountToPay: "भुगतान की राशि",
    paymentMethod: "भुगतान विधि चुनें",
    upi: "यूपीआई (सिम्युलेटेड)",
    card: "डेबिट/क्रेडिट कार्ड (सिम्युलेटेड)",
    netbanking: "नेटबैंकिंग (सिम्युलेटेड)",
    verifyAndPay: "सिम्युलेटेड राशि सत्यापित करें और भुगतान करें",
    cancel: "रद्द करें",
    cardHolderName: "कार्डधारक का नाम",
    cardNumber: "कार्ड संख्या",
    expiryDate: "समाप्ति तिथि (MM/YY)",
    cvv: "सीवीवी",
    cardHolderPlaceholder: "उद: समद अब्बास जाफ़री",
    cardNumberPlaceholder: "4111 2222 3333 4444",
    paySecurely: "₹{amount} भुगतान करें",
    netbankingSelect: "अपने सिम्युलेटेड बैंक का चयन करें",
    selectBank: "--बैंक चुनें--",
    sbi: "भारतीय स्टेट बैंक (SBI)",
    hdfc: "एचडीएफसी बैंक (HDFC)",
    icici: "आईसीआईसीआई बैंक (ICICI)",
    axis: "एक्सिस बैंक (Axis)",
    upiApps: "लोकप्रिय यूपीआई विकल्प",
    upiIdLabel: "सिम्युलेटेड यूपीआई आईडी",
    upiIdPlaceholder: "username@upi",
    authenticating: "सिम्युलेटेड भुगतान संसाधित किया जा रहा है...",
    statusInitiated: "सुरक्षित कनेक्शन शुरू किया जा रहा है...",
    statusRouting: "सिम्युलेटेड गेटवे के माध्यम से रूटिंग...",
    statusVerifying: "सिम्युलेटेड बैंक/UPI के साथ प्रमाणित किया जा रहा है...",
    statusSuccess: "भुगतान सफलतापूर्वक अधिकृत किया गया!",
    scanQr: "किसी भी यूपीआई ऐप से क्यूआर कोड स्कैन करें",
    orPayWithUpi: "या त्वरित ऐप भुगतान का उपयोग करें",
    successHeading: "भुगतान सफल रहा!",
    successDesc: "आपके वॉलेट का बैलेंस तुरंत अपडेट हो जाएगा।"
  }
};

interface SimulatedWalletPaymentModalProps {
  amount: number;
  language: string;
  onSuccess: () => void;
  onClose: () => void;
  showNotification: (msg: string, color: string) => void;
}

export const SimulatedWalletPaymentModal: React.FC<SimulatedWalletPaymentModalProps> = ({
  amount,
  language,
  onSuccess,
  onClose,
  showNotification
}) => {
  const t = GATEWAY_TRANSLATIONS[language] || GATEWAY_TRANSLATIONS.en;
  const isHindi = language === 'hi';

  const [activeTab, setActiveTab] = React.useState<'upi' | 'card' | 'netbanking'>('upi');
  
  // Card Inputs state
  const [cardNumber, setCardNumber] = React.useState('');
  const [cardExpiry, setCardExpiry] = React.useState('');
  const [cardCvv, setCardCvv] = React.useState('');
  const [cardHolder, setCardHolder] = React.useState('');

  // UPI Inputs state
  const [upiId, setUpiId] = React.useState('user@oksbi');
  const [quickUpiSelected, setQuickUpiSelected] = React.useState<string | null>(null);

  // NetBanking state
  const [selectedBank, setSelectedBank] = React.useState('');

  // Transaction processing animation steps state
  const [processingState, setProcessingState] = React.useState<'idle' | 'processing' | 'success'>('idle');
  const [stepIndex, setStepIndex] = React.useState(0);
  const stepsEn = [
    "🔒 Initiating secure SSL layer and handshakes...",
    "🛡️ Verifying payment parameters with sandbox network...",
    "📡 Authenticating transaction authorization with gateway...",
    "🎉 Finalizing balance update and security checks..."
  ];
  const stepsHi = [
    "🔒 सुरक्षित एसएसएल परत और हैंडशेक शुरू किया जा रहा है...",
    "🛡️ सैंडबॉक्स नेटवर्क के साथ भुगतान मापदंडों का सत्यापन...",
    "📡 गेटवे के साथ लेनदेन प्राधिकरण का सत्यापन...",
    "🎉 बैलेंस अपडेट और अंतिम सुरक्षा जांच की जा रही है..."
  ];
  const activeSteps = isHindi ? stepsHi : stepsEn;

  // Format Card Number dynamically (adds spaces every 4 digits)
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '');
    const truncated = raw.slice(0, 16);
    const formatted = truncated.replace(/(\d{4})(?=\d)/g, '$1 ');
    setCardNumber(formatted);
  };

  // Format Expiry MM/YY
  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let raw = e.target.value.replace(/\D/g, '');
    const truncated = raw.slice(0, 4);
    if (truncated.length >= 2) {
      setCardExpiry(`${truncated.slice(0, 2)}/${truncated.slice(2)}`);
    } else {
      setCardExpiry(truncated);
    }
  };

  // Trigger processing step-by-step
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Field Validations based on selected Tab
    if (activeTab === 'card') {
      const sanitizedCard = cardNumber.replace(/\s/g, '');
      if (sanitizedCard.length !== 16) {
        showNotification(isHindi ? "कृपया 16-अंकीय मान्य कार्ड नंबर दर्ज करें" : "Please enter a valid 16-digit card number", "#e53935");
        return;
      }
      if (cardExpiry.length !== 5) {
        showNotification(isHindi ? "कृपया अमान्य समाप्ति तिथि दर्ज करें (MM/YY)" : "Please enter a valid expiry date (MM/YY)", "#e53935");
        return;
      }
      if (cardCvv.length < 3) {
        showNotification(isHindi ? "कृपया 3-अंकीय मान्य सीवीवी दर्ज करें" : "Please enter a valid 3-digit CVV", "#e53935");
        return;
      }
      if (!cardHolder.trim()) {
        showNotification(isHindi ? "कृपया कार्डधारक का नाम दर्ज करें" : "Please enter the cardholder's name", "#e53935");
        return;
      }
    } else if (activeTab === 'upi') {
      if (!quickUpiSelected && (!upiId.trim() || !upiId.includes('@'))) {
        showNotification(isHindi ? "कृपया एक मान्य यूपीआई आईडी दर्ज करें (जैसे: user@upi)" : "Please Enter a valid UPI ID (e.g. user@upi)", "#e53935");
        return;
      }
    } else if (activeTab === 'netbanking') {
      if (!selectedBank) {
        showNotification(isHindi ? "कृपया भुगतान के लिए एक बैंक चुनें" : "Please select a bank for net banking payment", "#e53935");
        return;
      }
    }

    setProcessingState('processing');
    setStepIndex(0);

    // Step-by-step simulation delay
    const startStepSimulation = (idx: number) => {
      if (idx < activeSteps.length) {
        setTimeout(() => {
          setStepIndex(idx + 1);
          startStepSimulation(idx + 1);
        }, 1200);
      } else {
        setTimeout(() => {
          setProcessingState('success');
          setTimeout(() => {
            onSuccess();
          }, 1500);
        }, 800);
      }
    };

    startStepSimulation(0);
  };

  const merchantName = "Samad Abbas Jafri";
  const upiUrl = `upi://pay?pa=abbasjafri333@oksbi&pn=${encodeURIComponent(merchantName)}&am=${amount.toFixed(2)}&cu=INR&tn=EcoPoolTopUp&mode=02`;

  return (
    <div className="fixed inset-0 z-55 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <AnimatePresence mode="wait">
        {processingState === 'idle' && (
          <motion.div 
            id="payment-modal-container"
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            className="bg-white rounded-3xl w-full max-w-xl shadow-2xl border border-slate-100 overflow-hidden text-slate-800 flex flex-col max-h-[90vh]"
          >
            {/* Secures Header */}
            <div className="bg-gradient-to-r from-blue-700 via-indigo-800 to-indigo-900 px-6 py-5 text-white relative">
              <button 
                id="close-payment-modal-btn"
                onClick={onClose}
                className="absolute top-4 right-4 p-1.5 rounded-full bg-black/10 hover:bg-black/25 text-white transition-colors"
                aria-label="Close modal"
              >
                <X size={18} />
              </button>
              <div className="flex items-center gap-2.5 mb-1.5 select-none">
                <ShieldCheck className="text-emerald-400 w-5 h-5 animate-pulse" />
                <span className="text-xs uppercase tracking-widest font-black text-emerald-300">SANDBOX SECURE PAY</span>
              </div>
              <h3 className="text-xl font-black tracking-tight">{t.title}</h3>
              <p className="text-xs text-white/70 font-medium">{t.subtitle}</p>
            </div>

            {/* Scrollable Container */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              
              {/* Payment Amount Card */}
              <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex justify-between items-center shadow-2xs">
                <div>
                  <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 block mb-0.5">{t.amountToPay}</span>
                  <span className="text-xs text-slate-500 font-medium">{language === 'hi' ? 'वॉलेट टॉप-अप सेवा' : 'Wallet Top-up load request'}</span>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-black text-blue-700">₹{amount.toLocaleString()}</span>
                </div>
              </div>

              {/* Tabs selector */}
              <div>
                <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 block mb-3 px-1">
                  💳 {t.paymentMethod}
                </span>
                <div className="grid grid-cols-3 gap-1.5 bg-slate-100/80 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setActiveTab('upi')}
                    className={`py-2 px-1 text-center rounded-lg text-xs font-black transition-all ${
                      activeTab === 'upi'
                        ? 'bg-white text-blue-700 shadow-sm'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {t.upi}
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('card')}
                    className={`py-2 px-1 text-center rounded-lg text-xs font-black transition-all ${
                      activeTab === 'card'
                        ? 'bg-white text-blue-700 shadow-sm'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {t.card}
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('netbanking')}
                    className={`py-2 px-1 text-center rounded-lg text-xs font-black transition-all ${
                      activeTab === 'netbanking'
                        ? 'bg-white text-blue-700 shadow-sm'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {t.netbanking}
                  </button>
                </div>
              </div>

              <form onSubmit={handlePaymentSubmit} className="space-y-5">
                
                {/* 1. UPI Payment Segment */}
                {activeTab === 'upi' && (
                  <div className="space-y-4">
                    <div className="flex flex-col md:flex-row items-center gap-5 p-4 bg-blue-50/50 border border-blue-50 rounded-2xl">
                      {/* Simulated QR block */}
                      <div className="bg-white p-3 rounded-xl border border-slate-200/60 shadow-xs flex-shrink-0">
                        <QRCodeSVG 
                          value={upiUrl} 
                          size={110} 
                          includeMargin={false} 
                          level="M"
                        />
                      </div>
                      <div className="text-center md:text-left flex-1 min-w-0">
                        <p className="text-xs font-bold text-slate-700 mb-1">{t.scanQr}</p>
                        <p className="text-[10px] text-slate-400 font-medium line-clamp-2">
                          {language === 'hi' 
                            ? 'यह एक सिम्युलेटेड भुगतान है, कोई वास्तविक पैसे नहीं काटे जाएंगे।' 
                            : 'This is a simulated secure testing environment. No actual money will leave your bank account.'}
                        </p>
                        <div className="mt-2.5 flex items-center justify-center md:justify-start gap-1.5 uppercase font-mono text-[9px] text-indigo-600 bg-white border border-indigo-100 rounded-lg px-2 py-1 w-max">
                          <span>UPI ID: abbasjafri333@oksbi</span>
                        </div>
                      </div>
                    </div>

                    {/* Quick Simulated Apps */}
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2 px-1">{t.upiApps}</p>
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { id: 'gpay', name: 'Google Pay', icon: '⚡' },
                          { id: 'phonepe', name: 'PhonePe', icon: '🏆' },
                          { id: 'paytm', name: 'Paytm', icon: '💰' }
                        ].map((app) => (
                          <button
                            key={app.id}
                            type="button"
                            onClick={() => {
                              setQuickUpiSelected(app.id);
                              setUpiId(`${app.id}@upi`);
                            }}
                            className={`p-3 rounded-xl border text-center transition-all ${
                              quickUpiSelected === app.id
                                ? 'bg-blue-50 border-blue-500 text-blue-700 font-bold'
                                : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                            }`}
                          >
                            <span className="block text-lg mb-1">{app.icon}</span>
                            <span className="text-[10px] font-bold block">{app.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Custom UPI String input */}
                    {!quickUpiSelected && (
                      <div>
                        <label className="text-[10px] uppercase font-black text-slate-400 tracking-widest block mb-1.5 px-1">{t.upiIdLabel}</label>
                        <div className="relative">
                          <Smartphone className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                          <input 
                            type="text"
                            value={upiId}
                            onChange={(e) => setUpiId(e.target.value)}
                            placeholder={t.upiIdPlaceholder}
                            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:border-blue-500 bg-slate-50/50 outline-none font-bold text-sm"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* 2. Simulated Debit/Credit Card Segment */}
                {activeTab === 'card' && (
                  <div className="space-y-4">
                    {/* Cool Credit Card Graphics Preview */}
                    <div className="relative w-full h-44 rounded-2xl bg-gradient-to-br from-slate-900 via-indigo-950 to-indigo-900 border border-white/10 p-5 text-white flex flex-col justify-between shadow-xl overflow-hidden">
                      <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-blue-500/10 blur-xl" />
                      <div className="absolute -bottom-10 -left-10 w-32 h-32 rounded-full bg-indigo-500/10 blur-xl" />
                      
                      <div className="relative z-10 flex justify-between items-start">
                        <div className="h-7 w-10 bg-yellow-400/85 rounded-md flex items-center justify-center text-slate-900 font-black text-[9px] shadow-xs select-none">
                          SIM-V
                        </div>
                        <span className="text-xs uppercase font-black italic tracking-widest opacity-80 select-none bg-blue-500/30 px-2 py-0.5 rounded border border-blue-400/20">
                          Secure Card
                        </span>
                      </div>

                      <div className="relative z-10 text-center my-1.5">
                        <span className="text-xl font-mono tracking-widest block font-bold text-white/95 select-all">
                          {cardNumber || "•••• •••• •••• ••••"}
                        </span>
                      </div>

                      <div className="relative z-10 flex justify-between items-end">
                        <div className="min-w-0 max-w-[70%]">
                          <span className="text-[7px] text-white/50 uppercase font-black tracking-widest block mb-0.5">Cardholder</span>
                          <span className="text-xs font-bold uppercase truncate block text-white/90">
                            {cardHolder || "Spade EcoPooler"}
                          </span>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <span className="text-[7px] text-white/50 uppercase font-black tracking-widest block mb-0.5">Expiry</span>
                          <span className="text-xs font-mono font-bold block text-white/95">
                            {cardExpiry || "MM/YY"}
                          </span>
                        </div>
                        <div className="text-right flex-shrink-0 pl-3">
                          <span className="text-[7px] text-white/50 uppercase font-black tracking-widest block mb-0.5">CVV</span>
                          <span className="text-xs font-mono font-bold block text-white/95">
                            {cardCvv ? "•••" : "000"}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Inputs panel */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="md:col-span-2">
                        <label className="text-[10px] uppercase font-black text-slate-400 tracking-widest block mb-1 px-1">
                          {t.cardHolderName}
                        </label>
                        <input
                          type="text"
                          value={cardHolder}
                          onChange={(e) => setCardHolder(e.target.value)}
                          placeholder={t.cardHolderPlaceholder}
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-blue-500 outline-none text-sm font-bold bg-slate-50/50"
                        />
                      </div>

                      <div className="md:col-span-2">
                        <label className="text-[10px] uppercase font-black text-slate-400 tracking-widest block mb-1 px-1">
                          {t.cardNumber}
                        </label>
                        <div className="relative">
                          <CreditCard className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                          <input
                            type="text"
                            value={cardNumber}
                            onChange={handleCardNumberChange}
                            placeholder={t.cardNumberPlaceholder}
                            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:border-blue-500 outline-none text-sm font-bold bg-slate-50/50"
                            maxLength={19}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] uppercase font-black text-slate-400 tracking-widest block mb-1 px-1">
                          {t.expiryDate}
                        </label>
                        <input
                          type="text"
                          value={cardExpiry}
                          onChange={handleExpiryChange}
                          placeholder="MM/YY"
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-blue-500 outline-none text-sm font-bold bg-slate-50/50"
                          maxLength={5}
                        />
                      </div>

                      <div>
                        <label className="text-[10px] uppercase font-black text-slate-400 tracking-widest block mb-1 px-1">
                          {t.cvv}
                        </label>
                        <input
                          type="password"
                          value={cardCvv}
                          onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, '').slice(0, 3))}
                          placeholder="•••"
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-blue-500 outline-none text-sm font-bold bg-slate-50/50"
                          maxLength={3}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* 3. Simulated NetBanking Segment */}
                {activeTab === 'netbanking' && (
                  <div className="space-y-4">
                    <div>
                      <label className="text-[10px] uppercase font-black text-slate-400 tracking-widest block mb-1.5 px-1">
                        {t.netbankingSelect}
                      </label>
                      <div className="relative">
                        <School className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                        <select
                          value={selectedBank}
                          onChange={(e) => setSelectedBank(e.target.value)}
                          className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 bg-white outline-none text-sm font-bold appearance-none cursor-pointer"
                        >
                          <option value="">{t.selectBank}</option>
                          <option value="sbi">🏦 {t.sbi}</option>
                          <option value="hdfc">🏦 {t.hdfc}</option>
                          <option value="icici">🏦 {t.icici}</option>
                          <option value="axis">🏦 {t.axis}</option>
                        </select>
                      </div>
                    </div>

                    {/* Simulated Banks Grid Checklist */}
                    <div className="p-3 bg-indigo-50/50 border border-indigo-100 rounded-xl">
                      <p className="text-[10px] uppercase font-black text-indigo-700 mb-1.5">⚡ Instant Simulated NB Authorizer</p>
                      <p className="text-[10px] text-indigo-500 font-medium">
                        {isHindi 
                          ? 'नेटबैंकिंग भुगतान पर सुरक्षा सत्यापन सुनिश्चित होगा। कोई अतिरिक्त पिन आवश्यक नहीं है।'
                          : 'Selecting a bank forwards your top-up request to the sandbox security provider.'}
                      </p>
                    </div>
                  </div>
                )}

                {/* Bottom Trigger buttons */}
                <div className="grid grid-cols-2 gap-3 pt-6 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={onClose}
                    className="w-full bg-slate-100 hover:bg-slate-200 text-slate-600 font-black py-3 rounded-xl text-xs uppercase tracking-widest transition-all"
                  >
                    {t.cancel}
                  </button>
                  <button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-3 rounded-xl text-xs uppercase tracking-widest shadow-lg shadow-blue-200 transition-all flex items-center justify-center gap-2"
                  >
                    <Lock size={12} />
                    {t.paySecurely.replace("{amount}", amount.toString())}
                  </button>
                </div>

              </form>
            </div>
          </motion.div>
        )}

        {/* PROCESSING DISPLAY */}
        {processingState === 'processing' && (
          <motion.div
            key="processing-payment"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-8 max-w-sm w-full text-center space-y-6 shadow-2xl border border-slate-100"
          >
            <div className="flex justify-center">
              <Loader className="w-12 h-12 text-blue-600 animate-spin" />
            </div>

            <div className="space-y-2">
              <h4 className="text-lg font-black text-slate-900">{isHindi ? 'भुगतान प्रक्रियाधीन...' : 'Simulated Gateway active...'}</h4>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{t.authenticating}</p>
            </div>

            {/* Simulated SSL Loading list */}
            <div className="space-y-2 bg-slate-50 p-4 rounded-2xl text-left border border-slate-100">
              {activeSteps.map((step, idx) => {
                const isDone = idx < stepIndex;
                const isCurrent = idx === stepIndex;
                return (
                  <div key={idx} className="flex items-start gap-2 text-[10px] font-bold">
                    {isDone ? (
                      <span className="text-emerald-500 flex-shrink-0">✓</span>
                    ) : isCurrent ? (
                      <span className="text-blue-500 animate-bounce flex-shrink-0">➜</span>
                    ) : (
                      <span className="text-slate-300 flex-shrink-0">○</span>
                    )}
                    <span className={`${isDone ? 'text-slate-400 line-through' : isCurrent ? 'text-indigo-700 font-black' : 'text-slate-400'}`}>
                      {step}
                    </span>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* SUCCESS TICK DISPLAY */}
        {processingState === 'success' && (
          <motion.div
            key="success-payment"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-8 max-w-sm w-full text-center space-y-5 shadow-2xl border border-slate-100"
          >
            <div className="flex justify-center">
              <div className="w-16 h-16 rounded-full bg-emerald-50 border-4 border-emerald-500 flex items-center justify-center text-emerald-500 animate-pulse">
                <Check className="w-8 h-8 font-extrabold stroke-[4]" />
              </div>
            </div>

            <div className="space-y-1.5">
              <h4 className="text-xl font-black text-emerald-600">{t.successHeading}</h4>
              <p className="text-xs text-slate-500 font-medium">{t.successDesc}</p>
            </div>

            <div className="p-3 bg-emerald-50 text-emerald-800 text-[10px] rounded-xl font-bold uppercase tracking-wider mx-auto w-max">
              Transaction ID: TXN_SIM_{Math.random().toString(36).substring(2, 8).toUpperCase()}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
