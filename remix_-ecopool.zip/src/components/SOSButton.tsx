import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, Phone, MessageSquare, X, MapPin, ShieldAlert, Settings, ArrowLeft, Save } from 'lucide-react';
import { TRANSLATIONS } from '../constants';

interface SOSButtonProps {
  language: string;
  showNotification: (msg: string, color?: string) => void;
}

export const SOSButton: React.FC<SOSButtonProps> = ({ language, showNotification }) => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [isTriggered, setIsTriggered] = React.useState(false);
  const [location, setLocation] = React.useState<{ lat: number; lng: number } | null>(null);
  const [isFetchingLocation, setIsFetchingLocation] = React.useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = React.useState(false);

  const [contacts, setContacts] = React.useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('ecopool_emergency_contacts');
      return saved ? JSON.parse(saved) : ['', '', ''];
    } catch {
      return ['', '', ''];
    }
  });

  const t = TRANSLATIONS[language];

  // Helper to standardise length to 3
  const handleContactChange = (index: number, val: string) => {
    const updated = [...contacts];
    updated[index] = val;
    setContacts(updated);
  };

  const handleSaveContacts = () => {
    const filtered = contacts.map(c => c.trim());
    localStorage.setItem('ecopool_emergency_contacts', JSON.stringify(filtered));
    showNotification(language === 'hi' ? "आपातकालीन संपर्क सुरक्षित कर लिए गए हैं!" : "Emergency contacts saved successfully!", "#10b981");
    setIsSettingsOpen(false);
  };

  const fetchLocation = () => {
    setIsFetchingLocation(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
          setIsFetchingLocation(false);
        },
        (error) => {
          console.error("Error fetching location:", error);
          setIsFetchingLocation(false);
          showNotification(t.sosLocationError || "Could not fetch location", "#e53935");
        }
      );
    } else {
      setIsFetchingLocation(false);
      showNotification(t.sosLocationError || "Geolocation not supported", "#e53935");
    }
  };

  const handleTriggerSOS = () => {
    setIsTriggered(true);
    // In a real app, this would send an API request to a backend
    console.log("SOS TRIGGERED at", location);
    showNotification(t.sosTriggered, "#d32f2f");
    
    // Simulate sending alerts
    setTimeout(() => {
      setIsOpen(false);
      setIsTriggered(false);
    }, 5000);
  };

  const handleContactEmergency = () => {
    // Check if we have pre-configured contacts first
    const activeContacts = contacts.filter(c => c.trim());
    if (activeContacts.length > 0) {
      window.location.href = `tel:${activeContacts[0]}`;
    } else {
      window.location.href = "tel:112"; // Universal emergency number
    }
  };

  const handleSendDistress = () => {
    const activeContacts = contacts.filter(c => c.trim());
    const locationString = location ? `https://www.google.com/maps?q=${location.lat},${location.lng}` : "Unknown location";
    const message = `EMERGENCY SOS! I need help. My location: ${locationString}`;
    
    if (activeContacts.length > 0) {
      // Simulate real SMS dispatch to the saved contacts
      showNotification(
        language === 'hi' 
          ? `संकट संदेश इन संपर्कों को भेजा गया: ${activeContacts.join(', ')}` 
          : `Distress message sent to: ${activeContacts.join(', ')}`, 
        "#d32f2f"
      );
    } else {
      showNotification("Distress message sent to emergency services!", "#d32f2f");
    }
    setIsOpen(false);
  };

  return (
    <>
      {/* Floating SOS Button */}
      <motion.button
        id="sos-fab"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => {
          setIsOpen(true);
          setIsSettingsOpen(false);
          fetchLocation();
        }}
        className="fixed bottom-24 right-6 z-[1000] bg-red-600 text-white w-16 h-16 rounded-full shadow-2xl flex items-center justify-center border-4 border-white/20"
      >
        <AlertCircle className="w-8 h-8" />
        <span className="absolute -top-1 -right-1 bg-white text-red-600 text-[10px] font-bold px-1.5 py-0.5 rounded-full border border-red-600">
          SOS
        </span>
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden border-4 border-red-600"
            >
              {/* Header section toggleable */}
              <div className="bg-red-600 p-6 text-white text-center relative">
                <button 
                  onClick={() => setIsOpen(false)}
                  className="absolute top-4 right-4 p-1 hover:bg-white/20 rounded-full transition-colors"
                  id="sos-close-btn"
                >
                  <X className="w-6 h-6" />
                </button>
                
                {!isSettingsOpen && (
                  <button 
                    onClick={() => setIsSettingsOpen(true)}
                    className="absolute top-4 left-4 p-2 bg-white/15 hover:bg-white/30 rounded-full transition-colors flex items-center gap-1 text-xs font-semibold"
                    title="Emergency Contacts Settings"
                    id="sos-settings-toggle"
                  >
                    <Settings className="w-4 h-4" />
                    <span>Contacts</span>
                  </button>
                )}

                {isSettingsOpen && (
                  <button 
                    onClick={() => setIsSettingsOpen(false)}
                    className="absolute top-4 left-4 p-2 bg-white/15 hover:bg-white/30 rounded-full transition-colors flex items-center gap-1 text-xs font-semibold"
                    id="sos-back-btn"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back</span>
                  </button>
                )}

                <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3 mt-6">
                  <ShieldAlert className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-2xl font-black tracking-tighter uppercase">
                  {isSettingsOpen ? 'Contact Settings' : (t.sos || "SOS")}
                </h2>
                <p className="text-red-100 mt-1 font-medium text-xs px-4">
                  {isSettingsOpen 
                    ? 'Configure up to 3 emergency numbers to contact during crisis' 
                    : t.sosConfirm}
                </p>
              </div>

              <div className="p-6 space-y-4">
                {isSettingsOpen ? (
                  /* Settings panel for emergency contacts configuration */
                  <div className="space-y-4">
                    <p className="text-xs text-gray-500 font-medium leading-relaxed">
                      Saving contact details here overrides standard universal help lines, redirecting immediate distress alerts straight to your selected individuals.
                    </p>
                    
                    {[0, 1, 2].map((num) => (
                      <div key={num} className="space-y-1">
                        <label className="text-xs font-bold text-gray-600 focus-within:text-blue-600 block">
                          Emergency Contact {num + 1}
                        </label>
                        <div className="relative">
                          <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                            <Phone className="w-4 h-4" />
                          </span>
                          <input
                            type="tel"
                            id={`sos-contact-input-${num}`}
                            placeholder="e.g. +91 98765 43210"
                            value={contacts[num] || ''}
                            onChange={(e) => handleContactChange(num, e.target.value)}
                            className="pl-9 w-full bg-gray-50 border border-gray-200 focus:border-red-500 focus:bg-white focus:outline-none transition-all py-2.5 rounded-xl text-sm font-mono"
                          />
                        </div>
                      </div>
                    ))}

                    <div className="pt-2 grid grid-cols-2 gap-3">
                      <button
                        onClick={() => setIsSettingsOpen(false)}
                        className="w-full py-3 bg-gray-100 text-gray-700 font-bold rounded-xl text-sm hover:bg-gray-200 transition-colors"
                      >
                        Cancel
                      </button>
                      
                      <button
                        onClick={handleSaveContacts}
                        className="w-full py-3 bg-green-600 text-white font-bold rounded-xl text-sm hover:bg-green-700 transition-colors flex items-center justify-center gap-2 shadow-md"
                        id="sos-settings-save-btn"
                      >
                        <Save className="w-4 h-4" />
                        <span>Save Specs</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Standard SOS Panel */
                  <>
                    {isFetchingLocation ? (
                      <div className="flex items-center justify-center py-4 space-x-2 text-gray-500">
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                        >
                          <MapPin className="w-5 h-5" />
                        </motion.div>
                        <span className="text-sm font-medium">Fetching location...</span>
                      </div>
                    ) : location ? (
                      <div className="bg-gray-50 p-3 rounded-xl flex items-center space-x-3 border border-gray-100">
                        <div className="bg-red-100 p-2 rounded-lg">
                          <MapPin className="w-5 h-5 text-red-600" />
                        </div>
                        <div className="text-xs">
                          <p className="text-gray-500 uppercase font-bold tracking-wider">Current Location</p>
                          <p className="font-mono text-gray-800">{location.lat.toFixed(6)}, {location.lng.toFixed(6)}</p>
                        </div>
                      </div>
                    ) : null}

                    {/* Pre-configured alert indicator for contacts */}
                    {contacts.filter(c => c.trim()).length > 0 && (
                      <div className="bg-orange-50 border border-orange-100 p-2.5 rounded-xl flex items-center justify-between text-xs text-orange-800">
                        <span>
                          ⚙️ <b>{contacts.filter(c => c.trim()).length} Emergency Contacts</b> configured.
                        </span>
                        <button 
                          onClick={() => setIsSettingsOpen(true)}
                          className="text-orange-950 font-bold hover:underline"
                        >
                          Change
                        </button>
                      </div>
                    )}

                    {!isTriggered ? (
                      <div className="grid grid-cols-1 gap-3">
                        <button
                          onClick={handleTriggerSOS}
                          className="w-full bg-red-600 text-white py-4 rounded-2xl font-bold text-lg shadow-lg hover:bg-red-700 transition-colors flex items-center justify-center space-x-2"
                        >
                          <AlertCircle className="w-6 h-6" />
                          <span>{t.sosConfirmButton || "Trigger SOS"}</span>
                        </button>
                        
                        <div className="grid grid-cols-2 gap-3">
                          <button
                            onClick={handleContactEmergency}
                            className="bg-blue-600 text-white p-4 rounded-2xl font-bold text-sm flex flex-col items-center justify-center space-y-2 hover:bg-blue-700 transition-colors"
                          >
                            <Phone className="w-6 h-6" />
                            <span className="text-center leading-tight">
                              {contacts.filter(c => c.trim()).length > 0 
                                ? "Call Contact 1" 
                                : (t.sosContactEmergency || "Emergency Services")}
                            </span>
                          </button>
                          <button
                            onClick={handleSendDistress}
                            className="bg-orange-600 text-white p-4 rounded-2xl font-bold text-sm flex flex-col items-center justify-center space-y-2 hover:bg-orange-700 transition-colors"
                          >
                            <MessageSquare className="w-6 h-6" />
                            <span className="text-center leading-tight">{t.sosSendDistress || "Distress Message"}</span>
                          </button>
                        </div>

                        <button
                          onClick={() => setIsOpen(false)}
                          className="w-full py-3 text-gray-500 font-bold hover:bg-gray-100 rounded-xl transition-colors"
                        >
                          {t.sosCancel || "Cancel"}
                        </button>
                      </div>
                    ) : (
                      <div className="text-center py-8 space-y-4">
                        <motion.div
                          animate={{ scale: [1, 1.2, 1] }}
                          transition={{ repeat: Infinity, duration: 1 }}
                          className="bg-red-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto"
                        >
                          <AlertCircle className="w-16 h-16 text-red-600" />
                        </motion.div>
                        <h3 className="text-xl font-bold text-red-600">{t.sosTriggered}</h3>
                        <p className="text-gray-600 text-sm">{t.sosDesc}</p>
                      </div>
                    )}
                  </>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};

