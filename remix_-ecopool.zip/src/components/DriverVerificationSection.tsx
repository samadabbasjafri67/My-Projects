import React from 'react';
import { db, doc, onSnapshot, updateDoc } from '../firebase';
import { User } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import { compressImage } from '../utils';

interface DriverVerificationSectionProps {
  currentUser: string;
  user: User;
  showNotification: (msg: string, color?: string) => void;
  submitUserVerification: (docs: any[]) => Promise<boolean>;
  language: string;
}

export const DriverVerificationSection: React.FC<DriverVerificationSectionProps> = ({ 
  currentUser, 
  user, 
  showNotification, 
  submitUserVerification,
  language 
}) => {
  const [status, setStatus] = React.useState(user.verificationStatus || "none");
  const [formData, setFormData] = React.useState({
    fullName: user.fullName || "",
    aadharNumber: user.aadharNumber || "",
    vehicleNumber: user.vehicleNumber || "",
    licenseNumber: user.licenseNumber || "",
    carName: user.carName || "",
    carType: user.carType || ""
  });
  const [files, setFiles] = React.useState<{ [key: string]: string }>({
    license: user.licenseImage || "",
    registration: user.registrationImage || "",
    carImage: user.carImage || ""
  });
  const [uploading, setUploading] = React.useState(false);

  React.useEffect(() => {
    setStatus(user.verificationStatus || "none");
  }, [user]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, key: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      try {
        // Compress and resize the image before save
        const compressedBase64 = await compressImage(base64);
        setFiles(prev => ({ ...prev, [key]: compressedBase64 }));
        showNotification(language === 'hi' ? "दस्तावेज़ सफलतापूर्वक संसाधित किया गया" : "Document processed successfully", "#10b981");
      } catch (error) {
        console.error("Error compressing image:", error);
        // Fallback to original Base64 if compression fails
        if (base64 && base64.length < 500000) {
          setFiles(prev => ({ ...prev, [key]: base64 }));
        } else {
          showNotification(language === 'hi' ? "दस्तावेज़ का आकार बहुत बड़ा है! कृपया 500KB से कम का उपयोग करें।" : "Document file is too large! Please use under 500KB or another copy.", "#e53935");
        }
      } finally {
        setUploading(false);
      }
    };
    reader.onerror = () => {
      setUploading(false);
      showNotification("Error reading file!", "#e53935");
    };
    reader.readAsDataURL(file);
  };

  const submit = async () => {
    if (!formData.fullName || !formData.aadharNumber || !formData.vehicleNumber || !formData.licenseNumber || !formData.carName || !formData.carType) {
      showNotification("Please fill all fields, including vehicle style!", "#e53935");
      return;
    }

    if (!files.license || !files.registration || !files.carImage) {
      showNotification("Please upload all required documents and vehicle image!", "#e53935");
      return;
    }
    
    setUploading(true);
    try {
      const docs = [
        { type: 'license', data: files.license, name: 'Driver License' },
        { type: 'registration', data: files.registration, name: 'Vehicle Registration' },
        { type: 'carImage', data: files.carImage, name: 'Vehicle Image' }
      ];

      // Update basic info first
      await updateDoc(doc(db, 'users', currentUser), {
        fullName: formData.fullName,
        aadharNumber: formData.aadharNumber,
        vehicleNumber: formData.vehicleNumber,
        licenseNumber: formData.licenseNumber,
        carName: formData.carName,
        carType: formData.carType,
        carImage: files.carImage,
        licenseImage: files.license,
        registrationImage: files.registration
      });

      const success = await submitUserVerification(docs);
      if (success) {
        showNotification("Verification submitted! Admin will review soon.", "#ff9800");
      }
    } catch (error) {
       console.error("Error submitting verification: ", error);
       showNotification("Submission failed! Document details might be too heavy.", "#e53935");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div id="driverVerificationSection">
      <h2 className="text-xl font-bold mb-4">🛡️ {language === 'hi' ? 'ड्राइवर सत्यापन' : 'Driver Verification'}</h2>
      
      <div className="verification-section mb-8">
        <h3 className="font-bold mb-2">{language === 'hi' ? 'वर्तमान स्थिति' : 'Current Status'}</h3>
        <div className={`verification-status ${status === 'approved' ? 'status-approved' : 'status-pending'}`}>
          {status === 'none' ? (language === 'hi' ? 'जमा नहीं किया गया' : 'Not Submitted') : 
           status === 'approved' ? (language === 'hi' ? 'अनुमोदित' : 'Approved') :
           status === 'pending' ? (language === 'hi' ? 'लंबित' : 'Pending') :
           status === 'rejected' ? (language === 'hi' ? 'अस्वीकृत' : 'Rejected') :
           status.charAt(0).toUpperCase() + status.slice(1)}
        </div>
      </div>

      {(status === 'none' || status === 'rejected') && (
        <div className="form-section p-6 bg-gray-50 rounded-xl border">
          <h3 className="font-bold mb-4">{language === 'hi' ? 'सत्यापन विवरण जमा करें' : 'Submit Verification Details'}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase">{language === 'hi' ? 'पूरा नाम *' : 'Full Name *'}</label>
              <input type="text" value={formData.fullName} onChange={(e) => setFormData({...formData, fullName: e.target.value})} />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase">{language === 'hi' ? 'आधार नंबर *' : 'Aadhar Number *'}</label>
              <input type="text" value={formData.aadharNumber} onChange={(e) => setFormData({...formData, aadharNumber: e.target.value})} />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase">{language === 'hi' ? 'वाहन नंबर *' : 'Vehicle Number *'}</label>
              <input type="text" value={formData.vehicleNumber} onChange={(e) => setFormData({...formData, vehicleNumber: e.target.value})} />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase">{language === 'hi' ? 'लाइसेंस नंबर *' : 'License Number *'}</label>
              <input type="text" value={formData.licenseNumber} onChange={(e) => setFormData({...formData, licenseNumber: e.target.value})} />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase">{language === 'hi' ? 'वाहन का नाम/मॉडल *' : 'Vehicle/Car/Bike Name/Model *'}</label>
              <input type="text" value={formData.carName} placeholder={language === 'hi' ? 'जैसे: Hero Splendor, Toyota Camry' : 'e.g. Hero Splendor, Toyota Camry'} onChange={(e) => setFormData({...formData, carName: e.target.value})} />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase">{language === 'hi' ? 'वाहन का प्रकार *' : 'Vehicle Type *'}</label>
              <select value={formData.carType} onChange={(e) => setFormData({...formData, carType: e.target.value})} className="bg-white">
                <option value="">{language === 'hi' ? '--चुनें--' : '--Select--'}</option>
                <option value="bike">{language === 'hi' ? 'बाइक / स्कूटर (Bike / Scooter)' : 'Bike / Scooter'}</option>
                <option value="hatchback">{language === 'hi' ? 'हैचबैक (Hatchback)' : 'Hatchback'}</option>
                <option value="sedan">{language === 'hi' ? 'सेडान (Sedan)' : 'Sedan'}</option>
                <option value="suv">{language === 'hi' ? 'एसयूवी (SUV)' : 'SUV'}</option>
                <option value="muv">{language === 'hi' ? 'एमयूवी (MUV/MPV)' : 'MUV / MPV'}</option>
                <option value="luxury">{language === 'hi' ? 'लक्जरी क्लास (Luxury)' : 'Luxury Class'}</option>
                <option value="other">{language === 'hi' ? 'अन्य प्रकार (Other)' : 'Other'}</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="p-4 border-2 border-dashed rounded-lg bg-white">
              <label className="block text-sm font-bold mb-2">{language === 'hi' ? 'ड्राइवर लाइसेंस (फोटो) *' : 'Driver License (Photo) *'}</label>
              <input 
                type="file" 
                accept="image/*" 
                onChange={(e) => handleFileChange(e, 'license')}
                className="text-xs w-full"
              />
              {files.license && (
                <div className="mt-2 relative h-32 w-full bg-gray-100 rounded overflow-hidden">
                  <img src={files.license} alt="License" className="h-full w-full object-contain" referrerPolicy="no-referrer" />
                </div>
              )}
            </div>
            <div className="p-4 border-2 border-dashed rounded-lg bg-white">
              <label className="block text-sm font-bold mb-2">{language === 'hi' ? 'वाहन पंजीकरण (RC) *' : 'Vehicle Registration (RC) *'}</label>
              <input 
                type="file" 
                accept="image/*" 
                onChange={(e) => handleFileChange(e, 'registration')}
                className="text-xs w-full"
              />
              {files.registration && (
                <div className="mt-2 relative h-32 w-full bg-gray-100 rounded overflow-hidden">
                  <img src={files.registration} alt="Registration" className="h-full w-full object-contain" referrerPolicy="no-referrer" />
                </div>
              )}
            </div>
            <div className="p-4 border-2 border-dashed rounded-lg bg-white">
              <label className="block text-sm font-bold mb-2">{language === 'hi' ? 'वाहन की छवि *' : 'Vehicle Image *'}</label>
              <input 
                type="file" 
                accept="image/*" 
                onChange={(e) => handleFileChange(e, 'carImage')}
                className="text-xs w-full"
              />
              {files.carImage && (
                <div className="mt-2 relative h-32 w-full bg-gray-100 rounded overflow-hidden">
                  <img src={files.carImage} alt="Vehicle" className="h-full w-full object-contain" referrerPolicy="no-referrer" />
                </div>
              )}
            </div>
          </div>

          <button 
            onClick={submit} 
            disabled={uploading}
            className={`w-full py-3 font-bold flex items-center justify-center gap-2 ${uploading ? 'bg-gray-400 cursor-not-allowed' : ''}`}
          >
            {uploading && <LoadingSpinner size="sm" color="white" />}
            {uploading ? (language === 'hi' ? 'अपलोड हो रहा है...' : 'Uploading...') : (language === 'hi' ? 'सत्यापन के लिए जमा करें' : 'Submit for Verification')}
          </button>
        </div>
      )}

      {status === 'pending' && (
        <div className="p-10 text-center bg-amber-50 border border-amber-200 rounded-xl">
          <div className="text-4xl mb-4">⏳</div>
          <h3 className="font-bold text-amber-800 mb-2">{language === 'hi' ? 'सत्यापन प्रगति पर है' : 'Verification in Progress'}</h3>
          <p className="text-amber-700">{language === 'hi' ? 'हमारी टीम आपके दस्तावेजों की समीक्षा कर रही है। इसमें आमतौर पर 24-48 घंटे लगते हैं। अनुमोदित होने पर आपको सूचित किया जाएगा!' : "Our team is reviewing your documents. This usually takes 24-48 hours. You'll be notified once approved!"}</p>
        </div>
      )}

      {status === 'approved' && (
        <div className="p-10 text-center bg-green-50 border border-green-200 rounded-xl">
          <div className="text-4xl mb-4">✅</div>
          <h3 className="font-bold text-green-800 mb-2">{language === 'hi' ? 'सत्यापित ड्राइवर' : 'Verified Driver'}</h3>
          <p className="text-green-700">{language === 'hi' ? 'बधाई हो! आप एक सत्यापित ड्राइवर हैं। अब आप सवारी की पेशकश कर सकते हैं और यात्रियों के साथ विश्वास बना सकते हैं।' : 'Congratulations! You are a verified driver. You can now offer rides and build trust with passengers.'}</p>
        </div>
      )}
    </div>
  );
};
