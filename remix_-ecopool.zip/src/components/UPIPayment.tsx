import React from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { TRANSLATIONS } from '../constants';
import { CheckCircle, Copy, Smartphone } from 'lucide-react';
import { LoadingSpinner } from './LoadingSpinner';

interface UPIPaymentProps {
  amount: number;
  onSuccess: (paymentId: string) => void;
  onCancel: () => void;
  language: string;
  showNotification: (msg: string, color?: string) => void;
}

export const UPIPayment: React.FC<UPIPaymentProps> = ({ amount, onSuccess, onCancel, language, showNotification }) => {
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;
  const [isVerifying, setIsVerifying] = React.useState(false);
  const [copied, setCopied] = React.useState(false);
  
  const upiId = "abbasjafri333@oksbi"; // Updated UPI ID
  const merchantName = "Samad Abbas Jafri";
  const upiUrl = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(merchantName)}&am=${amount.toFixed(2)}&cu=INR&tn=RideBooking&mc=0000&mode=02&purpose=00`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleVerify = async () => {
    setIsVerifying(true);
    showNotification(language === 'hi' ? 'भुगतान सत्यापित किया जा रहा है...' : 'Verifying payment...', "#1565c0");
    
    // Simulate server-side verification
    try {
      const response = await fetch(`${window.location.origin}/api/verify-upi-payment`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount, upiId }),
      });
      
      if (!response.ok) {
        throw new Error(`Server responded with ${response.status}`);
      }

      const data = await response.json();
      if (data.success) {
        showNotification(language === 'hi' ? 'भुगतान सफल!' : 'Payment Successful!', "#43a047");
        onSuccess(data.transactionId);
      } else {
        showNotification(data.message || (language === 'hi' ? 'सत्यापन विफल रहा' : 'Verification failed'), "#e53935");
      }
    } catch (error) {
      console.error("Verification failed", error);
      showNotification(language === 'hi' ? 'नेटवर्क त्रुटि या सर्वर अनुपलब्ध' : 'Network error or server unavailable', "#e53935");
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="p-8 bg-white rounded-2xl shadow-xl max-w-md mx-auto border border-gray-100 flex flex-col items-center">
      <h3 className="text-2xl font-bold mb-2 text-gray-800 text-center">
        {language === 'hi' ? 'UPI से भुगतान करें' : 'Pay with UPI'}
      </h3>
      <p className="text-sm text-gray-500 mb-6 text-center">
        {language === 'hi' ? 'QR कोड स्कैन करें या UPI ID का उपयोग करें' : 'Scan QR code or use UPI ID to pay'}
      </p>
      
      <div className="w-full mb-6 p-4 bg-emerald-50 rounded-xl border border-emerald-100 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/State_Bank_of_India_logo.svg/1200px-State_Bank_of_India_logo.svg.png" alt="SBI" className="h-6 w-6 object-contain" referrerPolicy="no-referrer" />
          <div className="flex flex-col">
            <span className="text-emerald-800 font-semibold">{t.totalAmount}</span>
            <span className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider">State Bank of India • {merchantName}</span>
          </div>
        </div>
        <span className="text-2xl font-black text-emerald-900">₹{amount}</span>
      </div>

      <div className="bg-white p-4 rounded-2xl border-2 border-gray-100 mb-6 shadow-sm">
        <QRCodeSVG 
          value={upiUrl} 
          size={200} 
          includeMargin={true} 
          level="H" 
          imageSettings={{
            src: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Google_Pay_Logo.svg/1200px-Google_Pay_Logo.svg.png",
            height: 30,
            width: 30,
            excavate: true,
          }}
        />
      </div>

      <div className="w-full space-y-4">
        {isVerifying && (
          <LoadingSpinner fullScreen label={language === 'hi' ? 'भुगतान सत्यापित किया जा रहा है...' : 'Verifying your payment...'} />
        )}
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-200">
          <div className="flex items-center gap-2">
            <Smartphone size={18} className="text-gray-400" />
            <span className="text-sm font-medium text-gray-700">{upiId}</span>
          </div>
          <button 
            onClick={copyToClipboard}
            className="text-emerald-600 hover:text-emerald-700 p-1 transition-colors"
          >
            {copied ? <CheckCircle size={18} /> : <Copy size={18} />}
          </button>
        </div>

        <button 
          onClick={handleVerify}
          disabled={isVerifying}
          className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-300 text-white py-4 rounded-xl font-bold text-lg shadow-lg shadow-emerald-200 transition-all flex items-center justify-center gap-2"
        >
          {isVerifying ? (
            <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            language === 'hi' ? 'भुगतान सत्यापित करें' : 'Verify Payment'
          )}
        </button>

        <button 
          type="button"
          onClick={onCancel}
          className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 rounded-xl font-bold transition-all"
        >
          {language === 'hi' ? 'रद्द करें' : 'Cancel'}
        </button>
      </div>
      
      <div className="mt-8 flex items-center gap-4 opacity-40 grayscale">
        <img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/UPI-Logo.png" alt="UPI" className="h-6" referrerPolicy="no-referrer" />
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Google_Pay_Logo.svg/1200px-Google_Pay_Logo.svg.png" alt="GPay" className="h-4" referrerPolicy="no-referrer" />
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/PhonePe_Logo.svg/1200px-PhonePe_Logo.svg.png" alt="PhonePe" className="h-4" referrerPolicy="no-referrer" />
      </div>
    </div>
  );
};
