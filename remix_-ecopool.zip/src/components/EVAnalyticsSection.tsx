import React from 'react';
import { Ride, User } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import { db, collection, getDocs, handleFirestoreError, OperationType } from '../firebase';

interface EVAnalyticsSectionProps {
  currentUser: string;
  showNotification: (msg: string, color?: string) => void;
  language: string;
}

export const EVAnalyticsSection: React.FC<EVAnalyticsSectionProps> = ({ currentUser, showNotification, language }) => {
  const [stats, setStats] = React.useState<any>({});
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    if (!currentUser) return;
    const fetchEVData = async () => {
      setLoading(true);
      try {
        const ridesSnapshot = await getDocs(collection(db, 'rides'));
        const rides = ridesSnapshot.docs.map(doc => doc.data() as Ride);
        const evRides = rides.filter((r: Ride) => r.isEV);
        const carbonPerRide = 3.8;
        const totalEVCarbonSaved = evRides.length * carbonPerRide;
        
        const usersSnapshot = await getDocs(collection(db, 'users'));
        const users = usersSnapshot.docs.map(doc => doc.data() as User);
        const totalCarbonSaved = users.reduce((sum: number, u: User) => sum + (u.carbonSaved || 0), 0);

        setStats({
          evRidesCount: evRides.length,
          totalEVCarbonSaved,
          evDrivers: new Set(evRides.map((r: Ride) => r.driver)).size,
          treesEquivalent: (totalEVCarbonSaved / 22).toFixed(1),
          totalCarbonSaved
        });
      } catch (error) {
        console.error("Error fetching EV data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchEVData();
  }, [currentUser]);

  return (
    <div id="evAnalyticsSection">
      <h2 className="text-xl font-bold mb-4">🌿 {language === 'hi' ? 'ईवी और ग्रीन मोबिलिटी एनालिटिक्स' : 'EV & Green Mobility Analytics'}</h2>
      
      {loading ? (
        <div className="py-20">
          <LoadingSpinner label={language === 'hi' ? 'एनालिटिक्स लोड हो रहा है...' : 'Loading analytics...'} />
        </div>
      ) : (
        <>
          <div className="stats-grid mb-6">
        <div className="stat-card" style={{background: 'linear-gradient(135deg, #4CAF50, #2E7D32)'}}>
          <h3>{language === 'hi' ? 'ईवी सवारी' : 'EV Rides'}</h3>
          <div className="number">{stats.evRidesCount || 0}</div>
          <p>{language === 'hi' ? 'कुल ईवी यात्राएं' : 'Total EV trips'}</p>
        </div>
        <div className="stat-card" style={{background: 'linear-gradient(135deg, #66BB6A, #388E3C)'}}>
          <h3>{language === 'hi' ? 'कार्बन बचाया' : 'Carbon Saved'}</h3>
          <div className="number">{(stats.totalEVCarbonSaved || 0).toFixed(1)} kg</div>
          <p>{language === 'hi' ? 'ईवी सवारी से' : 'From EV rides'}</p>
        </div>
        <div className="stat-card" style={{background: 'linear-gradient(135deg, #7CB342, #558B2F)'}}>
          <h3>{language === 'hi' ? 'ईवी बेड़ा' : 'EV Fleet'}</h3>
          <div className="number">{stats.evDrivers || 0}</div>
          <p>{language === 'hi' ? 'ईवी ड्राइवर' : 'EV Drivers'}</p>
        </div>
      </div>

      <div className="carbon-analytics p-6 bg-green-900 text-white rounded-xl mb-6">
        <h4 className="font-bold border-b border-white/20 pb-2 mb-4">{language === 'hi' ? 'पर्यावरण प्रभाव डैशबोर्ड' : 'Environmental Impact Dashboard'}</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h5 className="text-sm opacity-80 mb-1">{language === 'hi' ? 'कुल CO₂ बचाया (सभी सवारी)' : 'Total CO₂ Saved (All Rides)'}</h5>
            <div className="text-3xl font-bold">{(stats.totalCarbonSaved || 0).toFixed(1)} kg</div>
          </div>
          <div>
            <h5 className="text-sm opacity-80 mb-1">{language === 'hi' ? 'पेड़ों के बराबर' : 'Trees Equivalent'}</h5>
            <div className="text-3xl font-bold">🌳 {stats.treesEquivalent || 0} {language === 'hi' ? 'पेड़' : 'trees'}</div>
          </div>
        </div>
        <p className="mt-4 text-xs opacity-70">{language === 'hi' ? 'प्रत्येक ईवी सवारी एक नियमित कार की तुलना में लगभग 3.8 किलोग्राम CO₂ बचाती है। एक परिपक्व पेड़ प्रति वर्ष लगभग 22 किलोग्राम CO₂ सोखता है।' : 'Each EV ride saves approximately 3.8kg CO₂ compared to a regular car. One mature tree absorbs about 22kg CO₂ per year.'}</p>
      </div>
    </>
    )}
    </div>
  );
};
