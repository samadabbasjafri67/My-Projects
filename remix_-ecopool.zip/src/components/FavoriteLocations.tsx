import React from 'react';
import { motion } from 'motion/react';
import { Home, School, Briefcase, MapPin, Plus, X } from 'lucide-react';
import { db, doc, updateDoc, arrayUnion, arrayRemove } from '../firebase';
import { User } from '../types';

interface FavoriteLocationsProps {
  user: User;
  userId: string;
  language: string;
  onSelect: (address: string) => void;
  suggestedHint?: any;
}

export const FavoriteLocations: React.FC<FavoriteLocationsProps> = ({ user, userId, language, onSelect, suggestedHint }) => {
  const [showAdd, setShowAdd] = React.useState(false);
  const [newAddress, setNewAddress] = React.useState("");
  const [newLabel, setNewLabel] = React.useState<'Home' | 'College' | 'Work' | 'Other'>('Home');

  const isHindi = language === 'hi';

  const icons = {
    Home: <Home size={16} />,
    College: <School size={16} />,
    Work: <Briefcase size={16} />,
    Other: <MapPin size={16} />
  };

  const labels = {
    Home: isHindi ? "घर" : "Home",
    College: isHindi ? "कॉलेज" : "College",
    Work: isHindi ? "काम" : "Work",
    Other: isHindi ? "अन्य" : "Other"
  };

  const addLocation = async (label: any, addr: string) => {
    if (!addr.trim()) return;
    const newLoc = {
      id: Math.random().toString(36).substr(2, 9),
      label: label,
      address: addr
    };

    try {
      await updateDoc(doc(db, 'users', userId), {
        frequentLocations: arrayUnion(newLoc)
      });
      setNewAddress("");
      setShowAdd(false);
    } catch (e) {
      console.error(e);
    }
  };

  const removeLocation = async (loc: any) => {
    try {
      await updateDoc(doc(db, 'users', userId), {
        frequentLocations: arrayRemove(loc)
      });
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
          📍 {isHindi ? 'पसंदीदा स्थान' : 'Favorite Locations'}
        </h4>
        {!showAdd && (
          <button 
            onClick={() => setShowAdd(true)}
            className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:bg-blue-50 px-2 py-1 rounded-lg transition-all"
          >
            + {isHindi ? 'जोड़ें' : 'Add New'}
          </button>
        )}
      </div>

      <div className="flex flex-wrap gap-3">
        {user.frequentLocations?.map((loc) => (
          <motion.div 
            key={loc.id}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="group relative"
          >
            <button
              onClick={() => onSelect(loc.address)}
              className="bg-white border border-slate-200 p-2.5 pr-5 pl-4 rounded-3xl shadow-sm hover:shadow-md hover:border-primary/40 hover:-translate-y-0.5 transition-all flex items-center gap-3"
            >
              <div className="bg-slate-50 p-2 rounded-2xl text-slate-400 group-hover:text-primary transition-colors">
                {icons[loc.label]}
              </div>
              <div className="text-left">
                <div className="text-[10px] font-black uppercase tracking-widest text-slate-900">{labels[loc.label]}</div>
                <div className="text-[10px] font-bold text-slate-400 max-w-[130px] truncate">{loc.address}</div>
              </div>
            </button>
            <button 
              onClick={(e) => { e.stopPropagation(); removeLocation(loc); }}
              className="absolute -top-1.5 -right-1.5 w-6 h-6 bg-white text-slate-400 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity border border-slate-100 shadow-sm hover:text-red-500 hover:bg-red-50"
            >
              <X size={12} />
            </button>
          </motion.div>
        ))}

        {suggestedHint && !user.frequentLocations?.some(l => l.address === suggestedHint.to) && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-2 bg-blue-50/50 border border-blue-100 border-dashed p-2.5 rounded-3xl"
          >
             <div className="bg-blue-100 p-2 rounded-2xl text-blue-600">
               <School size={16} />
             </div>
             <div className="text-left">
               <div className="text-[9px] font-black uppercase tracking-widest text-blue-900">{isHindi ? 'सुझाव: कॉलेज?' : 'Suggest: College?'}</div>
               <div className="text-[10px] font-bold text-blue-700 max-w-[100px] truncate">{suggestedHint.to}</div>
             </div>
             <button 
               onClick={() => addLocation('College', suggestedHint.to)}
               className="bg-blue-600 text-white p-1 rounded-full hover:bg-blue-700 transition-colors"
             >
               <Plus size={12} />
             </button>
          </motion.div>
        )}

        {user.frequentLocations?.length === 0 && !showAdd && !suggestedHint && (
          <p className="text-[10px] text-slate-400 font-medium italic">
            {isHindi ? 'कोई पसंदीदा स्थान नहीं बचा है' : 'No favorites saved yet'}
          </p>
        )}
      </div>

      {showAdd && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-50 p-4 rounded-3xl border border-slate-200 shadow-inner space-y-4"
        >
          <div className="flex gap-2">
            {(['Home', 'College', 'Work', 'Other'] as const).map((l) => (
              <button
                key={l}
                onClick={() => setNewLabel(l)}
                className={`flex-1 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${newLabel === l ? 'bg-slate-900 text-white shadow-xl shadow-slate-200' : 'bg-white text-slate-400 border border-slate-100'}`}
              >
                {labels[l]}
              </button>
            ))}
          </div>
          <div className="flex gap-3">
            <input 
              type="text" 
              placeholder={isHindi ? "पता दर्ज करें..." : "Enter address..."}
              value={newAddress}
              onChange={(e) => setNewAddress(e.target.value)}
              className="flex-1 text-xs font-bold p-3 rounded-2xl bg-white border-2 border-slate-100 focus:border-primary focus:ring-0 transition-all"
            />
            <button 
              onClick={() => addLocation(newLabel, newAddress)}
              className="px-6 bg-primary hover:bg-primary-dark text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-blue-100 transition-all"
            >
              {isHindi ? 'बचाएं' : 'Save'}
            </button>
            <button 
              onClick={() => setShowAdd(false)}
              className="p-3 text-slate-400 hover:text-slate-600 bg-white rounded-2xl border border-slate-100"
            >
              <X size={18} />
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
};
