import React from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-routing-machine/dist/leaflet-routing-machine.css';
import 'leaflet-routing-machine';
import { Ride } from '../types';
import { TRANSLATIONS } from '../constants';
import { LoadingSpinner } from './LoadingSpinner';
import { Navigation, MapPin, Car } from 'lucide-react';

interface LiveDriverMapProps {
  ride: Ride;
  language: string;
}

// Fix Leaflet default icon issue with Vite
if (typeof window !== 'undefined') {
  delete (L.Icon.Default.prototype as any)._getIconUrl;
  L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
    iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  });
}

export const LiveDriverMap: React.FC<LiveDriverMapProps> = ({ ride, language }) => {
  const mapContainerRef = React.useRef<HTMLDivElement>(null);
  const mapRef = React.useRef<L.Map | null>(null);
  const driverMarkerRef = React.useRef<L.Marker | null>(null);
  const routingControlRef = React.useRef<any>(null);
  const [pickupCoords, setPickupCoords] = React.useState<[number, number] | null>(null);
  const [isGeocoding, setIsGeocoding] = React.useState(true);
  const [simulatedLoc, setSimulatedLoc] = React.useState<{lat: number, lng: number} | null>(null);
  
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  // Sync simulated location with real location initially
  React.useEffect(() => {
    if (ride.currentLocation) {
      setSimulatedLoc({ lat: ride.currentLocation.lat, lng: ride.currentLocation.lng });
    }
  }, [ride.currentLocation?.lat, ride.currentLocation?.lng]);

  // Small jitter simulation for "alive" feel
  React.useEffect(() => {
    if (!simulatedLoc || !ride.currentLocation) return;
    
    const interval = setInterval(() => {
      setSimulatedLoc(prev => {
        if (!prev) return null;
        return {
          lat: prev.lat + (Math.random() - 0.5) * 0.00005,
          lng: prev.lng + (Math.random() - 0.5) * 0.00005
        };
      });
    }, 3000);

    return () => clearInterval(interval);
  }, [!!simulatedLoc, !!ride.currentLocation]);

  // Initialize Map
  React.useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapRef.current) {
      mapRef.current = L.map(mapContainerRef.current, { zoomControl: false }).setView([28.6139, 77.2090], 13);
      L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO'
      }).addTo(mapRef.current);
      L.control.zoom({ position: 'topright' }).addTo(mapRef.current);
    }

    return () => {
      // We don't necessarily want to destroy it on every re-render, 
      // but if the component unmounts we should cleanup.
    };
  }, []);

  // Geocode Pickup Point
  React.useEffect(() => {
    if (ride.fromCoords) {
      setPickupCoords([ride.fromCoords.lat, ride.fromCoords.lng]);
      setIsGeocoding(false);
      return;
    }

    const geocode = async (query: string) => {
      try {
        setIsGeocoding(true);
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`);
        const data = await response.json();
        if (data && data.length > 0) {
          setPickupCoords([parseFloat(data[0].lat), parseFloat(data[0].lon)]);
        }
      } catch (err) {
        console.error("Geocoding error:", err);
      } finally {
        setIsGeocoding(false);
      }
    };

    if (ride.from) {
      geocode(ride.from);
    }
  }, [ride.from]);

  // Update Driver Location and Route
  React.useEffect(() => {
    if (!mapRef.current || !pickupCoords) return;

    const map = mapRef.current;
    const driverLoc = ride.currentLocation;

    // 1. Manage Pickup Marker (Fixed)
    const pickupIcon = L.divIcon({
      className: 'pickup-marker',
      html: `<div style="background-color: #2563eb; color: white; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid white; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
             </div>`,
      iconSize: [32, 32],
      iconAnchor: [16, 16]
    });

    L.marker(pickupCoords, { icon: pickupIcon }).addTo(map).bindPopup(t.pickupLocation);

    // 2. Manage Driver Marker
    const currentLoc = simulatedLoc || ride.currentLocation;
    if (currentLoc) {
      const driverPos: [number, number] = [currentLoc.lat, currentLoc.lng];
      
      const carIcon = L.divIcon({
        className: 'car-marker',
        html: `<div style="background-color: #059669; color: white; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid white; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); transform: rotate(${Math.random() * 360}deg);">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/></svg>
               </div>`,
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      });

      if (!driverMarkerRef.current) {
        driverMarkerRef.current = L.marker(driverPos, { icon: carIcon }).addTo(map).bindPopup(t.driverLocation);
      } else {
        driverMarkerRef.current.setLatLng(driverPos);
      }

      // 3. Update Route from Driver to Pickup
      if (routingControlRef.current) {
        map.removeControl(routingControlRef.current);
      }

      routingControlRef.current = (L as any).Routing.control({
        waypoints: [
          L.latLng(driverPos[0], driverPos[1]),
          L.latLng(pickupCoords[0], pickupCoords[1])
        ],
        lineOptions: {
          styles: [{ color: '#2563eb', weight: 4, opacity: 0.6 }]
        },
        createMarker: () => null,
        addWaypoints: false,
        draggableWaypoints: false,
        fitSelectedRoutes: true,
        show: false
      }).addTo(map);

    } else {
      // No driver location yet, just center on pickup
      map.setView(pickupCoords, 14);
    }

  }, [pickupCoords, ride.currentLocation]);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
          <Navigation size={12} className="text-primary" />
          {t.liveTracking}
        </h4>
        <div className="flex items-center gap-2">
          {ride.currentLocation ? (
            <span className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full animate-pulse">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
              {t.driverOnWay}
            </span>
          ) : (
            <span className="text-[10px] font-bold text-slate-400 bg-slate-50 px-2 py-0.5 rounded-full">
              {t.driverNotStarted}
            </span>
          )}
        </div>
      </div>
      
      <div className="relative w-full h-64 rounded-xl border border-slate-200 overflow-hidden shadow-inner bg-slate-50">
        {isGeocoding && (
          <div className="absolute inset-0 z-[1001] bg-white/60 backdrop-blur-sm flex items-center justify-center">
            <LoadingSpinner size="sm" />
          </div>
        )}
        <div ref={mapContainerRef} className="w-full h-full z-0"></div>
        
        {ride.currentLocation && (
          <div className="absolute bottom-3 left-3 z-[1000]">
             <div className="bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-100 shadow-sm flex items-center gap-2">
                <Car size={14} className="text-emerald-600" />
                <span className="text-[10px] font-black text-slate-700 tracking-tight">
                  {t.driverLocation} @ {new Date(ride.currentLocation.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};
