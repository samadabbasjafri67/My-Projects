import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TRANSLATIONS, AMENITIES, EV_CHARGING_STATIONS } from '../constants';
import { Ride } from '../types';
import { db, collection, query, onSnapshot, where, handleFirestoreError, OperationType } from '../firebase';
import { RouteMap } from './RouteMap';
import { LoadingSpinner } from './LoadingSpinner';
import { LiveDriverMap } from './LiveDriverMap';
import { NearbyDriversMap } from './NearbyDriversMap';
import { FavoriteLocations } from './FavoriteLocations';
import { DecisionIntelligenceBadge } from './DecisionIntelligenceBadge';
import { ScenarioSuggestionBadge } from './ScenarioSuggestionBadge';
import { UncertaintyIndicator } from './UncertaintyIndicator';
import { Map as MapIcon, Navigation, ChevronDown, ChevronUp, Car, ShieldCheck, Info, Search, BarChart3, Sparkles, BrainCircuit, Users, Scale, Heart, Lightbulb, ShieldAlert } from 'lucide-react';
import { PredictiveSuggestion } from './PredictiveSuggestion';
import { PredictiveHint, PredictionService } from '../services/predictionService';
import { DecisionIntelligenceService } from '../services/decisionIntelligenceService';
import { FairMatchingService } from '../services/fairMatchingService';
import { ScenarioSuggestionService } from '../services/scenarioSuggestionService';
import { UncertaintyService } from '../services/uncertaintyService';
import { PreferenceLearningService } from '../services/preferenceLearningService';
import { User, Booking } from '../types';
import { getDoc, doc as firestoreDoc } from 'firebase/firestore';

interface SearchSectionProps {
  currentUser: string | null;
  showNotification: (msg: string, color?: string) => void;
  onStartBooking: (ride: Ride) => void;
  language: string;
  onNavigateToSection?: (section: string) => void;
  initialPoolType?: 'all' | 'car' | 'bike' | 'ev';
  clearInitialPoolType?: () => void;
}

export const SearchSection: React.FC<SearchSectionProps> = ({ 
  currentUser, 
  showNotification, 
  onStartBooking, 
  language,
  onNavigateToSection,
  initialPoolType,
  clearInitialPoolType
}) => {
  const [searchFrom, setSearchFrom] = React.useState("");
  const [searchTo, setSearchTo] = React.useState("");
  const [searchDate, setSearchDate] = React.useState("");
  const [searchTime, setSearchTime] = React.useState("");
  const [minPrice, setMinPrice] = React.useState("");
  const [maxPrice, setMaxPrice] = React.useState("");
  const [searchAmenities, setSearchAmenities] = React.useState<string[]>([]);
  const [allRides, setAllRides] = React.useState<Ride[]>([]);
  const [searchResults, setSearchResults] = React.useState<Ride[]>([]);
  const [useSmartMatching, setUseSmartMatching] = React.useState(true);
  const [minRating, setMinRating] = React.useState(0);
  const [sortBy, setSortBy] = React.useState("relevance");
  const [timeFilter, setTimeFilter] = React.useState("all");
  const [tripTypeFilter, setTripTypeFilter] = React.useState<'all' | 'ride' | 'parcel'>('all');
  const [poolTypeFilter, setPoolTypeFilter] = React.useState<'all' | 'car' | 'bike' | 'ev'>('all');
  
  React.useEffect(() => {
    if (initialPoolType) {
      setPoolTypeFilter(initialPoolType);
      if (clearInitialPoolType) clearInitialPoolType();
    }
  }, [initialPoolType, clearInitialPoolType]);

  const [evOnly, setEvOnly] = React.useState(false);
  const [womenOnly, setWomenOnly] = React.useState(false);
  const [showChargingStations, setShowChargingStations] = React.useState(false);
  const [chargingStations, setChargingStations] = React.useState<any[]>([]);
  const [driverRatings, setDriverRatings] = React.useState<any[]>([]);
  const [driverRides, setDriverRides] = React.useState<Record<string, number>>({});
  const [driverProfiles, setDriverProfiles] = React.useState<Record<string, User>>({});
  const [rawOnlineUsers, setRawOnlineUsers] = React.useState<any[]>([]);
  const [userGeoLocation, setUserGeoLocation] = React.useState<{lat: number, lng: number} | null>(null);

  React.useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setUserGeoLocation({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude
          });
        },
        () => {}
      );
    }
  }, []);

  const onlineDrivers = React.useMemo(() => {
    const driversMap = new Map<string, any>();

    // 1. Add any users from firestore whose status is 'online'
    rawOnlineUsers.forEach((user) => {
      if (user.currentLocation) {
        driversMap.set(user.id, {
          id: user.id,
          username: user.username || user.fullName || "Driver",
          fullName: user.fullName || user.username || "Driver",
          status: 'online',
          totalRides: user.totalRides || 12,
          rating: user.rating || 4.8,
          currentLocation: user.currentLocation
        });
      }
    });

    // 2. Add drivers of any active rides in allRides
    allRides.forEach((ride) => {
      if (!ride.driver) return;
      const dUid = ride.driver;
      const profile = driverProfiles[dUid];

      // Use the best available location coordinates of the ride
      const loc = profile?.currentLocation || ride.currentLocation || ride.fromCoords;

      if (loc && loc.lat && loc.lng) {
        // Prevent duplicate entries for the same driver, prioritizing their active ride location
        driversMap.set(dUid, {
          id: dUid,
          username: profile?.username || ride.driver || "Driver",
          fullName: profile?.fullName || profile?.username || ride.driver || "Driver",
          status: 'online',
          totalRides: profile?.totalRides || 45,
          rating: profile?.rating || ride.averageRating || 4.8,
          currentLocation: {
            lat: loc.lat,
            lng: loc.lng,
            timestamp: loc.timestamp || new Date().toISOString()
          }
        });
      }
    });

    // 3. Adhere strictly to the "Use real driver only" directive. No fallback mock drivers are generated when there are 0 real drivers online.
    return Array.from(driversMap.values());
  }, [rawOnlineUsers, allRides, driverProfiles, userGeoLocation]);

  const [selectedRideForMap, setSelectedRideForMap] = React.useState<Ride | null>(null);
  const [expandedRideId, setExpandedRideId] = React.useState<string | number | null>(null);
  const [loadingRides, setLoadingRides] = React.useState(true);
  const [showNearbyDrivers, setShowNearbyDrivers] = React.useState(true);
  const [userProfile, setUserProfile] = React.useState<User | null>(null);
  const [activeHint, setActiveHint] = React.useState<PredictiveHint | null>(null);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const handleServiceTypeChange = (type: 'all' | 'ride' | 'parcel') => {
    setTripTypeFilter(type);
    // Trigger search automatically when filter changes
    searchRides();
  };

  const calculateETA = (ride: Ride) => {
    if (!ride.currentLocation || !ride.fromCoords) return null;

    // Freshness check: Location must be within last 5 minutes to be considered "currently on the way"
    const locTimestamp = new Date(ride.currentLocation.timestamp).getTime();
    const now = Date.now();
    if (now - locTimestamp > 5 * 60 * 1000) return null;

    const R = 6371; // Earth radius in km
    const dLat = (ride.fromCoords.lat - ride.currentLocation.lat) * (Math.PI / 180);
    const dLon = (ride.fromCoords.lng - ride.currentLocation.lng) * (Math.PI / 180);
    
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(ride.currentLocation.lat * (Math.PI / 180)) * Math.cos(ride.fromCoords.lat * (Math.PI / 180)) * 
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in km
    
    // Average urban speed: 30 km/h (0.5 km/min)
    // Multiplier for road distance (approx 1.4x straight line)
    const roadDistance = distance * 1.4;
    const etaMinutes = Math.round(roadDistance / 0.5);
    
    if (etaMinutes < 1) return language === 'hi' ? 'अभी' : 'Now';
    return `${etaMinutes} ${language === 'hi' ? 'मिनट' : 'mins'}`;
  };

  React.useEffect(() => {
    if (currentUser) {
      PredictionService.getRecentBookings(currentUser).then(bookings => {
        const hint = PredictionService.analyzePatterns(bookings, language);
        setActiveHint(hint);
        
        // Also learn preferences from these bookings
        PreferenceLearningService.updateLearnedPreferences(currentUser, bookings as any);
      });
    }
  }, [currentUser, language]);

  React.useEffect(() => {
    if (!currentUser) return;

    const q = query(collection(db, 'rides'));
    const unsubscribeRides = onSnapshot(q, (snapshot) => {
      const rides = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Ride));
      setAllRides(rides);
      setLoadingRides(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'rides');
      setLoadingRides(false);
    });

    const unsubscribeRatings = onSnapshot(collection(db, 'ratings'), (snapshot) => {
      const ratings = snapshot.docs.map(doc => doc.data());
      // Calculate average ratings per driver
      const driverMap: any = {};
      ratings.forEach((r: any) => {
        if (!driverMap[r.ratedUser]) driverMap[r.ratedUser] = { total: 0, count: 0 };
        driverMap[r.ratedUser].total += r.overall;
        driverMap[r.ratedUser].count += 1;
      });
      const summaries = Object.keys(driverMap).map(driver => ({
        driver,
        overall: driverMap[driver].total / driverMap[driver].count,
        count: driverMap[driver].count
      }));
      setDriverRatings(summaries);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'ratings');
    });

    const unsubscribeUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      const ridesMap: Record<string, number> = {};
      const profileMap: Record<string, User> = {};
      const online: any[] = [];
      const now = Date.now();
      
      snapshot.docs.forEach(doc => {
        const data = doc.data() as User;
        ridesMap[doc.id] = data.totalRides || 0;
        profileMap[doc.id] = { id: doc.id, ...data } as any;
        
        if (doc.id === currentUser) {
          setUserProfile({ id: doc.id, ...data } as any);
        }

        // Filter users who are online and active within 10 minutes
        const lastActive = data.lastActiveAt ? new Date(data.lastActiveAt).getTime() : 0;
        if (data.status === 'online' && (now - lastActive < 10 * 60 * 1000)) {
          online.push({ id: doc.id, ...data });
        }
      });
      setDriverRides(ridesMap);
      setDriverProfiles(profileMap);
      setRawOnlineUsers(online);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'users');
    });

    return () => {
      unsubscribeRides();
      unsubscribeRatings();
      unsubscribeUsers();
    };
  }, [currentUser]);

  React.useEffect(() => {
    searchRides();
  }, [allRides, poolTypeFilter, tripTypeFilter, evOnly, womenOnly, sortBy, timeFilter, minPrice, maxPrice]);

  const getDriverRatingInfo = (driverUid: string) => {
    return driverRatings.find((d: any) => d.driver === driverUid);
  };

  const getDriverRating = (driverUid: string) => {
    const info = getDriverRatingInfo(driverUid);
    return info ? info.overall : 0;
  };

  const toggleSearchAmenity = (value: string) => {
    setSearchAmenities(prev =>
      prev.includes(value)
        ? prev.filter(a => a !== value)
        : [...prev, value]
    );
  };

  const searchRides = () => {
    const from = searchFrom.trim().toLowerCase();
    const to = searchTo.trim().toLowerCase();
    const minPriceVal = parseFloat(minPrice) || 0;
    const maxPriceVal = parseFloat(maxPrice) || Infinity;
    const minRatingVal = parseFloat(minRating.toString()) || 0;

    let results = allRides.filter((r: Ride) => {
      const driverRating = getDriverRating(r.driver);
      
      // Inject rating for UI and Decision Intelligence Service
      (r as any).averageRating = driverRating;

      if (evOnly && !r.isEV && r.vehiclePoolType !== 'ev') return false;
      if (womenOnly && !r.womenOnly) return false;
      if (tripTypeFilter !== 'all' && (r.type || 'ride') !== tripTypeFilter) return false;
      
      // Pool Type filter implementation (Car Pool vs Bike Pool vs EV Pool)
      if (poolTypeFilter === 'bike' && r.vehiclePoolType !== 'bike') return false;
      if (poolTypeFilter === 'ev' && !r.isEV && r.vehiclePoolType !== 'ev') return false;
      if (poolTypeFilter === 'car' && r.vehiclePoolType === 'bike') return false;

      return (
        (!from || r.from.toLowerCase().includes(from)) &&
        (!to || r.to.toLowerCase().includes(to)) &&
        (!searchDate || r.date === searchDate) &&
        (!searchTime || r.time >= searchTime) &&
        (r.price >= minPriceVal && r.price <= maxPriceVal) &&
        (driverRating >= minRatingVal) &&
        (searchAmenities.length === 0 || searchAmenities.every(reqA => r.amenities && r.amenities.includes(reqA)))
      );
    });

    results = results.map((ride: Ride) => {
      let score = 0;
      const driverRating = getDriverRating(ride.driver);
      const driverProfile = driverProfiles[ride.driver];
      
      if (from && ride.from.toLowerCase().includes(from)) score += 30;
      if (to && ride.to.toLowerCase().includes(to)) score += 30;
      if (searchTime && ride.time === searchTime) score += 20;
      score += driverRating * 2;
      if (ride.isEV || ride.vehiclePoolType === 'ev') score += 15;

      // Apply Fairness Priority Boost
      const fairnessBoost = FairMatchingService.calculateFairnessPriority(ride, driverProfile);
      score += fairnessBoost;

      // Apply Personal Preference Boost
      const prefBoost = PreferenceLearningService.calculatePreferenceMatch(ride, userProfile?.learnedPreferences);
      score += prefBoost;

      // Compute elegant & robust Ride Compatibility Score (0 - 100)
      let comp = 65; // High-quality base compatibility for validated matches
      
      // 1. Driver verification status
      if (ride.driverVerified || driverProfile?.isVerified) {
        comp += 12;
      }

      // 2. Helmet option for bike pools (which makes them extra score-boosted)
      if (ride.vehiclePoolType === 'bike') {
        if (ride.helmetAvailable) {
          comp += 10;
        } else {
          comp += 3;
        }
      }

      // 3. EV environment match bonus
      if (ride.isEV || ride.vehiclePoolType === 'ev') {
        comp += 8;
      }

      // 4. Female friendly / Women only match
      if (ride.womenOnly) {
        comp += 10;
      }

      // 5. Shared commuter affinity matching (office commuter, college student)
      const isStudentMatch = (ride.from.toLowerCase().includes('college') || ride.to.toLowerCase().includes('college') || ride.from.toLowerCase().includes('university') || ride.to.toLowerCase().includes('university'));
      const isOfficeMatch = (ride.from.toLowerCase().includes('office') || ride.to.toLowerCase().includes('office') || ride.from.toLowerCase().includes('it park') || ride.to.toLowerCase().includes('it park') || ride.from.toLowerCase().includes('cyber'));
      if (isStudentMatch || isOfficeMatch) {
         comp += 8;
      }

      // 6. Rating adjustment
      if (driverRating >= 4.5) {
        comp += 7;
      }

      const compatibilityScore = Math.min(Math.max(comp, 65), 98); // Lock between premium 65% and elite 98%
      (ride as any).compatibilityScore = compatibilityScore;

      return { ...ride, matchScore: score || compatibilityScore };
    });

    // Sorting
    if (sortBy === "price_low") results.sort((a, b) => a.price - b.price);
    else if (sortBy === "price_high") results.sort((a, b) => b.price - a.price);
    else if (sortBy === "time_early") results.sort((a, b) => a.time.localeCompare(b.time));
    else if (sortBy === "rating") results.sort((a, b) => getDriverRating(b.driver) - getDriverRating(a.driver));
    else if (sortBy === "relevance" && useSmartMatching) results.sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0));

    // Time filter
    if (timeFilter === "morning") results = results.filter((r: Ride) => r.time >= "06:00" && r.time <= "12:00");
    else if (timeFilter === "afternoon") results = results.filter((r: Ride) => r.time >= "12:00" && r.time <= "17:00");
    else if (timeFilter === "evening") results = results.filter((r: Ride) => r.time >= "17:00" && r.time <= "21:00");
    else if (timeFilter === "night") results = results.filter((r: Ride) => r.time >= "21:00" || r.time <= "06:00");

    setSearchResults(results);

    if (evOnly && from && to) {
      const stations = EV_CHARGING_STATIONS.filter(station => {
        const stationName = station.name.toLowerCase();
        return stationName.includes(from) || stationName.includes(to);
      });
      setChargingStations(stations);
      setShowChargingStations(true);
    } else {
      setShowChargingStations(false);
    }
  };

  const handleApplySuggestion = (hint: PredictiveHint) => {
    setSearchFrom(hint.from);
    setSearchTo(hint.to);
    setSearchTime(hint.timeSlot);
    const today = new Date().toISOString().split('T')[0];
    setSearchDate(today);
    
    // Automatically trigger search after state updates
    setTimeout(() => {
      searchRides();
      showNotification(language === 'hi' ? 'सुझाव लागू किया गया' : 'Suggestion applied', '#43a047');
    }, 100);
  };

  return (
    <div id="searchSection" className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">{t.searchRide}</h2>
          <p className="text-slate-500 mt-1">{language === 'hi' ? 'अपनी अगली यात्रा के लिए सबसे अच्छी सवारी खोजें' : 'Find the best ride for your next journey'}</p>
        </div>
        <div className="bg-blue-50 px-4 py-2 rounded-xl border border-blue-100 flex items-center gap-3">
          <div className="bg-blue-600 p-1.5 rounded-lg text-white">
            <ShieldCheck size={18} />
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-bold text-blue-900 uppercase tracking-wider">{language === 'hi' ? 'एआई-संचालित' : 'AI-Powered'}</span>
            <div className="flex items-center gap-2">
              <label className={`flex items-center gap-2 ${userProfile?.subscription?.plan !== 'premium' ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'}`}>
                <input
                  type="checkbox"
                  checked={useSmartMatching && userProfile?.subscription?.plan === 'premium'}
                  onChange={(e) => {
                    if (userProfile?.subscription?.plan !== 'premium') {
                      showNotification(language === 'hi' ? 'स्मार्ट मैचिंग के लिए प्रीमियम की आवश्यकता है' : 'Premium required for Smart Matching', '#ff9800');
                      return;
                    }
                    setUseSmartMatching(e.target.checked);
                  }}
                  disabled={userProfile?.subscription?.plan !== 'premium'}
                  className="w-4 h-4 rounded border-blue-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm font-medium text-blue-800">{language === 'hi' ? 'स्मार्ट मैचिंग' : 'Smart Matching'}</span>
              </label>
              {userProfile?.subscription?.plan !== 'premium' && (
                <div 
                  className="p-1 bg-amber-100 text-amber-700 rounded-lg cursor-pointer"
                  onClick={() => showNotification(language === 'hi' ? 'प्रीमियम के साथ स्मार्ट मैचिंग अनलॉक करें' : 'Unlock Smart Matching with Premium')}
                >
                  <Sparkles size={12} className="animate-pulse" />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {currentUser && (
        <PredictiveSuggestion 
          userId={currentUser} 
          language={language} 
          onApply={handleApplySuggestion} 
        />
      )}

      {currentUser && userProfile && (
        <FavoriteLocations 
          user={userProfile} 
          userId={currentUser} 
          language={language} 
          onSelect={(addr) => {
            if (!searchFrom && !searchTo) {
              setSearchTo(addr);
              showNotification(language === 'hi' ? 'गंतव्य के रूप में सेट करें' : 'Set as destination');
            } else if (!searchFrom) {
              setSearchFrom(addr);
            } else if (!searchTo) {
              setSearchTo(addr);
            } else {
              setSearchTo(addr);
            }
            
            // Auto-trigger search if we have both
            if ((searchFrom || addr) && (searchTo || addr)) {
               setTimeout(() => searchRides(), 100);
            }
          }}
          suggestedHint={activeHint}
        />
      )}

      {/* Fair Matching Research Explanation */}
      <div className="bg-slate-900 text-white p-6 rounded-3xl overflow-hidden relative group">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 blur-[100px] -mr-32 -mt-32 transition-all group-hover:bg-primary/30" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="flex items-center gap-2 text-primary">
              <Scale size={20} />
              <span className="text-[10px] font-black uppercase tracking-[0.2em]">{language === 'hi' ? 'अनुसंधान आधारित' : 'Research Driven'}</span>
            </div>
            <h3 className="text-xl font-black">{language === 'hi' ? 'उचित मिलान प्रणाली' : 'Fair Matching System'}</h3>
            <p className="text-xs text-slate-400 leading-relaxed font-medium">
              {language === 'hi' 
                ? 'हमारा एल्गोरिदम यह सुनिश्चित करता है कि नए ड्राइवरों और कम सेवा वाले उपयोगकर्ताओं को समान अवसर मिले। हम केवल रेटिंग पर निर्भर नहीं रहते, बल्कि "उचित अवसर" को प्राथमिकता देते हैं ताकि समुदाय का संतुलित विकास हो सके।' 
                : 'Our algorithm ensures new drivers and underserved users get equal opportunities. We don\'t just rely on ratings; we prioritize "fair chance" to ensure balanced community growth.'}
            </p>
          </div>
          <div className="flex -space-x-4">
            {[1,2,3,4].map(i => (
              <div key={i} className="w-12 h-12 rounded-2xl border-4 border-slate-900 bg-slate-800 flex items-center justify-center overflow-hidden grayscale hover:grayscale-0 transition-all cursor-help" title="Fairly Matched User">
                <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=fair${i}`} alt="User" />
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">{t.from}</label>
            <div className="relative">
              <Navigation className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder={t.from} 
                value={searchFrom} 
                onChange={(e) => setSearchFrom(e.target.value)} 
                className="pl-10"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">{t.to}</label>
            <div className="relative">
              <MapIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder={t.to} 
                value={searchTo} 
                onChange={(e) => setSearchTo(e.target.value)} 
                className="pl-10"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">{language === 'hi' ? 'तारीख' : 'Date'}</label>
            <input type="date" value={searchDate} onChange={(e) => setSearchDate(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">{language === 'hi' ? 'समय' : 'Time'}</label>
            <input type="time" value={searchTime} onChange={(e) => setSearchTime(e.target.value)} />
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100">
          <div className="flex flex-wrap items-center justify-between gap-6">
            <div className="flex flex-wrap items-center gap-6">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">{language === 'hi' ? 'कीमत सीमा' : 'Price Range'}</label>
                <div className="flex items-center gap-2">
                  <input type="number" placeholder="Min" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} className="w-24" />
                  <span className="text-slate-300">—</span>
                  <input type="number" placeholder="Max" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} className="w-24" />
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">{t.sortBy}</label>
                <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="w-48">
                  <option value="relevance">{t.relevance}</option>
                  <option value="price_low">{t.priceLow}</option>
                  <option value="price_high">{t.priceHigh}</option>
                  <option value="time_early">{t.timeEarly}</option>
                  <option value="rating">{t.highestRated}</option>
                </select>
              </div>
            </div>
            <button onClick={searchRides} className="px-8 py-3 bg-primary hover:bg-primary-dark text-white rounded-xl font-bold shadow-lg shadow-blue-200 transition-all flex items-center gap-2">
              <Search size={20} />
              {t.search}
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-4 pt-2">
          <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t.timeOfDay}:</span>
            <div className="flex gap-1">
              {['all', 'morning', 'afternoon', 'evening', 'night'].map(f => (
                <button
                  key={f}
                  className={`px-2 py-1 rounded text-xs font-bold transition-all ${
                    timeFilter === f 
                      ? "bg-white text-primary shadow-sm" 
                      : "text-slate-400 hover:text-slate-600"
                  }`}
                  onClick={() => setTimeFilter(f)}
                >
                  {f === 'all' ? t.all : f === 'morning' ? t.morning : f === 'afternoon' ? t.afternoon : f === 'evening' ? t.evening : t.night}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t.rideType}:</span>
            <div className="flex gap-1">
              {[
                { id: 'all', label: t.all },
                { id: 'ride', label: t.passengerRide },
                { id: 'parcel', label: t.parcelDelivery }
              ].map(f => (
                <button
                  key={f.id}
                  className={`px-2 py-1 rounded text-xs font-bold transition-all ${
                    tripTypeFilter === f.id 
                      ? "bg-white text-primary shadow-sm" 
                      : "text-slate-400 hover:text-slate-600"
                  }`}
                  onClick={() => setTripTypeFilter(f.id as any)}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 animate-fade-in">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">🛵 {language === 'hi' ? 'पूल प्रकार:' : 'Pool Type:'}</span>
            <div className="flex gap-1">
              {[
                { id: 'all', label: language === 'hi' ? 'सभी' : 'All Pools' },
                { id: 'car', label: language === 'hi' ? 'कार' : 'Car Pool' },
                { id: 'bike', label: language === 'hi' ? 'बाइक ⭐' : 'Bike Pool ⭐' },
                { id: 'ev', label: language === 'hi' ? 'ईवी' : 'EV Pool' }
              ].map(f => (
                <button
                  key={f.id}
                  className={`px-2 py-1 rounded text-xs font-bold transition-all ${
                    poolTypeFilter === f.id 
                      ? "bg-white text-primary shadow-sm font-black border border-slate-200" 
                      : "text-slate-400 hover:text-slate-600"
                  }`}
                  onClick={() => setPoolTypeFilter(f.id as any)}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
            <label className="flex items-center gap-2 cursor-pointer group">
              <input 
                type="checkbox" 
                checked={evOnly} 
                onChange={(e) => setEvOnly(e.target.checked)} 
                className="w-4 h-4 rounded border-slate-300 text-eco focus:ring-eco"
              />
              <span className="text-xs font-bold text-slate-600 group-hover:text-eco transition-colors">{t.evOnly}</span>
            </label>
            <div className="w-px h-4 bg-slate-200" />
            <label className="flex items-center gap-2 cursor-pointer group">
              <input 
                type="checkbox" 
                checked={womenOnly} 
                onChange={(e) => setWomenOnly(e.target.checked)} 
                className="w-4 h-4 rounded border-slate-300 text-pink-600 focus:ring-pink-500"
              />
              <span className="text-xs font-bold text-slate-600 group-hover:text-pink-600 transition-colors">{t.womenOnly}</span>
            </label>
            <div className="w-px h-4 bg-slate-200" />
            <label className="flex items-center gap-2 cursor-pointer group">
              <input 
                type="checkbox" 
                checked={showNearbyDrivers} 
                onChange={(e) => setShowNearbyDrivers(e.target.checked)} 
                className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-xs font-bold text-slate-600 group-hover:text-blue-600 transition-colors">
                {language === 'hi' ? 'सक्रिय चालक मैप' : 'Nearby Drivers Map'}
              </span>
            </label>
          </div>
        </div>
      </div>

      {showNearbyDrivers && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <MapIcon size={12} className="text-emerald-500" />
              {language === 'hi' ? 'सक्रिय चालक' : 'Active Drivers Nearby'}
            </h3>
            <button 
              onClick={() => setShowNearbyDrivers(false)}
              className="text-[10px] font-bold text-slate-400 hover:text-slate-600"
            >
              {language === 'hi' ? 'छिपाएं' : 'Hide'}
            </button>
          </div>
          <NearbyDriversMap drivers={onlineDrivers} language={language} />
        </div>
      )}

      {showChargingStations && chargingStations.length > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-6 bg-emerald-50 border border-emerald-100 rounded-2xl"
        >
          <div className="flex items-center gap-2 mb-4">
            <div className="bg-emerald-600 p-1.5 rounded-lg text-white">
              <BarChart3 size={18} />
            </div>
            <h4 className="font-bold text-emerald-900">{t.chargingStationsTitle}</h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {chargingStations.map(station => (
              <div key={station.id} className="bg-white p-4 rounded-xl border border-emerald-100 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="font-bold text-emerald-900">{station.name}</div>
                  <div className="text-xs text-emerald-600 mt-1">{station.address}</div>
                </div>
                <div className="flex justify-between items-center mt-4">
                  <span className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider">{station.type}</span>
                  <span className="text-sm font-black text-emerald-600">{station.price}</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Service Selection Toggle */}
      <div className="mb-6 bg-white p-1.5 rounded-2xl flex gap-2 shadow-sm border border-slate-100">
        <button 
          onClick={() => handleServiceTypeChange('ride')}
          className={`flex-1 py-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${tripTypeFilter === 'ride' ? 'bg-primary text-white shadow-lg shadow-blue-200' : 'text-slate-500 hover:bg-slate-50'}`}
        >
          <span className="text-lg">🚗</span> 
          {language === 'hi' ? 'सवारी' : 'Join Ride'}
        </button>
        <button 
          onClick={() => handleServiceTypeChange('parcel')}
          className={`flex-1 py-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${tripTypeFilter === 'parcel' ? 'bg-primary text-white shadow-lg shadow-blue-200' : 'text-slate-500 hover:bg-slate-50'}`}
        >
          <span className="text-lg">📦</span> 
          {t.sendParcel}
        </button>
        <button 
          onClick={() => handleServiceTypeChange('all')}
          className={`px-6 py-3 rounded-xl text-xs font-black transition-all ${tripTypeFilter === 'all' ? 'bg-primary text-white shadow-lg shadow-blue-200' : 'text-slate-500 hover:bg-slate-50'}`}
        >
          {language === 'hi' ? 'सब' : 'All'}
        </button>
      </div>

      <div id="rideList" className="space-y-4">
        {loadingRides ? (
          <div className="py-20 flex flex-col items-center justify-center space-y-4">
            <LoadingSpinner />
            <p className="text-slate-500 font-medium animate-pulse">{language === 'hi' ? 'सवारियों की खोज की जा रही है...' : 'Finding available rides...'}</p>
          </div>
        ) : searchResults.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12 px-6 bg-slate-50 rounded-2xl border border-dashed border-slate-200"
          >
            <div className="bg-slate-200 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
              <Search size={32} />
            </div>
            <h3 className="text-lg font-bold text-slate-900">{t.noRidesFound}</h3>
            <p className="text-slate-500 max-w-sm mx-auto mt-2 text-sm leading-relaxed">
              {language === 'hi' ? 'क्षमा करें, हमें आपकी खोज से मेल खाने वाली कोई सवारी नहीं मिली।' : 'Sorry, we couldn\'t find any rides matching your search criteria.'}
            </p>

            {/* Multimodal Suggestion Box */}
            <div className="mt-6 p-4 max-w-md mx-auto bg-blue-50/80 rounded-xl border border-blue-100 flex flex-col items-center gap-3">
              <span className="text-xs font-black text-blue-700 bg-blue-100 px-2.5 py-1 rounded-full uppercase tracking-wider">
                💡 {language === 'hi' ? 'मल्टीमोडल मार्ग सुझाव' : 'Multimodal Route Suggestion'}
              </span>
              <p className="text-xs font-bold text-slate-700 max-w-xs text-center leading-normal">
                {language === 'hi' 
                  ? 'आस-पास कोई सवारी उपलब्ध नहीं है। ट्रांसपोर्ट हब से मेट्रो या बस मार्ग का प्रयास करें।' 
                  : 'No rides available nearby. Try Metro or Bus Route from Transport Hub.'}
              </p>
              {onNavigateToSection && (
                <button
                  onClick={() => onNavigateToSection("transportHubSection")}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-black uppercase tracking-wider rounded-lg transition-all shadow-sm shadow-blue-200 flex items-center gap-1.5"
                >
                  🌐 {language === 'hi' ? 'ट्रांसपोर्ट हब पर जाएं' : 'Go to Transport Hub'}
                </button>
              )}
            </div>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            <AnimatePresence mode="popLayout">
              {searchResults.map((r, index) => {
                const isExpanded = expandedRideId === r.id;
                const insight = isExpanded ? DecisionIntelligenceService.findBetterOption(r, searchResults, language) : null;
                const driverProfile = driverProfiles[r.driver];
                const fairInsight = FairMatchingService.getFairnessInsight(r, driverProfile || null, language);
                const prefInsight = PreferenceLearningService.getMatchInsight(r, userProfile?.learnedPreferences, language);
                const uncertaintyInsight = UncertaintyService.calculateUncertainty(r, driverProfile || null, language);
                
                return (
                  <motion.div 
                    key={r.id} 
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    className={`ride-card cursor-pointer group ${r.isEV ? 'ev-ride' : ''} ${r.womenOnly ? 'women-only' : ''} ${isExpanded ? 'ring-2 ring-primary shadow-xl' : ''}`}
                    onClick={() => setExpandedRideId(isExpanded ? null : r.id)}
                  >
                    {/* Ride Card Content - similar to before but with better styling */}
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex-grow">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
                            {r.from} 
                            <span className="text-slate-300">→</span> 
                            {r.to}
                          </h3>
                          <div className="flex flex-wrap gap-1.5 items-center">
                            {r.type === 'parcel' && (
                              <span className="bg-blue-100 text-blue-700 text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider border border-blue-200 flex items-center gap-1">
                                📦 {t.parcelDelivery}
                              </span>
                            )}
                            {r.vehiclePoolType === 'bike' && (
                              <span className="bg-amber-100 text-amber-800 text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider border border-amber-200 flex items-center gap-1">
                                🏍️ {language === 'hi' ? 'बाइक पूल' : 'Bike Pool'}
                              </span>
                            )}
                            {r.vehiclePoolType === 'ev' && (
                              <span className="bg-emerald-100 text-emerald-800 text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider border border-emerald-200 flex items-center gap-1">
                                ⚡ {language === 'hi' ? 'ईवी पूल' : 'EV Pool'}
                              </span>
                            )}
                            {r.vehiclePoolType === 'car' && (
                              <span className="bg-indigo-100 text-indigo-800 text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider border border-indigo-200 flex items-center gap-1">
                                🚗 {language === 'hi' ? 'कार पूल' : 'Car Pool'}
                              </span>
                            )}
                            {r.vehiclePoolType === 'bike' && r.helmetAvailable && (
                              <span className="bg-sky-100 text-sky-800 text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider border border-sky-200 flex items-center gap-1">
                                🪖 {language === 'hi' ? 'हेलमेट उपलब्ध ✅' : 'Helmet Available ✅'}
                              </span>
                            )}
                            {r.womenOnly && (
                              <span className="bg-pink-100 text-pink-700 text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider border border-pink-200 flex items-center gap-1">
                                👩 {language === 'hi' ? 'केवल महिलाएँ' : 'Female-Friendly'}
                              </span>
                            )}
                            {r.isEV && r.vehiclePoolType !== 'ev' && (
                              <span className="bg-emerald-100 text-emerald-700 text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider border border-emerald-200">EV Ride</span>
                            )}
                            <span className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[10px] px-2.5 py-0.5 rounded-full font-black uppercase tracking-wider flex items-center gap-1 shadow-sm">
                              🎯 {(r as any).compatibilityScore || 85}% {language === 'hi' ? 'संगतता' : 'Compatibility'}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-slate-500 font-medium">
                          <div className="flex items-center gap-1.5">
                            <Navigation size={14} className="text-slate-400" />
                            {r.date}
                          </div>
                          <div className="flex items-center gap-1.5">
                            <BarChart3 size={14} className="text-slate-400" />
                            {r.time}
                          </div>
                          {calculateETA(r) && (
                            <div className="flex items-center gap-1.5 text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md font-black text-[10px] animate-pulse border border-emerald-100">
                              <span className="w-1 h-1 bg-emerald-500 rounded-full"></span>
                              {language === 'hi' ? 'ड्राइवर ' : 'Driver '} {calculateETA(r)} {language === 'hi' ? 'में आ रहा है' : 'away'}
                            </div>
                          )}
                        </div>
                      </div>

                        <div className="flex items-center gap-6">
                         <div className="text-right">
                           <div className="text-2xl font-black text-primary">₹{r.price}</div>
                           <div className="text-[10px] font-black text-emerald-700 bg-emerald-50 border border-emerald-150 px-1.5 py-0.5 rounded-full mt-1 flex items-center justify-center gap-1 shadow-xs tracking-wide">
                              🤝 {language === 'hi' ? 'तोल-मोल' : 'Bargain with AI'}
                           </div>
                           <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                             {r.type === 'parcel' ? (
                               <span>{r.parcelDetails?.maxWeight}kg {language === 'hi' ? 'तक' : 'Limit'}</span>
                             ) : (
                               <span>{r.seats} {t.seatsLeft}</span>
                             )}
                           </div>
                          {r.type === 'ride' && r.luggageCapacity && r.luggageCapacity !== 'none' && (
                            <div className="text-[9px] font-black text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded mt-1 border border-emerald-100 flex items-center justify-end gap-1">
                              🧳 {t[r.luggageCapacity + 'Luggage' as keyof typeof t] || r.luggageCapacity}
                            </div>
                          )}
                         </div>
                         <div className="bg-slate-50 p-2 rounded-full text-slate-400 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                          {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 flex items-center justify-between pt-4 border-t border-slate-100">
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <div className="w-10 h-10 rounded-full bg-slate-100 border-2 border-white shadow-sm overflow-hidden">
                            {r.driverPhoto ? (
                              <img src={r.driverPhoto} alt={r.driverName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-slate-400 font-bold">
                                {(r.driverName || 'U').charAt(0).toUpperCase()}
                              </div>
                            )}
                          </div>
                          {r.driverVerified && (
                            <div className="absolute -bottom-1 -right-1 bg-emerald-500 text-white p-0.5 rounded-full border-2 border-white">
                              <ShieldCheck size={10} />
                            </div>
                          )}
                        </div>
                        <div>
                          <div className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                            {r.driverName || r.driver}
                            {(r.driverVerified || driverProfile?.isVerified) && (
                              <span className="inline-flex items-center gap-0.5 px-1.5 py-0.25 bg-emerald-50 text-emerald-600 text-[9px] font-black uppercase rounded border border-emerald-200">
                                ✓ Verified
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-0.5">
                            {getDriverRating(r.driver as string) > 0 ? (
                              <div className="flex items-center gap-1 text-amber-500 text-xs font-black">
                                <span>★</span>
                                <span>{getDriverRating(r.driver as string).toFixed(1)}</span>
                                <span className="text-slate-400 font-medium">({getDriverRatingInfo(r.driver as string)?.count})</span>
                              </div>
                            ) : (
                              <span className="text-[10px] text-slate-400 italic font-medium">New Driver</span>
                            )}
                            <UncertaintyIndicator insight={uncertaintyInsight} compact language={language} />
                            {fairInsight?.isBoosted && (
                              <div className="flex items-center gap-1 px-1.5 py-0.5 bg-blue-50 text-blue-600 rounded text-[9px] font-black uppercase tracking-tight border border-blue-100" title={fairInsight.explanation}>
                                <Scale size={8} />
                                {fairInsight.priorityReason}
                              </div>
                            )}
                            {prefInsight && (
                              <div className="flex items-center gap-1 px-1.5 py-0.5 bg-rose-50 text-rose-600 rounded text-[9px] font-black uppercase tracking-tight border border-rose-100">
                                <Heart size={8} />
                                {prefInsight.label}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button 
                          onClick={(e) => { e.stopPropagation(); onStartBooking(r); }} 
                          className="px-6 py-2 bg-primary hover:bg-primary-dark text-white rounded-lg font-bold text-sm transition-all"
                        >
                          {t.bookNow}
                        </button>
                        <span className="carbon-badge">🌱 {t.carbonSavedBadge}</span>
                      </div>
                    </div>

                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="overflow-hidden"
                        >
                          <div className="pt-6 mt-4 border-t border-slate-100 space-y-6">
                            {/* Why Not This Ride? Feature */}
                            {insight && (
                              <DecisionIntelligenceBadge 
                                insight={insight}
                                onApply={(betterRide) => {
                                  setExpandedRideId(betterRide.id);
                                  showNotification(language === 'hi' ? 'बेहतर विकल्प चुना गया' : 'Better option selected!');
                                }}
                                language={language}
                              />
                            )}

                            <UncertaintyIndicator insight={uncertaintyInsight} language={language} />

                            {/* Scenario-Based Suggestions */}
                            {isExpanded && (
                              <div className="space-y-4">
                                {ScenarioSuggestionService.getSuggestions(r, searchResults, language).map((suggestion, idx) => (
                                  <ScenarioSuggestionBadge 
                                    key={idx}
                                    suggestion={suggestion}
                                    language={language}
                                    onApply={() => {
                                      if (suggestion.targetRideId) {
                                        setExpandedRideId(suggestion.targetRideId);
                                      }
                                      showNotification(language === 'hi' ? 'सुझाव लागू किया गया' : 'Suggestion applied');
                                    }}
                                  />
                                ))}
                              </div>
                            )}

                            {/* Detailed Info Section */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                              <div className="space-y-6">
                                <div className="grid grid-cols-2 gap-6">
                                  <div className="space-y-3">
                                    <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t.amenities}</h4>
                                    <div className="flex flex-wrap gap-1.5">
                                      {r.amenities && r.amenities.length > 0 ? r.amenities.map(a => (
                                        <span key={a} className="bg-slate-100 text-slate-600 text-[10px] px-2.5 py-1 rounded-md font-bold border border-slate-200">
                                          {language === 'hi' ? (
                                            a === 'ac' ? 'एसी' :
                                            a === 'music' ? 'संगीत' :
                                            a === 'wifi' ? 'वाईफाई' :
                                            a === 'charging' ? 'चार्जिंग' :
                                            a === 'luggage' ? 'सामान' :
                                            a === 'pets' ? 'पालतू जानवर' : a
                                          ) : (AMENITIES.find(am => am.value === a)?.label || a)}
                                        </span>
                                      )) : <span className="text-xs text-slate-400 italic">No amenities listed</span>}
                                    </div>
                                  </div>

                                  <div className="space-y-3">
                                    <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{language === 'hi' ? 'वाहन' : 'Vehicle'}</h4>
                                    <div className="flex items-center gap-3">
                                      {r.carImage && (
                                        <img src={r.carImage} className="w-16 h-10 object-cover rounded-lg border border-slate-200" referrerPolicy="no-referrer" />
                                      )}
                                      <div>
                                        <div className="text-sm font-bold text-slate-900 flex items-center gap-1.5 flex-wrap">
                                          <span>{r.carName || (r.isEV ? 'Electric Vehicle' : 'Standard Vehicle')}</span>
                                          {r.carType && (
                                            <span className="px-1.5 py-0.25 rounded text-[8.5px] font-black uppercase tracking-wider bg-blue-50 border border-blue-100 text-blue-700">
                                              {r.carType}
                                            </span>
                                          )}
                                        </div>
                                        <div className="text-xs font-mono text-slate-500 mt-0.5 uppercase">{r.vehicleNumber || 'N/A'}</div>
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
                                  <div className="flex items-center gap-3">
                                    <div className="bg-primary/10 p-2 rounded-lg text-primary">
                                      <Info size={16} />
                                    </div>
                                    <p className="text-[11px] font-medium text-slate-600 leading-relaxed">
                                      {language === 'hi' 
                                        ? 'यह ड्राइवर सुरक्षित यात्रा के लिए सत्यापित है और समुदाय द्वारा रेट किया गया है।' 
                                        : 'This driver is verified for safe travel and rated by the community.'}
                                    </p>
                                  </div>
                                  <button 
                                    onClick={(e) => { e.stopPropagation(); setSelectedRideForMap(r); }} 
                                    className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg font-bold text-[10px] transition-all shadow-sm"
                                  >
                                    <MapIcon size={12} />
                                    {language === 'hi' ? 'पूरा मार्ग' : 'Full Route'}
                                  </button>
                                </div>
                              </div>

                              {/* Live Driver Location Map */}
                              <LiveDriverMap ride={r} language={language} />
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>

      {selectedRideForMap && (
        <RouteMap 
          ride={selectedRideForMap} 
          onClose={() => setSelectedRideForMap(null)} 
          language={language} 
        />
      )}
    </div>
  );
};
