import React from 'react';
import { Company } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import { db, collection, addDoc, query, where, getDocs, updateDoc, doc, arrayUnion, handleFirestoreError, OperationType } from '../firebase';

interface CorporateSectionProps {
  currentUser: string;
  showNotification: (msg: string, color?: string) => void;
  language: string;
}

export const CorporateSection: React.FC<CorporateSectionProps> = ({ currentUser, showNotification, language }) => {
  const [companies, setCompanies] = React.useState<Company[]>([]);
  const [newCompany, setNewCompany] = React.useState({ name: '', code: '' });
  const [joinCode, setJoinCode] = React.useState('');
  const [loading, setLoading] = React.useState(true);
  const [isCreating, setIsCreating] = React.useState(false);
  const [isJoining, setIsJoining] = React.useState(false);

  const fetchCorporateData = async () => {
    setLoading(true);
    try {
      const snapshot = await getDocs(collection(db, 'corporateAccounts'));
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      setCompanies(data);
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, 'corporateAccounts');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    if (currentUser) {
      fetchCorporateData();
    }
  }, [currentUser]);

  const createCompany = async () => {
    if (!newCompany.name || !newCompany.code) {
      showNotification("Please fill all fields!", "#e53935");
      return;
    }
    setIsCreating(true);
    try {
      const q = query(collection(db, 'corporateAccounts'), where('code', '==', newCompany.code));
      const snapshot = await getDocs(q);
      if (!snapshot.empty) {
        showNotification("Company code already exists!", "#e53935");
        setIsCreating(false);
        return;
      }
      await addDoc(collection(db, 'corporateAccounts'), {
        name: newCompany.name,
        code: newCompany.code,
        admin: currentUser,
        employees: [currentUser],
        createdAt: new Date().toISOString()
      });
      setNewCompany({ name: '', code: '' });
      showNotification("Corporate account created!");
      fetchCorporateData();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'corporateAccounts');
    } finally {
      setIsCreating(false);
    }
  };

  const joinCompany = async () => {
    if (!joinCode) return;
    setIsJoining(true);
    try {
      const q = query(collection(db, 'corporateAccounts'), where('code', '==', joinCode));
      const snapshot = await getDocs(q);
      if (snapshot.empty) {
        showNotification("Invalid company code!", "#e53935");
        setIsJoining(false);
        return;
      }
      const companyDoc = snapshot.docs[0];
      const companyData = companyDoc.data() as Company;
      if (companyData.employees.includes(currentUser)) {
        showNotification("Already a member!");
        setIsJoining(false);
        return;
      }
      await updateDoc(doc(db, 'corporateAccounts', companyDoc.id), {
        employees: arrayUnion(currentUser)
      });
      setJoinCode('');
      showNotification(`Joined ${companyData.name}!`);
      fetchCorporateData();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'corporateAccounts');
    } finally {
      setIsJoining(false);
    }
  };

  return (
    <div id="corporateSection">
      <h2 className="text-xl font-bold mb-4">🏢 {language === 'hi' ? 'कॉर्पोरेट कारपूल कार्यक्रम' : 'Corporate Carpool Program'}</h2>
      
      <div className="admin-info mb-6 p-4 bg-blue-50 rounded-lg">
        <p className="text-sm">{language === 'hi' ? 'कंपनियां कर्मचारी कारपूल आयोजित करने, कार्बन बचत को ट्रैक करने और समूह छूट प्राप्त करने के लिए कॉर्पोरेट खाते बना सकती हैं।' : 'Companies can create corporate accounts to organize employee carpools, track carbon savings, and get group discounts.'}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="form-section p-4 bg-gray-50 rounded-lg">
          <h3 className="font-bold mb-3">{language === 'hi' ? 'नई कंपनी बनाएं' : 'Create New Company'}</h3>
          <input 
            type="text" 
            placeholder={language === 'hi' ? 'कंपनी का नाम' : "Company Name"} 
            value={newCompany.name} 
            onChange={(e) => setNewCompany({...newCompany, name: e.target.value})} 
            className="mb-2"
          />
          <input 
            type="text" 
            placeholder={language === 'hi' ? 'कंपनी कोड' : "Company Code"} 
            value={newCompany.code} 
            onChange={(e) => setNewCompany({...newCompany, code: e.target.value})} 
            className="mb-3"
          />
          <button 
            onClick={createCompany} 
            disabled={isCreating}
            className="w-full flex items-center justify-center gap-2"
          >
            {isCreating && <LoadingSpinner size="sm" color="white" />}
            {isCreating ? (language === 'hi' ? 'बनाया जा रहा है...' : 'Creating...') : (language === 'hi' ? 'खाता बनाएं' : 'Create Account')}
          </button>
        </div>

        <div className="form-section p-4 bg-gray-50 rounded-lg">
          <h3 className="font-bold mb-3">{language === 'hi' ? 'मौजूदा कंपनी में शामिल हों' : 'Join Existing Company'}</h3>
          <p className="text-xs text-gray-600 mb-3">{language === 'hi' ? 'शामिल होने के लिए अपना कंपनी कोड दर्ज करें:' : 'Enter your company code to join:'}</p>
          <input 
            type="text" 
            placeholder={language === 'hi' ? 'कंपनी कोड' : "Company Code"} 
            value={joinCode} 
            onChange={(e) => setJoinCode(e.target.value)} 
            className="mb-3"
          />
          <button 
            onClick={joinCompany} 
            disabled={isJoining}
            className="w-full flex items-center justify-center gap-2"
          >
            {isJoining && <LoadingSpinner size="sm" color="white" />}
            {isJoining ? (language === 'hi' ? 'शामिल हो रहे हैं...' : 'Joining...') : (language === 'hi' ? 'कंपनी में शामिल हों' : 'Join Company')}
          </button>
        </div>
      </div>

      <div>
        <h3 className="font-bold mb-4">{language === 'hi' ? 'मेरी कंपनियां' : 'My Companies'}</h3>
        {loading ? (
          <div className="py-10">
            <LoadingSpinner label={language === 'hi' ? 'कंपनियां लोड हो रही हैं...' : 'Loading companies...'} />
          </div>
        ) : companies.filter(c => c.employees.includes(currentUser)).length === 0 ? (
          <p className="text-gray-500 italic text-center py-4">{language === 'hi' ? 'आप अभी तक किसी भी कंपनी में शामिल नहीं हुए हैं।' : "You haven't joined any companies yet."}</p>
        ) : (
          companies.filter(c => c.employees.includes(currentUser)).map(c => (
            <div key={c.id} className="ride-card corporate-ride">
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="font-bold text-lg">{c.name}</h4>
                  <p className="text-xs text-gray-600">{language === 'hi' ? 'कोड:' : 'Code:'} <strong>{c.code}</strong></p>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-purple-700">{c.employees.length} {language === 'hi' ? 'कर्मचारी' : 'Employees'}</div>
                  {c.admin === currentUser && <span className="text-[10px] bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full font-bold">{language === 'hi' ? 'एडमिन' : 'Admin'}</span>}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
