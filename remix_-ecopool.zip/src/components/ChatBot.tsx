import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, Bot, User, Loader2, Sparkles } from 'lucide-react';
import { TRANSLATIONS } from '../constants';

interface ChatBotProps {
  language: string;
}

interface Message {
  role: 'user' | 'model';
  content: string;
}

export const ChatBot: React.FC<ChatBotProps> = ({ language }) => {
  const [open, setOpen] = React.useState(false);
  const [input, setInput] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [messages, setMessages] = React.useState<Message[]>([]);
  const scrollRef = React.useRef<HTMLDivElement>(null);
  
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const systemInstruction = `You are the EcoPool Assistant, a helpful AI guide for the EcoPool carpooling platform.
EcoPool features:
- Community-based carpooling to save the planet.
- Women-Only Rides: Exclusive safety for female passengers.
- EV Tracking & Green Mobility: Dedicated EV category with integration to see charging stations.
- Carbon Analytics: Track CO2 savings and tree equivalents in EV Analytics.
- Dynamic Pricing: AI-optimized ride prices.
- Smart Match Score: Real-time matching based on route and preferences.
- Live Tracking: Real-time driver location and journey status.
- Wallet & Rewards: Cashbacks, referrals (₹50 bonus), and internal UPI-like payments.
- Parcel Delivery: Send packages with trusted riders.
- SOS Button: Emergency alerts for safety.
- Subscription Plans: Free and premium layers.

Guidelines:
1. Be polite, enthusiastic, and concise.
2. Support both English and Hindi based on the user's input/preference (the app language is currently ${language === 'hi' ? 'Hindi' : 'English'}).
3. If users ask about features, explain how they benefit them (saving money, environment, or safety).
4. Do not mention that you are an AI or a language model unless asked.
5. Use emojis to keep the conversation friendly.`;

  React.useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        { 
          role: "model", 
          content: language === 'hi' 
            ? "नमस्ते! मैं आपका इकोपूल सहायक हूँ 🚗 मैं सवारी बुक करने, ईवी सवारी, केवल महिलाओं के लिए सवारी और बहुत कुछ में आपकी मदद कर सकता हूँ! मैं आज आपकी कैसे सहायता कर सकता हूँ?" 
            : "Hello! I'm your EcoPool Assistant 🚗 I can help you with booking rides, EV rides, women-only rides, and much more! How can I assist you today?" 
        }
      ]);
    }
  }, [language]);

  React.useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;

    const userMsg: Message = { role: "user", content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const response = await fetch("/api/chatbot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          language,
          messages: messages.concat(userMsg)
        })
      });
      const data = await response.json();
      if (data.error) throw new Error(data.error);

      const reply = data.reply || (language === 'hi' ? "क्षमा करें, मैं इसे समझ नहीं पाया।" : "Sorry, I couldn't process that.");
      setMessages(prev => [...prev, { role: "model", content: reply }]);
    } catch (error) {
      console.error("ChatBot Error:", error);
      setMessages(prev => [...prev, { 
        role: "model", 
        content: language === 'hi' 
          ? "माफ़ कीजिये, अभी मेरा संपर्क टूट गया है। कृपया बाद में प्रयास करें।" 
          : "Oops, I'm having trouble connecting right now. Please try again later." 
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[2000]">
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="absolute bottom-20 right-0 w-[350px] max-w-[90vw] h-[500px] bg-white rounded-3xl shadow-2xl border border-slate-100 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-primary to-blue-600 p-4 pt-6 pb-4 text-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-white/20 p-2 rounded-xl backdrop-blur-sm">
                    <Bot size={20} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black uppercase tracking-widest leading-none">
                      {language === 'hi' ? 'इकोपूल सहायक' : 'EcoPool Assistant'}
                    </h3>
                    <div className="flex items-center gap-1.5 mt-1">
                      <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></div>
                      <span className="text-[10px] font-bold text-white/80 uppercase tracking-tighter">Online Now</span>
                    </div>
                  </div>
                </div>
                <button 
                  onClick={() => setOpen(false)}
                  className="p-1.5 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Chat Body */}
            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth"
            >
              {messages.map((m, i) => (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  key={i}
                  className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex gap-2 max-w-[85%] ${m.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 mt-1 ${
                      m.role === 'user' ? 'bg-slate-100 text-slate-500' : 'bg-primary/10 text-primary'
                    }`}>
                      {m.role === 'user' ? <User size={12} /> : <Bot size={12} />}
                    </div>
                    <div className={`p-3 rounded-2xl text-xs font-medium leading-relaxed ${
                      m.role === 'user' 
                        ? 'bg-primary text-white rounded-tr-none shadow-md shadow-primary/20' 
                        : 'bg-slate-50 text-slate-700 rounded-tl-none border border-slate-100'
                    }`}>
                      {m.content}
                    </div>
                  </div>
                </motion.div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-slate-50 border border-slate-100 p-3 rounded-2xl rounded-tl-none flex items-center gap-2">
                    <Loader2 size={12} className="animate-spin text-primary" />
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                      {language === 'hi' ? 'सोच रहा हूँ...' : 'Thinking...'}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="p-4 border-t border-slate-50 bg-white">
              <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-2xl border border-slate-200 focus-within:border-primary/50 focus-within:ring-4 focus-within:ring-primary/5 transition-all">
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                  placeholder={language === 'hi' ? 'कुछ भी पूछें...' : 'Ask me anything...'}
                  className="flex-1 bg-transparent border-none focus:outline-none text-xs font-medium px-3 text-slate-700"
                />
                <button 
                  onClick={sendMessage}
                  disabled={loading || !input.trim()}
                  className={`p-2 rounded-xl transition-all ${
                    input.trim() && !loading 
                      ? 'bg-primary text-white shadow-lg shadow-primary/20 hover:scale-105 active:scale-95' 
                      : 'bg-slate-200 text-slate-400'
                  }`}
                >
                  <Send size={16} />
                </button>
              </div>
              <div className="mt-3 flex items-center justify-center gap-1">
                <Sparkles size={8} className="text-primary" />
                <span className="text-[8px] font-black text-slate-300 uppercase tracking-widest">Powered by Gemini AI</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen(!open)}
        className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-xl transition-all ${
          open 
            ? 'bg-white text-slate-400 border border-slate-100 rotate-90' 
            : 'bg-primary text-white animate-bounce-subtle'
        }`}
      >
        {open ? <X size={24} /> : <MessageSquare size={24} />}
      </motion.button>
    </div>
  );
};
