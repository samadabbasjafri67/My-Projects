import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Download, Share2, MapPin, Calendar, Clock, CreditCard, TreeDeciduous, ShieldCheck, Printer } from 'lucide-react';
import { TRANSLATIONS } from '../constants';

interface RideReceiptModalProps {
  booking: any;
  language: string;
  onClose: () => void;
}

export const RideReceiptModal: React.FC<RideReceiptModalProps> = ({ booking, language, onClose }) => {
  const isHindi = language === 'hi';
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  // Simulated distance calculation if not present
  const distance = booking.distance || 12.5; 
  const co2Saved = (distance * 0.12 * booking.seats).toFixed(2);

  const handleDownload = () => {
    window.print();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[6000] flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col relative border border-white/20 print:shadow-none print:border-none"
        >
          {/* Header */}
          <header className="bg-slate-900 text-white p-6 pt-8 text-center relative print:hidden">
            <button 
              onClick={onClose}
              className="absolute right-6 top-6 p-2 hover:bg-white/10 rounded-xl transition-all"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="bg-emerald-500/20 w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-emerald-500/30">
              <ShieldCheck className="text-emerald-400" />
            </div>
            <h3 className="text-sm font-black uppercase tracking-[0.2em]">{isHindi ? 'सवारी रसीद' : 'Ride Receipt'}</h3>
            <p className="text-[10px] text-slate-400 font-bold mt-1 opacity-80">
              ID: {booking.bookingId?.substring(0, 8).toUpperCase() || 'TXN-9921'}
            </p>
          </header>

          {/* Receipt Content */}
          <div className="p-8 space-y-8 max-h-[70vh] overflow-y-auto print:max-h-none print:overflow-visible custom-scrollbar">
            {/* Main Info */}
            <div className="flex justify-between items-start gap-4">
              <div className="space-y-4 flex-1">
                <div className="flex gap-3">
                  <div className="flex flex-col items-center pt-1 shrink-0">
                    <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                    <div className="w-0.5 h-6 bg-slate-100 my-1"></div>
                    <div className="w-2 h-2 rounded-full bg-red-500"></div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{isHindi ? 'पिकअप' : 'Pickup'}</div>
                      <div className="text-xs font-bold text-slate-800 leading-tight">{booking.from}</div>
                    </div>
                    <div>
                      <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{isHindi ? 'ड्रॉप' : 'Drop'}</div>
                      <div className="text-xs font-bold text-slate-800 leading-tight">{booking.to}</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{isHindi ? 'दिनांक' : 'Date'}</div>
                <div className="text-xs font-bold text-slate-800">{booking.date}</div>
                <div className="text-[10px] font-medium text-slate-400">{booking.time}</div>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-2 gap-4 py-6 border-y border-slate-50">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-slate-400">
                  <Clock className="w-3 h-3" />
                  <span className="text-[9px] font-black uppercase tracking-widest">{isHindi ? 'दूरी' : 'Distance'}</span>
                </div>
                <div className="text-sm font-black text-slate-900">{distance} km</div>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-emerald-600">
                  <TreeDeciduous className="w-3 h-3" />
                  <span className="text-[9px] font-black uppercase tracking-widest">{isHindi ? 'CO₂ की बचत' : 'CO₂ Saved'}</span>
                </div>
                <div className="text-sm font-black text-emerald-600">{co2Saved} kg</div>
              </div>
            </div>

            {/* Fare Breakdown */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{isHindi ? 'किराया विवरण' : 'Fare Breakdown'}</h4>
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-500 font-medium">{isHindi ? 'आधार शुल्क' : 'Base Fare'} ({booking.seats} {isHindi ? 'सीटें' : 'seats'})</span>
                  <span className="text-slate-900 font-bold">₹{booking.price}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-500 font-medium">{isHindi ? 'प्लेटफॉर्म शुल्क' : 'Platform Fee'}</span>
                  <span className="text-slate-900 font-bold">₹5.00</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-emerald-600 font-medium">{isHindi ? 'इको डिस्काउंट' : 'Eco Discount'}</span>
                  <span className="text-emerald-600 font-bold">-₹2.00</span>
                </div>
                <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
                  <span className="text-sm font-black text-slate-900 uppercase tracking-widest">{isHindi ? 'कुल' : 'Total'}</span>
                  <span className="text-xl font-black text-blue-600">₹{booking.price + 3}</span>
                </div>
              </div>
            </div>

            {/* Payment Method */}
            <div className="bg-slate-50 p-4 rounded-2xl flex items-center justify-between border border-slate-100/50">
              <div className="flex items-center gap-3">
                <div className="bg-white p-2 rounded-xl shadow-sm">
                  <CreditCard className="w-4 h-4 text-slate-400" />
                </div>
                <div>
                  <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{isHindi ? 'भुगतान विधि' : 'Payment Method'}</div>
                  <div className="text-xs font-bold text-slate-800">Eco Wallet •••• 9921</div>
                </div>
              </div>
              <div className="bg-emerald-50 text-emerald-600 text-[10px] font-black px-2 py-1 rounded-lg uppercase tracking-widest">
                {isHindi ? 'सफल' : 'Paid'}
              </div>
            </div>

            {/* Footer Note */}
            <div className="text-center space-y-2">
              <p className="text-[10px] text-slate-400 font-medium leading-relaxed">
                {isHindi 
                  ? 'EcoPool के साथ यात्रा करने के लिए धन्यवाद। हर सवारी के साथ आप पृथ्वी को हरा-भरा बना रहे हैं।' 
                  : 'Thank you for riding with EcoPool. With every ride, you make the planet greener.'}
              </p>
              <div className="flex justify-center gap-1">
                {[1,2,3,4,5,6,7,8,1,2,3,4,5,6,7,8].map((_, i) => (
                  <div key={i} className="w-2 h-0.5 bg-slate-100 rounded-full"></div>
                ))}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <footer className="p-6 pt-2 flex gap-3 print:hidden">
            <button 
              onClick={handleDownload}
              className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-3 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-slate-100"
            >
              <Printer size={14} />
              {isHindi ? 'प्रिंट रसीद' : 'Print Receipt'}
            </button>
            <button className="p-3 bg-slate-100 text-slate-600 rounded-2xl hover:bg-slate-200 transition-all active:scale-95">
              <Share2 size={18} />
            </button>
          </footer>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
