import React from 'react';
import { TRANSLATIONS } from '../constants';
import { LoadingSpinner } from './LoadingSpinner';
import { HelpCircle, Trash2, CheckCircle, Phone, FileText, AlertTriangle, ChevronRight, RefreshCw, PlusCircle, Check } from 'lucide-react';
import { db, collection, addDoc, getDocs, query, where, updateDoc, doc, deleteDoc, handleFirestoreError, OperationType } from '../firebase';
import { Booking, LostReport } from '../types';

interface LostFoundSectionProps {
  currentUser: string | null;
  showNotification: (msg: string, color?: string) => void;
  language: string;
}

export const LostFoundSection: React.FC<LostFoundSectionProps> = ({ currentUser, showNotification, language }) => {
  const [item, setItem] = React.useState('');
  const [rideId, setRideId] = React.useState('');
  const [driverContact, setDriverContact] = React.useState('');
  const [comments, setComments] = React.useState('');
  
  const [reports, setReports] = React.useState<LostReport[]>([]);
  const [userBookings, setUserBookings] = React.useState<Booking[]>([]);
  
  const [isLoadingReports, setIsLoadingReports] = React.useState(false);
  const [isLoadingBookings, setIsLoadingBookings] = React.useState(false);
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  // Fetch student's / passenger's previous bookings to help auto-fill
  const fetchRecentBookings = React.useCallback(async () => {
    if (!currentUser) return;
    setIsLoadingBookings(true);
    try {
      const q = query(
        collection(db, 'bookings'),
        where('passenger', '==', currentUser)
      );
      const snap = await getDocs(q);
      const bookingsList: Booking[] = [];
      snap.forEach((docSnap) => {
        bookingsList.push({ id: docSnap.id, ...docSnap.data() } as Booking);
      });
      // Sort bookings by date / bookedAt descending
      bookingsList.sort((a, b) => new Date(b.bookedAt || 0).getTime() - new Date(a.bookedAt || 0).getTime());
      setUserBookings(bookingsList);
    } catch (err) {
      console.error("Error loading user bookings for lost found:", err);
    } finally {
      setIsLoadingBookings(false);
    }
  }, [currentUser]);

  // Fetch existing lost item reports for this user
  const fetchReports = React.useCallback(async () => {
    if (!currentUser) return;
    setIsLoadingReports(true);
    try {
      const q = query(
        collection(db, 'lostReports'),
        where('userId', '==', currentUser)
      );
      const snap = await getDocs(q);
      const reportsList: LostReport[] = [];
      snap.forEach((docSnap) => {
        reportsList.push({ id: docSnap.id, ...docSnap.data() } as LostReport);
      });
      reportsList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setReports(reportsList);
    } catch (err) {
      console.error("Error loading lost items reports:", err);
    } finally {
      setIsLoadingReports(false);
    }
  }, [currentUser]);

  React.useEffect(() => {
    if (currentUser) {
      fetchRecentBookings();
      fetchReports();
    }
  }, [currentUser, fetchRecentBookings, fetchReports]);

  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (!item.trim()) {
      showNotification(language === 'hi' ? 'कृपया वस्तु का नाम दर्ज करें' : 'Please specify the item forgotten', '#e53935');
      return;
    }
    if (!rideId.trim()) {
      showNotification(language === 'hi' ? 'कृपया राइड आईडी दर्ज करें' : 'Please specify the ride ID', '#e53935');
      return;
    }
    if (!driverContact.trim()) {
      showNotification(language === 'hi' ? 'कृपया ड्राइवर का संपर्क विवरण प्रदान करें' : 'Please provide driver contact details', '#e53935');
      return;
    }

    setIsSubmitting(true);
    try {
      // Look for driver details if selected from automatic list
      const matchedBooking = userBookings.find(b => b.id === rideId || b.ride?.id?.toString() === rideId);
      const driverName = matchedBooking?.ride?.driver || undefined;

      const newReport: Omit<LostReport, 'id'> = {
        userId: currentUser,
        item: item.trim(),
        rideId: rideId.trim(),
        driverContact: driverContact.trim(),
        status: 'Reported',
        createdAt: new Date().toISOString(),
        driverName: driverName,
        comments: comments.trim() || undefined
      };

      await addDoc(collection(db, 'lostReports'), newReport);
      
      showNotification(
        language === 'hi' 
          ? 'खोई हुई वस्तु की रिपोर्ट सफलतापूर्वक सहेज ली गई!' 
          : 'Lost item report submitted successfully!'
      );
      
      // Reset inputs
      setItem('');
      setRideId('');
      setDriverContact('');
      setComments('');

      // Refresh list
      fetchReports();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'lostReports');
      showNotification(language === 'hi' ? 'रिपोर्ट दर्ज करने में खराबी' : 'Failed to submit lost item report', '#e53935');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateStatus = async (reportId: string, newStatus: LostReport['status']) => {
    try {
      await updateDoc(doc(db, 'lostReports', reportId), { status: newStatus });
      showNotification(
        language === 'hi' 
          ? `स्थिति को '${newStatus}' में बदला गया!` 
          : `Status updated to '${newStatus}'!`
      );
      fetchReports();
    } catch (err) {
      console.error("Error updating report status:", err);
      showNotification(language === 'hi' ? 'रिपोर्ट स्थिति बदलने में विफलता' : 'Failed to update report status', '#e53935');
    }
  };

  const handleDeleteReport = async (reportId: string) => {
    if (!window.confirm(language === 'hi' ? 'क्या आप इस रिपोर्ट को हटाना चाहते हैं?' : 'Are you sure you want to delete this report?')) return;
    try {
      await deleteDoc(doc(db, 'lostReports', reportId));
      showNotification(language === 'hi' ? 'रिपोर्ट हटा दी गई!' : 'Report deleted successfully!');
      fetchReports();
    } catch (err) {
      console.error("Error deleting report:", err);
      showNotification(language === 'hi' ? 'रिपोर्ट हटाने में त्रुटि' : 'Failed to delete report', '#e53935');
    }
  };

  const selectBookingToAutoFill = (b: Booking) => {
    setRideId(b.id || b.ride?.id?.toString() || '');
    setDriverContact(b.ride?.driverPhone || b.ride?.driverEmail || t.verified || 'Driver');
    if (b.ride?.driver) {
      setComments(language === 'hi' ? `ड्राइवर: ${b.ride.driver} के साथ सवारी` : `Travelled with driver: ${b.ride.driver}`);
    }
    showNotification(language === 'hi' ? 'राइड विवरण स्वतः भर दिए गए!' : 'Ride details auto-filled!');
  };

  const getStatusBadgeColor = (status: LostReport['status']) => {
    switch (status) {
      case 'Reported':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Contacting Driver':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Item Found':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Returned':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'Resolved':
        return 'bg-gray-100 text-gray-700 border-gray-300';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div id="lostFoundSection" className="max-w-6xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
          🔍 {language === 'hi' ? 'खोया और पाया सिस्टम' : 'Lost & Found System'}
        </h1>
        <p className="text-slate-600 mt-2 max-w-2xl">
          {language === 'hi'
            ? 'क्या आप सवारी में अपना फोन, वॉलेट या अन्य कीमती सामान भूल गए हैं? एक रिपोर्ट दर्ज करें और सीधे संबंधित ड्राइवर तक पहुँचें।'
            : 'Forgot your phone, wallet, or other valuables? File a simple report and reach the driver or support team to get it back.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Form Column */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
            <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
              <PlusCircle className="text-primary" size={20} />
              {language === 'hi' ? 'नई रिपोर्ट दर्ज करें' : 'File a New Report'}
            </h2>

            <form onSubmit={handleSubmitReport} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">
                  📦 {language === 'hi' ? 'खोई हुई वस्तु (जैसे: फोन, ब्लैक वॉलेट)' : 'Item Forgotten (e.g. iPhone, Black Wallet)'} <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={item}
                  onChange={(e) => setItem(e.target.value)}
                  placeholder={language === 'hi' ? 'सटीक विवरण लिखें...' : 'Describe the item...'}
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-sm font-medium"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">
                  🆔 {language === 'hi' ? 'राइड आईडी (Ride ID)' : 'Ride ID'} <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={rideId}
                  onChange={(e) => setRideId(e.target.value)}
                  placeholder={language === 'hi' ? 'जैसे: ride_seed_1' : 'e.g. ride_seed_1'}
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-sm font-mono font-medium"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">
                  📞 {language === 'hi' ? 'ड्राइवर का फ़ोन / संपर्क' : 'Driver Contact Info'} <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={driverContact}
                  onChange={(e) => setDriverContact(e.target.value)}
                  placeholder={language === 'hi' ? 'जैसे: +91-XXXXX-XXXXX या ईमेल' : 'e.g. +91-XXXXX-XXXXX or email'}
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-sm font-medium"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">
                  💬 {language === 'hi' ? 'अतिरिक्त टिप्पणी (वैकल्पिक)' : 'Additional Comments (Optional)'}
                </label>
                <textarea
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  placeholder={language === 'hi' ? 'लिखें कि सामान कहाँ छूटा हो सकता है...' : 'Any details on where you might have left it...'}
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-sm font-medium h-20 resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full py-3 rounded-xl font-bold text-white transition-all flex items-center justify-center gap-2 shadow-sm ${
                  isSubmitting
                    ? 'bg-slate-400 cursor-not-allowed'
                    : 'bg-primary hover:bg-primary-dark hover:shadow-md'
                }`}
              >
                {isSubmitting && <LoadingSpinner size="sm" color="white" />}
                {isSubmitting
                  ? (language === 'hi' ? 'सहेजा जा रहा है...' : 'Filing Report...')
                  : (language === 'hi' ? 'खोई वस्तु की रिपोर्ट करें' : 'Report Forgot Item')}
              </button>
            </form>
          </div>

          {/* Quick Select Panel */}
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider">
                🚕 {language === 'hi' ? 'अपनी हालिया बुक की गई राइड्स' : 'Select from Your Recent Rides'}
              </h3>
              <button
                onClick={fetchRecentBookings}
                className="text-primary hover:text-primary-dark transition-colors"
                title={language === 'hi' ? 'ताज़ा करें' : 'Refresh list'}
                disabled={isLoadingBookings}
              >
                <RefreshCw size={14} className={isLoadingBookings ? "animate-spin" : ""} />
              </button>
            </div>

            {isLoadingBookings ? (
              <div className="py-8 flex justify-center text-slate-400">
                <LoadingSpinner size="md" />
              </div>
            ) : userBookings.length === 0 ? (
              <p className="text-xs text-slate-400 italic py-4">
                {language === 'hi' ? 'हालिया बुकिंग रिकॉर्ड नहीं मिले।' : 'No recent ride bookings found.'}
              </p>
            ) : (
              <div className="max-h-48 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                {userBookings.slice(0, 5).map((b) => (
                  <div
                    key={b.id}
                    onClick={() => selectBookingToAutoFill(b)}
                    className="p-2.5 text-left rounded-xl border border-slate-100 bg-slate-50 hover:bg-primary/5 hover:border-primary/20 cursor-pointer transition-all flex items-start gap-2 group"
                  >
                    <div className="bg-white p-1 rounded border border-slate-200 mt-0.5 shrink-0">
                      <FileText size={14} className="text-slate-500 group-hover:text-primary transition-colors" />
                    </div>
                    <div className="text-xs min-w-0 flex-1">
                      <div className="font-semibold text-slate-800 line-clamp-1">
                        {b.ride?.from} → {b.ride?.to}
                      </div>
                      <div className="text-[10px] text-slate-500 flex items-center justify-between mt-1">
                        <span>📅 {b.ride?.date}</span>
                        <span className="font-mono text-[9px] bg-white px-1 py-0.5 rounded border">ID: {b.id || b.ride?.id}</span>
                      </div>
                    </div>
                    <ChevronRight size={14} className="text-slate-400 group-hover:translate-x-0.5 transition-transform self-center shrink-0" />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Existing Reports List */}
        <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex flex-col min-h-[460px]">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
              📋 {language === 'hi' ? 'आपकी दर्ज़ रिपोर्ट' : 'Your Lost Item Reports'}
            </h2>
            <button
              onClick={fetchReports}
              className="text-primary hover:text-primary-dark transition-colors"
              title={language === 'hi' ? 'ताज़ा करें' : 'Refresh reports'}
              disabled={isLoadingReports}
            >
              <RefreshCw size={16} className={isLoadingReports ? "animate-spin" : ""} />
            </button>
          </div>

          {isLoadingReports ? (
            <div className="flex-1 flex items-center justify-center py-16 text-slate-400">
              <LoadingSpinner size="lg" />
            </div>
          ) : reports.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center py-16 text-slate-400">
              <HelpCircle size={48} className="text-slate-300 stroke-[1.5] mb-2" />
              <p className="font-semibold text-slate-600">
                {language === 'hi' ? 'कोई रिपोर्ट नहीं मिली' : 'No lost items reported yet'}
              </p>
              <p className="text-xs text-slate-400 max-w-xs mt-1">
                {language === 'hi'
                  ? 'आपकी खोई हुई वस्तुओं की सूचियाँ यहाँ दिखाई देंगी। बाईं ओर से एक नई रिपोर्ट दर्ज करें।'
                  : 'Items you report forgotten will appear here. File a new report from the left panel.'}
              </p>
            </div>
          ) : (
            <div className="space-y-4 flex-1 overflow-y-auto max-h-[600px] pr-2 custom-scrollbar">
              {reports.map((report) => (
                <div
                  key={report.id}
                  className="p-4 rounded-xl border border-slate-150 shadow-sm transition-all bg-white relative flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-2 min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-slate-800 text-sm">
                        📦 {report.item}
                      </span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold ${getStatusBadgeColor(report.status)}`}>
                        {report.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1 text-xs text-slate-500 font-medium">
                      <div className="flex items-center gap-1">
                        <span className="font-semibold text-slate-700">Ride ID:</span>
                        <span className="font-mono text-[11px] bg-slate-50 px-1.5 py-0.5 rounded border text-slate-600">
                          {report.rideId}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Phone size={12} className="text-slate-400" />
                        <span className="font-semibold text-slate-700">Driver Contact:</span>
                        <a href={`tel:${report.driverContact}`} className="text-primary hover:underline">
                          {report.driverContact}
                        </a>
                      </div>
                    </div>

                    {report.comments && (
                      <p className="text-xs text-slate-500 bg-slate-50 p-2 rounded-lg border border-slate-100 max-w-xl italic mt-1 line-clamp-2">
                        💡 {report.comments}
                      </p>
                    )}

                    <div className="text-[10px] text-slate-400">
                      📅 {language === 'hi' ? 'दर्ज करने की तारीख: ' : 'Reported on: '} 
                      {new Date(report.createdAt).toLocaleDateString(language === 'hi' ? 'hi-IN' : 'en-US')} 
                      {' '} {new Date(report.createdAt).toLocaleTimeString(language === 'hi' ? 'hi-IN' : 'en-US', { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>

                  {/* Quick Inline Actions */}
                  <div className="flex items-center gap-1.5 justify-end shrink-0 border-t pt-3 md:border-none md:pt-0">
                    {/* Stat Toggles */}
                    {report.status === 'Reported' && (
                      <button
                        onClick={() => handleUpdateStatus(report.id!, 'Contacting Driver')}
                        className="text-[10px] sm:text-xs bg-blue-50 border border-blue-200 text-blue-700 font-semibold px-2 py-1 rounded-lg hover:bg-blue-100 transition-colors"
                      >
                        {language === 'hi' ? 'ड्राइवर से संपर्क करें' : 'Contact Driver'}
                      </button>
                    )}

                    {(report.status === 'Reported' || report.status === 'Contacting Driver') && (
                      <button
                        onClick={() => handleUpdateStatus(report.id!, 'Item Found')}
                        className="text-[10px] sm:text-xs bg-emerald-50 border border-emerald-200 text-emerald-700 font-semibold px-2 py-1 rounded-lg hover:bg-emerald-100 transition-colors flex items-center gap-0.5"
                      >
                        <Check size={11} />
                        {language === 'hi' ? 'सामान मिल गया' : 'Found'}
                      </button>
                    )}

                    {report.status === 'Item Found' && (
                      <button
                        onClick={() => handleUpdateStatus(report.id!, 'Returned')}
                        className="text-[10px] sm:text-xs bg-purple-50 border border-purple-200 text-purple-700 font-semibold px-2 py-1 rounded-lg hover:bg-purple-100 transition-colors"
                      >
                        {language === 'hi' ? 'वापस मिला' : 'Mark Returned'}
                      </button>
                    )}

                    {report.status !== 'Resolved' && report.status !== 'Returned' ? (
                      <button
                        onClick={() => handleUpdateStatus(report.id!, 'Resolved')}
                        className="text-[10px] sm:text-xs bg-gray-50 border border-gray-200 text-gray-700 font-semibold px-2 py-1 rounded-lg hover:bg-gray-100 transition-colors"
                      >
                        {language === 'hi' ? 'सुलझ गया' : 'Resolve'}
                      </button>
                    ) : (
                      <span className="text-[11px] font-semibold text-emerald-600 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-0.5">
                        <CheckCircle size={10} />
                        {language === 'hi' ? 'समाप्त' : 'Resolved'}
                      </span>
                    )}

                    <button
                      onClick={() => handleDeleteReport(report.id!)}
                      className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg border border-transparent hover:border-rose-100 transition-all ml-1"
                      title={language === 'hi' ? 'हटाएं' : 'Delete report'}
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Quick Informational Notice */}
          <div className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-100 flex items-start gap-2.5">
            <AlertTriangle className="text-blue-600 shrink-0 mt-0.5" size={16} />
            <div className="text-xs text-blue-700">
              <span className="font-bold">
                💡 {language === 'hi' ? 'याद रखें:' : 'Important Notice:'}
              </span>{' '}
              {language === 'hi'
                ? 'यदि ड्राइवर ने आपको वापस फ़ोन नहीं किया है या वस्तु विशेष रूप से कीमती है, तो कृपया सुरक्षा हेल्पलाइन से संपर्क करें या फ़ीडबैक सेक्शन के माध्यम से हमारी एडमिन टीम से संपर्क करें।'
                : 'If your driver is unresponsive or if your item is extremely valuable, please contact our support team immediately or reach out via the Feedback section.'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
