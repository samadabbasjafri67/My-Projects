import React from 'react';
import { Ride } from '../types';
import { TRANSLATIONS } from '../constants';

interface PaymentModalProps {
  ride: Ride;
  onConfirm: (paymentDetails: any) => void;
  onCancel: () => void;
  language: string;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ ride, onConfirm, onCancel, language }) => {
  const [upiId, setUpiId] = React.useState('');
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [step, setStep] = React.useState<'select' | 'paytm'>('select');

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const handlePayment = () => {
    if (step === 'paytm' && !upiId.includes('@')) {
      alert(language === 'hi' ? 'कृपया एक वैध UPI आईडी दर्ज करें' : 'Please enter a valid UPI ID');
      return;
    }

    setIsProcessing(true);
    // Simulate payment processing
    setTimeout(() => {
      onConfirm({
        method: 'Paytm UPI',
        upiId: upiId,
        amount: ride.price,
        transactionId: 'TXN' + Math.random().toString(36).substr(2, 9).toUpperCase(),
        timestamp: new Date().toISOString()
      });
      setIsProcessing(false);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[2000] p-4">
      <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold">{language === 'hi' ? 'भुगतान करें' : 'Complete Payment'}</h2>
            <button onClick={onCancel} className="text-gray-400 hover:text-gray-600">✕</button>
          </div>

          <div className="bg-blue-50 p-4 rounded-xl mb-6 flex justify-between items-center">
            <div>
              <p className="text-xs text-blue-600 font-bold uppercase tracking-wider">{language === 'hi' ? 'कुल देय राशि' : 'Total Amount'}</p>
              <p className="text-2xl font-black text-blue-900">₹{ride.price}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-500">{ride.from} → {ride.to}</p>
              <p className="text-xs text-gray-500">{ride.date} | {ride.time}</p>
            </div>
          </div>

          {step === 'select' ? (
            <div className="space-y-3">
              <p className="text-sm font-bold text-gray-700 mb-2">{language === 'hi' ? 'भुगतान विधि चुनें' : 'Select Payment Method'}</p>
              
              <button 
                onClick={() => setStep('paytm')}
                className="w-full flex items-center justify-between p-4 border-2 border-gray-100 rounded-xl hover:border-blue-500 hover:bg-blue-50 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#00B9F1] rounded-lg flex items-center justify-center text-white font-bold text-xs">Paytm</div>
                  <div className="text-left">
                    <p className="font-bold group-hover:text-blue-700">Paytm UPI</p>
                    <p className="text-xs text-gray-500">{language === 'hi' ? 'सुरक्षित और तेज़' : 'Fast & Secure'}</p>
                  </div>
                </div>
                <div className="text-blue-500">→</div>
              </button>

              <button className="w-full flex items-center justify-between p-4 border-2 border-gray-100 rounded-xl opacity-50 cursor-not-allowed">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center text-gray-500 font-bold text-xs">Card</div>
                  <div className="text-left">
                    <p className="font-bold">{language === 'hi' ? 'डेबिट/क्रेडिट कार्ड' : 'Debit/Credit Card'}</p>
                    <p className="text-xs text-gray-500">{language === 'hi' ? 'जल्द आ रहा है' : 'Coming Soon'}</p>
                  </div>
                </div>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <button onClick={() => setStep('select')} className="text-blue-600 text-sm font-bold">← {language === 'hi' ? 'पीछे' : 'Back'}</button>
              </div>

              <div className="text-center mb-6">
                <img 
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Paytm_Logo_%28standalone%29.svg/1200px-Paytm_Logo_%28standalone%29.svg.png" 
                  alt="Paytm" 
                  className="h-8 mx-auto mb-2"
                />
                <p className="text-sm text-gray-600">{language === 'hi' ? 'अपनी UPI आईडी दर्ज करें' : 'Enter your UPI ID'}</p>
              </div>

              <div className="relative">
                <input 
                  type="text" 
                  placeholder="username@paytm" 
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-xl focus:border-blue-500 outline-none transition-all font-mono"
                />
                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold text-blue-500">UPI</div>
              </div>

              <div className="p-3 bg-gray-50 rounded-lg flex items-center gap-2">
                <span className="text-xs text-gray-500">🔒 {language === 'hi' ? 'आपका भुगतान सुरक्षित है' : 'Your payment is encrypted and secure'}</span>
              </div>
            </div>
          )}
        </div>

        <div className="p-6 bg-gray-50 border-t border-gray-100">
          <button 
            onClick={handlePayment}
            disabled={isProcessing || (step === 'paytm' && !upiId)}
            className={`w-full py-4 rounded-xl font-bold text-white shadow-lg transition-all ${
              isProcessing ? 'bg-gray-400' : 'bg-blue-600 hover:bg-blue-700 active:scale-95'
            }`}
          >
            {isProcessing ? (
              <div className="flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                {language === 'hi' ? 'प्रसंस्करण...' : 'Processing...'}
              </div>
            ) : (
              step === 'select' ? (language === 'hi' ? 'आगे बढ़ें' : 'Proceed') : (language === 'hi' ? `₹${ride.price} का भुगतान करें` : `Pay ₹${ride.price}`)
            )}
          </button>
          <p className="text-[10px] text-center text-gray-400 mt-4">
            By proceeding, you agree to EcoPool's Terms of Service and Privacy Policy.
          </p>
        </div>
      </div>
    </div>
  );
};
