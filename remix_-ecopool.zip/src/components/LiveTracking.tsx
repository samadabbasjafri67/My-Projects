import React from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-routing-machine/dist/leaflet-routing-machine.css';
import 'leaflet-routing-machine';
import { Ride, Booking, Location as TrackingLocation } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import { db, doc, onSnapshot, updateDoc, collection, query, where, getDoc } from '../firebase';
import { MapPin, Navigation, Info, X, ChevronRight, ChevronLeft, Phone } from 'lucide-react';

// Fix Leaflet default icon issue with Vite
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface LiveTrackingProps {
  ride: Ride;
  currentUser: string;
  role: 'driver' | 'passenger';
  bookingId?: string;
  onClose: () => void;
  language: string;
}

export const LiveTracking: React.FC<LiveTrackingProps> = ({ ride, currentUser, role, bookingId, onClose, language }) => {
  const mapRef = React.useRef<HTMLDivElement>(null);
  const [map, setMap] = React.useState<L.Map | null>(null);
  const [distance, setDistance] = React.useState("--");
  const [eta, setEta] = React.useState("--");
  const [instructions, setInstructions] = React.useState<any[]>([]);
  const [currentInstructionIndex, setCurrentInstructionIndex] = React.useState(0);
  const [showFullInstructions, setShowFullInstructions] = React.useState(false);
  const [followUser, setFollowUser] = React.useState(role === 'driver');
  const [voiceEnabled, setVoiceEnabled] = React.useState(false);
  const [shareLocation, setShareLocation] = React.useState(true);
  const [passengerReady, setPassengerReady] = React.useState(false);
  const [isGeocoding, setIsGeocoding] = React.useState(false);

  // Find the specific booking status if bookingId is provided, otherwise use the first one
  const currentBooking = bookingId ? ride.bookings?.find(b => b.bookingId === bookingId) : ride.bookings?.[0];
  const pickupStatus = currentBooking?.pickupStatus || 'scheduled';
  
  const [driverLocation, setDriverLocation] = React.useState<TrackingLocation | null>(ride.currentLocation || null);
  const [myPassengerLocation, setMyPassengerLocation] = React.useState<TrackingLocation | null>(null);
  const [passengerLocations, setPassengerLocations] = React.useState<Record<string, TrackingLocation>>({});
  
  const [resolvedDriverName, setResolvedDriverName] = React.useState<string>(ride.driverName || ride.driver);

  // Fetch actual human names for driver to prevent showing raw UIDs
  React.useEffect(() => {
    const fetchDriverName = async () => {
      // Determine if ride.driver looks like a UID (length > 15 and is alphanumeric)
      const isUid = ride.driver && ride.driver.length > 15 && /^[a-zA-Z0-9]+$/.test(ride.driver);
      const nameIsUid = ride.driverName && ride.driverName.length > 15 && /^[a-zA-Z0-9]+$/.test(ride.driverName);
      
      if (ride.driverName && !nameIsUid && !isUid) {
        setResolvedDriverName(ride.driverName);
        return;
      }
      
      const targetId = isUid ? ride.driver : (nameIsUid ? ride.driverName! : ride.driver);
      
      if (targetId) {
        try {
          const userDoc = await getDoc(doc(db, 'users', targetId));
          if (userDoc.exists()) {
            const data = userDoc.data();
            const fetchedName = data?.username || data?.name;
            if (fetchedName) {
              setResolvedDriverName(fetchedName);
            }
          }
        } catch (error) {
          console.error("Error fetching driver name in LiveTracking:", error);
        }
      }
    };

    fetchDriverName();
  }, [ride.driver, ride.driverName]);

  const driverMarkerRef = React.useRef<L.Marker | null>(null);
  const passengerMarkersRef = React.useRef<Record<string, L.Marker>>({});
  const routingControlRef = React.useRef<any>(null);

  // Initialize Map
  React.useEffect(() => {
    if (!mapRef.current) return;

    const trackingMap = L.map(mapRef.current).setView([28.6139, 77.2090], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(trackingMap);

    setMap(trackingMap);

    return () => {
      trackingMap.remove();
    };
  }, []);

  // Geocode and Route
  React.useEffect(() => {
    if (!map || !ride.from || !ride.to) return;

    const geocode = async (query: string) => {
      try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`);
        const data = await response.json();
        if (data && data.length > 0) {
          return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
        }
      } catch (err) {
        console.error("Geocoding error:", err);
      }
      return null;
    };

    const setupRoute = async () => {
      setIsGeocoding(true);
      const start = await geocode(ride.from);
      const end = await geocode(ride.to);
      setIsGeocoding(false);

      if (start && end) {
        // Determine routing waypoints based on ride phase
        // If ride hasn't started, show driver's approach to pickup
        let waypoints = [L.latLng(start.lat, start.lng), L.latLng(end.lat, end.lng)];
        
        // If we have driver location and ride hasn't started, show approach to pickup
        if (driverLocation && (pickupStatus === 'scheduled' || pickupStatus === 'on_the_way' || pickupStatus === 'arrived')) {
           waypoints = [L.latLng(driverLocation.lat, driverLocation.lng), L.latLng(start.lat, start.lng)];
        }

        // Add Start/End Markers
        L.marker([start.lat, start.lng], {
          icon: L.divIcon({
            className: 'start-marker',
            html: `<div style="background-color: #43a047; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; font-size: 10px; font-weight: bold;">S</div>`,
            iconSize: [24, 24],
            iconAnchor: [12, 12]
          })
        }).addTo(map).bindPopup(language === 'hi' ? 'पिकअप पॉइंट' : 'Pickup Point');

        L.marker([end.lat, end.lng], {
          icon: L.divIcon({
            className: 'end-marker',
            html: `<div style="background-color: #e53935; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; font-size: 10px; font-weight: bold;">E</div>`,
            iconSize: [24, 24],
            iconAnchor: [12, 12]
          })
        }).addTo(map).bindPopup(language === 'hi' ? 'ड्रॉप पॉइंट' : 'Drop Point');

        // Setup Routing
        if (routingControlRef.current && map) {
          try {
            map.removeControl(routingControlRef.current);
          } catch (e) {
            console.warn("Could not remove routing control:", e);
          }
        }

        const routingControl = (L as any).Routing.control({
          waypoints: waypoints,
          routeWhileDragging: false,
          addWaypoints: false,
          draggableWaypoints: false,
          fitSelectedRoutes: true,
          show: false,
          createMarker: () => null
        }).addTo(map);

        routingControl.on('routesfound', (e: any) => {
          const routes = e.routes;
          const summary = routes[0].summary;
          setDistance((summary.totalDistance / 1000).toFixed(1) + " km");
          setEta(Math.round(summary.totalTime / 60) + " min");
          setInstructions(routes[0].instructions);
        });

        routingControlRef.current = routingControl;
      }
    };

    setupRoute();
  }, [map, ride.from, ride.to, language, driverLocation]);

  // Update Driver Location in Firestore (if driver)
  const lastDriverUpdateRef = React.useRef<{ lat: number; lng: number; time: number }>({ lat: 0, lng: 0, time: 0 });

  React.useEffect(() => {
    if (role !== 'driver' || !ride.id) return;

    const watchId = navigator.geolocation.watchPosition(
      async (position) => {
        const { latitude: lat, longitude: lng } = position.coords;
        const now = Date.now();
        
        const newLoc: TrackingLocation = {
          lat,
          lng,
          timestamp: new Date().toISOString()
        };
        
        // Update local state immediately for smooth UI
        setDriverLocation(newLoc);

        // Throttle Firestore updates for driver: 
        // 1. Every 10 seconds OR
        // 2. Moved more than 20 meters
        const timeDiff = now - lastDriverUpdateRef.current.time;
        const distMoved = lastDriverUpdateRef.current.lat !== 0 ? 
          L.latLng(lat, lng).distanceTo(L.latLng(lastDriverUpdateRef.current.lat, lastDriverUpdateRef.current.lng)) : 
          100;

        if (timeDiff > 10000 || distMoved > 20) {
          try {
            await updateDoc(doc(db, 'rides', String(ride.id)), {
              currentLocation: newLoc
            });
            lastDriverUpdateRef.current = { lat, lng, time: now };
          } catch (error) {
            console.error("Error updating driver location in Firestore:", error);
          }
        }
      },
      (error) => console.error("Driver Geolocation error:", error),
      { enableHighAccuracy: true, maximumAge: 2000, timeout: 10000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [role, ride.id]);

  // Update Passenger Location in Firestore (if passenger and bookingId exists)
  const lastPassengerUpdateRef = React.useRef<{ lat: number; lng: number; time: number }>({ lat: 0, lng: 0, time: 0 });

  React.useEffect(() => {
    if (role !== 'passenger' || !bookingId || !shareLocation) return;

    const watchId = navigator.geolocation.watchPosition(
      async (position) => {
        const { latitude: lat, longitude: lng } = position.coords;
        const now = Date.now();
        
        // Update local state immediately
        const newLoc: TrackingLocation = {
          lat,
          lng,
          timestamp: new Date().toISOString()
        };
        setMyPassengerLocation(newLoc);

        // Throttle Firestore updates:
        // 1. At least 15 seconds have passed (passengers need less frequent updates)
        // 2. OR moved more than 30 meters
        const timeDiff = now - lastPassengerUpdateRef.current.time;
        const distMoved = lastPassengerUpdateRef.current.lat !== 0 ? 
          L.latLng(lat, lng).distanceTo(L.latLng(lastPassengerUpdateRef.current.lat, lastPassengerUpdateRef.current.lng)) : 
          100;

        if (timeDiff > 15000 || distMoved > 30) {
          try {
            await updateDoc(doc(db, 'bookings', bookingId), {
              currentLocation: newLoc
            });
            lastPassengerUpdateRef.current = { lat, lng, time: now };
          } catch (error) {
            console.error("Error updating passenger location:", error);
          }
        }
      },
      (error) => console.error("Geolocation error:", error),
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [role, bookingId, shareLocation]);

  // Listen for Driver Location (for passenger, or as fallback for driver)
  React.useEffect(() => {
    const unsub = onSnapshot(doc(db, 'rides', String(ride.id)), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as Ride;
        if (data.currentLocation) {
          // Only update if not driver (driver uses local state for smoothness)
          if (role !== 'driver') {
            setDriverLocation(data.currentLocation);
          }
        }
      }
    }, (error) => {
      console.warn("LiveTracking ride listener error under quota/offline:", error);
    });

    return () => unsub();
  }, [role, ride.id]);

  // Simulated Movement for Demo (if no real updates detected for 10s and status is on_the_way)
  React.useEffect(() => {
    if (role !== 'passenger' || !driverLocation || pickupStatus !== 'on_the_way' || !ride.fromCoords) return;

    const interval = setInterval(async () => {
      const now = new Date().getTime();
      const lastUpdate = new Date(driverLocation.timestamp).getTime();
      
      // If no update for 10 seconds, simulate a small step towards pickup
      if (now - lastUpdate > 10000) {
        setDriverLocation(prev => {
          if (!prev) return null;
          
          const latDiff = (ride.fromCoords!.lat - prev.lat) * 0.05;
          const lngDiff = (ride.fromCoords!.lng - prev.lng) * 0.05;
          
          // Stop if reached close enough
          if (Math.abs(latDiff) < 0.00001 && Math.abs(lngDiff) < 0.00001) return prev;

          return {
            lat: prev.lat + latDiff,
            lng: prev.lng + lngDiff,
            timestamp: new Date().toISOString()
          };
        });
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [role, driverLocation, pickupStatus, ride.fromCoords]);

  // Listen for Passenger Locations (if driver)
  React.useEffect(() => {
    if (role !== 'driver') return;

    const q = query(
      collection(db, 'bookings'), 
      where('rideId', '==', String(ride.id)),
      where('driverId', '==', currentUser)
    );
    const unsub = onSnapshot(q, (snapshot) => {
      const locations: Record<string, TrackingLocation> = {};
      snapshot.docs.forEach(doc => {
        const data = doc.data() as Booking;
        if (data.currentLocation) {
          locations[data.passengerName || data.passenger] = data.currentLocation;
        }
        if (bookingId && doc.id === bookingId) {
          setPassengerReady(!!data.pickupVerifiedAt || !!(data as any).passengerReady);
        }
      });
      setPassengerLocations(locations);
    }, (error) => {
      console.warn("LiveTracking passenger locations query error under quota/offline:", error);
    });

    return () => unsub();
  }, [role, ride.id]);

  // Update Markers on Map
  React.useEffect(() => {
    if (!map) return;

    // Driver Marker
    if (driverLocation) {
      if (driverMarkerRef.current) {
        driverMarkerRef.current.setLatLng([driverLocation.lat, driverLocation.lng]);
        driverMarkerRef.current.setPopupContent(`${language === 'hi' ? 'ड्राइवर' : 'Driver'}: ${resolvedDriverName}`);
      } else {
        const icon = L.divIcon({
          className: 'custom-div-icon',
          html: `<div style="background-color: #1d4ed8; color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 4px 6px rgba(0,0,0,0.3); font-weight: bold; position: relative;">
                  D
                  <div style="position: absolute; bottom: -10px; width: 0; height: 0; border-left: 5px solid transparent; border-right: 5px solid transparent; border-top: 10px solid #1d4ed8;"></div>
                </div>`,
          iconSize: [30, 30],
          iconAnchor: [15, 15]
        });
        driverMarkerRef.current = L.marker([driverLocation.lat, driverLocation.lng], { icon }).addTo(map)
          .bindPopup(`${language === 'hi' ? 'ड्राइवर' : 'Driver'}: ${resolvedDriverName}`);
      }

      if (followUser && map) {
        map.panTo([driverLocation.lat, driverLocation.lng]);
      }
    }

    // Passenger Markers
    Object.entries(passengerLocations).forEach(([passengerId, loc]) => {
      const pLoc = loc as TrackingLocation;
      if (passengerMarkersRef.current[passengerId]) {
        passengerMarkersRef.current[passengerId].setLatLng([pLoc.lat, pLoc.lng]);
      } else {
        const icon = L.divIcon({
          className: 'custom-div-icon',
          html: `<div style="background-color: #10b981; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); font-weight: bold; font-size: 10px;">P</div>`,
          iconSize: [24, 24],
          iconAnchor: [12, 12]
        });
        passengerMarkersRef.current[passengerId] = L.marker([pLoc.lat, pLoc.lng], { icon }).addTo(map)
          .bindPopup(`${language === 'hi' ? 'यात्री' : 'Passenger'}: ${passengerId}`);
      }
    });

  }, [map, driverLocation, passengerLocations, language, resolvedDriverName]);

  const currentInstruction = instructions[currentInstructionIndex];

  const notifyReady = async () => {
    if (!bookingId) return;
    try {
      await updateDoc(doc(db, 'bookings', bookingId), {
        passengerReady: true,
        readyAt: new Date().toISOString()
      });
      setPassengerReady(true);
    } catch (err) {
      console.error("Error notifying driver:", err);
    }
  };

  return (
    <div className="fixed inset-0 bg-white z-[5000] flex flex-col">
      <header className="bg-blue-700 text-white p-4 flex justify-between items-center shrink-0 shadow-lg">
        <div className="flex items-center gap-2">
          <Navigation className="w-5 h-5" />
          <h3 className="font-bold text-sm sm:text-base">
            {language === 'hi' ? 'लाइव ट्रैकिंग' : 'Live Tracking'}: {ride.from} → {ride.to}
          </h3>
        </div>
        <button className="bg-white/20 hover:bg-white/30 text-white text-xs py-1.5 px-4 rounded-full transition-colors" onClick={onClose}>
          {language === 'hi' ? 'बंद करें' : 'Close'}
        </button>
      </header>
      
      <div className="flex-1 relative overflow-hidden">
        {isGeocoding && (
          <div className="absolute inset-0 z-[2000] bg-white/50 backdrop-blur-sm flex items-center justify-center">
            <LoadingSpinner label={language === 'hi' ? 'मार्ग तैयार किया जा रहा है...' : 'Preparing route...'} />
          </div>
        )}
        <div ref={mapRef} className="absolute inset-0"></div>
        
        {/* Navigation Instructions (for driver or interested passengers) */}
        {instructions.length > 0 && (
          <div className="absolute top-4 left-4 right-4 z-[1000] pointer-events-none flex flex-col gap-2">
            <div className={`bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-2xl border border-blue-100 max-w-md mx-auto pointer-events-auto w-full ${role === 'driver' ? 'ring-4 ring-blue-500/30' : ''}`}>
              <div className="flex items-start gap-4">
                <div className={`bg-blue-600 text-white p-3 rounded-xl shadow-inner ${role === 'driver' ? 'animate-pulse' : ''}`}>
                  <Navigation className={`w-6 h-6 ${currentInstruction?.type === 'Left' ? '-rotate-45' : currentInstruction?.type === 'Right' ? 'rotate-45' : ''}`} />
                </div>
                <div className="flex-1">
                  <div className="text-[10px] text-blue-600 font-bold uppercase tracking-widest mb-1 flex justify-between">
                    <span>{language === 'hi' ? 'अगला कदम' : 'Next Step'}</span>
                    <div className="flex gap-2">
                      {role === 'driver' && <span className="text-green-600 animate-bounce">● {language === 'hi' ? 'लाइव' : 'LIVE'}</span>}
                      <button 
                        onClick={() => setShowFullInstructions(!showFullInstructions)}
                        className="text-blue-500 hover:underline pointer-events-auto"
                      >
                        {showFullInstructions ? (language === 'hi' ? 'छिपाएं' : 'Hide') : (language === 'hi' ? 'सूची' : 'List')}
                      </button>
                    </div>
                  </div>
                  <div className="text-[10px] text-gray-400 font-medium mb-1">
                    {(pickupStatus === 'scheduled' || pickupStatus === 'on_the_way' || pickupStatus === 'arrived') 
                      ? (language === 'hi' ? 'पिकअप की ओर' : 'Heading to Pickup') 
                      : (language === 'hi' ? 'गंतव्य की ओर' : 'Heading to Destination')}
                  </div>
                  <div className="text-sm sm:text-base font-black text-gray-800 leading-tight">
                    {currentInstruction?.text || (language === 'hi' ? 'सीधे चलें' : 'Continue straight')}
                  </div>
                  <div className="mt-2 h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-blue-600 transition-all duration-500" 
                      style={{ width: `${Math.min(100, (currentInstructionIndex / instructions.length) * 100)}%` }}
                    ></div>
                  </div>
                  <div className="text-[10px] text-gray-500 mt-1 font-medium flex justify-between">
                    <span>{(currentInstruction?.distance / 1000).toFixed(1)} km {language === 'hi' ? 'दूर' : 'away'}</span>
                    <span>{currentInstructionIndex + 1} / {instructions.length}</span>
                  </div>
                </div>
                <div className="flex flex-col gap-1 pointer-events-auto">
                  <button 
                    onClick={() => setCurrentInstructionIndex(prev => Math.max(0, prev - 1))}
                    disabled={currentInstructionIndex === 0}
                    className="p-1 hover:bg-gray-100 rounded disabled:opacity-30"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => setCurrentInstructionIndex(prev => Math.min(instructions.length - 1, prev + 1))}
                    disabled={currentInstructionIndex === instructions.length - 1}
                    className="p-1 hover:bg-gray-100 rounded disabled:opacity-30"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            {showFullInstructions && (
              <div className="bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-2xl border border-blue-100 max-w-md mx-auto pointer-events-auto w-full max-h-48 overflow-y-auto">
                <h4 className="text-xs font-bold text-gray-500 uppercase mb-2">{language === 'hi' ? 'सभी निर्देश' : 'All Instructions'}</h4>
                <div className="space-y-2">
                  {instructions.map((inst, idx) => (
                    <div 
                      key={idx} 
                      className={`text-xs p-2 rounded-lg cursor-pointer transition-colors ${idx === currentInstructionIndex ? 'bg-blue-100 border-l-4 border-blue-600' : 'hover:bg-gray-50'}`}
                      onClick={() => {
                        setCurrentInstructionIndex(idx);
                        setShowFullInstructions(false);
                      }}
                    >
                      <div className="flex justify-between items-center">
                        <span className={idx === currentInstructionIndex ? 'font-bold text-blue-700' : 'text-gray-700'}>{inst.text}</span>
                        <span className="text-[10px] text-gray-400">{(inst.distance / 1000).toFixed(1)} km</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Bottom Info Card */}
        <div className="absolute bottom-6 left-4 right-4 z-[1000]">
          <div className="bg-white/95 backdrop-blur-md p-5 rounded-2xl shadow-2xl border border-blue-100 max-w-2xl mx-auto">
            <div className="grid grid-cols-3 gap-4 text-center mb-5">
              <div className="bg-blue-50/50 p-2 rounded-xl">
                <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider mb-1">{language === 'hi' ? 'दूरी' : 'Distance'}</div>
                <div className="text-sm font-black text-blue-700">{distance}</div>
              </div>
              <div className="bg-blue-50/50 p-2 rounded-xl">
                <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider mb-1">{language === 'hi' ? 'समय' : 'ETA'}</div>
                <div className="text-sm font-black text-blue-700">{eta}</div>
              </div>
              <div className="bg-blue-50/50 p-2 rounded-xl">
                <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider mb-1">{language === 'hi' ? 'भूमिका' : 'Role'}</div>
                <div className="text-sm font-black text-blue-700 capitalize">{role === 'driver' ? (language === 'hi' ? 'ड्राइवर' : 'Driver') : (language === 'hi' ? 'यात्री' : 'Passenger')}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-4 pt-4 border-t border-gray-100">
              <div className="relative">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center font-bold text-white text-xl shadow-lg">
                  {resolvedDriverName.charAt(0).toUpperCase()}
                </div>
                <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 border-2 border-white rounded-full"></div>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-black text-gray-800">{resolvedDriverName}</span>
                  {ride.driverVerified && (
                    <div className="bg-blue-100 text-blue-700 text-[8px] px-1.5 py-0.5 rounded-full font-bold uppercase">Verified</div>
                  )}
                </div>
                <div className="text-xs text-gray-500 font-medium">{language === 'hi' ? 'वाहन' : 'Vehicle'}: {ride.vehicleNumber || (language === 'hi' ? 'सफेद स्विफ्ट' : 'White Swift')}</div>
                
                <div className="mt-2 space-y-1">
                  {role === 'passenger' && (
                    <div className="flex flex-col gap-2 mt-2">
                      <div className="flex items-center justify-between bg-blue-50 p-2 rounded-lg border border-blue-100">
                        <span className="text-[10px] font-bold text-blue-800 uppercase tracking-wider">
                          {language === 'hi' ? 'लोकेशन शेयर करें' : 'Share My Location'}
                        </span>
                        <button 
                          onClick={() => setShareLocation(!shareLocation)}
                          className={`w-8 h-4 rounded-full transition-colors relative ${shareLocation ? 'bg-blue-600' : 'bg-gray-300'}`}
                        >
                          <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-transform ${shareLocation ? 'left-4.5' : 'left-0.5'}`}></div>
                        </button>
                      </div>
                      
                      {!passengerReady && (
                        <button 
                          onClick={notifyReady}
                          className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2"
                        >
                          <MapPin className="w-4 h-4" />
                          {language === 'hi' ? 'मैं तैयार हूँ' : "I'm Ready at Pickup"}
                        </button>
                      )}
                      
                      {passengerReady && (
                        <div className="w-full py-2 bg-green-100 text-green-700 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border border-green-200">
                          <div className="w-2 h-2 bg-green-500 rounded-full animate-ping"></div>
                          {language === 'hi' ? 'ड्राइवर को सूचित कर दिया गया' : "Driver Notified - Ready"}
                        </div>
                      )}
                    </div>
                  )}

                  {role === 'driver' && passengerReady && (
                    <div className="mt-2 p-2 bg-green-100 text-green-700 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border border-green-200 animate-bounce">
                      <MapPin className="w-4 h-4" />
                      {language === 'hi' ? 'यात्री पिकअप पर तैयार है!' : "Passenger is Ready at Pickup!"}
                    </div>
                  )}
                  {role === 'driver' && driverLocation && Object.entries(passengerLocations).map(([pName, pLoc]) => (
                    <div key={pName} className="flex items-center gap-1 text-[10px] font-bold text-green-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-600 animate-pulse"></div>
                      {pName}: {(L.latLng(driverLocation.lat, driverLocation.lng).distanceTo(L.latLng((pLoc as TrackingLocation).lat, (pLoc as TrackingLocation).lng)) / 1000).toFixed(2)} km {language === 'hi' ? 'दूर' : 'away'}
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex gap-2">
                {ride.driverPhone && (
                  <a 
                    href={`tel:${ride.driverPhone}`}
                    className="p-3 bg-green-600 hover:bg-green-700 text-white rounded-xl shadow-lg transition-all active:scale-95 flex items-center justify-center"
                    title={language === 'hi' ? 'ड्राइवर को कॉल करें' : 'Call Driver'}
                  >
                    <Phone className="w-5 h-5" />
                  </a>
                )}
                <button 
                  className={`p-3 rounded-xl shadow-lg transition-all active:scale-95 flex items-center justify-center ${followUser ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`}
                  onClick={() => setFollowUser(!followUser)}
                  title={language === 'hi' ? 'मेरा स्थान फॉलो करें' : 'Follow My Location'}
                >
                  <Navigation className={`w-5 h-5 ${followUser ? 'animate-pulse' : ''}`} />
                </button>
                <button 
                  className="p-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl shadow-sm transition-all active:scale-95"
                  onClick={() => {
                    if (map && driverLocation) map.setView([driverLocation.lat, driverLocation.lng], 16);
                  }}
                >
                  <MapPin className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
