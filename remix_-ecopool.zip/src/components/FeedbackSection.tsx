import React from 'react';
import { TRANSLATIONS } from '../constants';
import { LoadingSpinner } from './LoadingSpinner';
import { db, collection, addDoc, handleFirestoreError, OperationType } from '../firebase';

interface FeedbackSectionProps {
  currentUser: string | null;
  userName: string;
  showNotification: (msg: string, color?: string) => void;
  language: string;
}

export const FeedbackSection: React.FC<FeedbackSectionProps> = ({ currentUser, userName, showNotification, language }) => {
  const [type, setType] = React.useState<'feedback' | 'issue'>('feedback');
  const [message, setMessage] = React.useState('');
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!message.trim()) {
      showNotification(language === 'hi' ? 'कृपया अपना संदेश लिखें' : 'Please enter your message', '#e53935');
      return;
    }

    setIsSubmitting(true);
    try {
      await addDoc(collection(db, 'feedback'), {
        userId: currentUser,
        userName: userName,
        type: type,
        message: message.trim(),
        createdAt: new Date().toISOString(),
        status: 'pending'
      });
      showNotification(language === 'hi' ? 'प्रतिक्रिया भेजने के लिए धन्यवाद!' : 'Thank you for your feedback!');
      setMessage('');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'feedback');
      showNotification(language === 'hi' ? 'प्रतिक्रिया भेजने में विफल' : 'Failed to submit feedback', '#e53935');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div id="feedbackSection" className="max-w-2xl mx-auto p-6 bg-white rounded-xl shadow-sm border border-gray-100 mt-8">
      <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
        {type === 'feedback' ? '💬' : '⚠️'} 
        {language === 'hi' ? 'प्रतिक्रिया और सहायता' : 'Feedback & Support'}
      </h2>
      <p className="text-gray-600 mb-6">
        {language === 'hi' 
          ? 'हम आपके सुझावों की सराहना करते हैं। कृपया हमें बताएं कि हम कैसे सुधार कर सकते हैं या किसी समस्या की रिपोर्ट करें।' 
          : 'We value your feedback. Please let us know how we can improve or report any issues you encounter.'}
      </p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex gap-4 mb-4">
          <button
            type="button"
            onClick={() => setType('feedback')}
            className={`flex-1 py-2 px-4 rounded-lg border transition-all ${
              type === 'feedback' 
                ? 'bg-blue-50 border-blue-200 text-blue-700 font-bold' 
                : 'bg-gray-50 border-gray-200 text-gray-600'
            }`}
          >
            {language === 'hi' ? 'सामान्य प्रतिक्रिया' : 'General Feedback'}
          </button>
          <button
            type="button"
            onClick={() => setType('issue')}
            className={`flex-1 py-2 px-4 rounded-lg border transition-all ${
              type === 'issue' 
                ? 'bg-red-50 border-red-200 text-red-700 font-bold' 
                : 'bg-gray-50 border-gray-200 text-gray-600'
            }`}
          >
            {language === 'hi' ? 'समस्या की रिपोर्ट करें' : 'Report an Issue'}
          </button>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1">
            {language === 'hi' ? 'आपका संदेश' : 'Your Message'}
          </label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder={language === 'hi' ? 'यहाँ अपना संदेश लिखें...' : 'Type your message here...'}
            className="w-full h-32 p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none resize-none"
            maxLength={5000}
          />
          <div className="text-right text-xs text-gray-400 mt-1">
            {message.length} / 5000
          </div>
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className={`w-full py-3 rounded-lg font-bold text-white transition-all flex items-center justify-center gap-2 ${
            isSubmitting 
              ? 'bg-gray-400 cursor-not-allowed' 
              : type === 'feedback' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-red-600 hover:bg-red-700'
          }`}
        >
          {isSubmitting && <LoadingSpinner size="sm" color="white" />}
          {isSubmitting 
            ? (language === 'hi' ? 'भेजा जा रहा है...' : 'Submitting...') 
            : (language === 'hi' ? 'प्रस्तुत करें' : 'Submit Feedback')}
        </button>
      </form>

      <div className="mt-8 p-4 bg-amber-50 rounded-lg border border-amber-100">
        <h4 className="font-bold text-amber-800 mb-1 text-sm">
          {language === 'hi' ? 'तत्काल सहायता चाहिए?' : 'Need Urgent Help?'}
        </h4>
        <p className="text-xs text-amber-700">
          {language === 'hi' 
            ? 'गंभीर सुरक्षा मुद्दों के लिए, कृपया हमारे 24/7 हेल्पलाइन पर संपर्क करें या ऐप में एसओएस बटन का उपयोग करें।' 
            : 'For critical safety issues, please contact our 24/7 helpline or use the SOS button in the app.'}
        </p>
      </div>
    </div>
  );
};
