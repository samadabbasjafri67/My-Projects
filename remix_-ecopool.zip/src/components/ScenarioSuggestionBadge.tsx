import React from 'react';
import { motion } from 'motion/react';
import { Clock, MapPin, Sparkles, TrendingDown } from 'lucide-react';
import { ScenarioSuggestion } from '../services/scenarioSuggestionService';

interface ScenarioSuggestionBadgeProps {
  suggestion: ScenarioSuggestion;
  onApply?: () => void;
  language: string;
}

export const ScenarioSuggestionBadge: React.FC<ScenarioSuggestionBadgeProps> = ({ suggestion, onApply, language }) => {
  const isHindi = language === 'hi';

  const icons = {
    wait: <Clock size={14} className="text-blue-500" />,
    walk: <MapPin size={14} className="text-amber-500" />,
    shared: <TrendingDown size={14} className="text-emerald-500" />
  };

  const bgColors = {
    wait: 'bg-blue-50/50 border-blue-100',
    walk: 'bg-amber-50/50 border-amber-100',
    shared: 'bg-emerald-50/50 border-emerald-100'
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      className={`p-4 rounded-3xl border-2 border-dashed ${bgColors[suggestion.type]} flex items-start gap-4 transition-all hover:bg-white hover:border-solid hover:shadow-lg hover:shadow-slate-100`}
    >
      <div className={`p-2.5 rounded-2xl bg-white shadow-sm shrink-0`}>
        {icons[suggestion.type]}
      </div>
      
      <div className="flex-1 space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">
            {suggestion.benefit}
          </span>
          <Sparkles size={10} className="text-primary animate-pulse" />
        </div>
        <p className="text-xs font-bold text-slate-800 leading-snug">
          {suggestion.label}
        </p>
      </div>

      <button
        onClick={onApply}
        className="px-4 py-2 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-primary transition-all active:scale-95 shrink-0"
      >
        {suggestion.actionLabel}
      </button>
    </motion.div>
  );
};
