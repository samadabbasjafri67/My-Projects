import React from 'react';
import { User, Ride, Rating } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import { db, collection, query, getDocs, where, handleFirestoreError, OperationType, updateDoc, doc } from '../firebase';

interface AdminSectionProps {
  currentUser: string;
  showNotification: (msg: string, color?: string) => void;
  approveUserVerification: (uid: string) => Promise<boolean>;
  rejectUserVerification: (uid: string) => Promise<boolean>;
  removeUser: (uid: string) => Promise<boolean>;
  language: string;
}

export const AdminSection: React.FC<AdminSectionProps> = ({
  currentUser,
  showNotification,
  approveUserVerification,
  rejectUserVerification,
  removeUser,
  language
}) => {
  const [activeTab, setActiveTab] = React.useState("users");
  const [stats, setStats] = React.useState<any>({});
  const [pendingVerifications, setPendingVerifications] = React.useState<User[]>([]);
  const [allUsers, setAllUsers] = React.useState<User[]>([]);
  const [feedback, setFeedback] = React.useState<any[]>([]);
  const [userToDelete, setUserToDelete] = React.useState<any>(null);
  const [showDeleteModal, setShowDeleteModal] = React.useState(false);
  const [selectedUserDocs, setSelectedUserDocs] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);
  const [isActionLoading, setIsActionLoading] = React.useState(false);

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const usersSnapshot = await getDocs(collection(db, 'users'));
      const users = usersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      setAllUsers(users);
      
      const pending = users.filter((u: User) => u.verificationStatus === 'pending');
      setPendingVerifications(pending);

      const totalCarbonSaved = users.reduce((sum: number, u: User) => sum + (u.carbonSaved || 0), 0);
      
      const ridesSnapshot = await getDocs(collection(db, 'rides'));
      const rides = ridesSnapshot.docs.map(doc => doc.data() as Ride);
      const totalEarnings = rides.reduce((sum: number, r: Ride) => sum + (r.price || 0), 0);
      
      setStats({
        totalUsers: users.length,
        totalCarbonSaved,
        totalRides: rides.length,
        totalEarnings
      });

      const feedbackSnapshot = await getDocs(collection(db, 'feedback'));
      const feedbackData = feedbackSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      setFeedback(feedbackData.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    } catch (error) {
      console.error("Error fetching admin data:", error);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    if (currentUser) {
      fetchAdminData();
    }
  }, [currentUser]);

  const handleApprove = async (uid: string) => {
    setIsActionLoading(true);
    try {
      await approveUserVerification(uid);
      await fetchAdminData();
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleReject = async (uid: string) => {
    setIsActionLoading(true);
    try {
      await rejectUserVerification(uid);
      await fetchAdminData();
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleResolveFeedback = async (feedbackId: string) => {
    setIsActionLoading(true);
    try {
      const feedbackRef = doc(db, 'feedback', feedbackId);
      await updateDoc(feedbackRef, { status: 'resolved' });
      showNotification(language === 'hi' ? 'प्रतिक्रिया को हल के रूप में चिह्नित किया गया है' : 'Feedback marked as resolved', '#10b981');
      await fetchAdminData();
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `feedback/${feedbackId}`);
    } finally {
      setIsActionLoading(false);
    }
  };

  const confirmDeleteUser = (user: any) => {
    setUserToDelete(user);
    setShowDeleteModal(true);
  };

  const handleDeleteUser = async () => {
    if (!userToDelete) return;
    setIsActionLoading(true);
    try {
      const success = await removeUser(userToDelete.id);
      if (success) {
        setShowDeleteModal(false);
        setUserToDelete(null);
        await fetchAdminData();
      }
    } finally {
      setIsActionLoading(false);
    }
  };

  return (
    <div id="adminSection">
      <h2 className="text-xl font-bold mb-4">{language === 'hi' ? 'एडमिन डैशबोर्ड' : 'Admin Dashboard'}</h2>
      
      {loading ? (
        <div className="py-20">
          <LoadingSpinner label={language === 'hi' ? 'डेटा लोड हो रहा है...' : 'Fetching admin data...'} />
        </div>
      ) : (
        <>
          <div className="stats-grid mb-6">
        <div className="stat-card">
          <h3>{language === 'hi' ? 'कुल उपयोगकर्ता' : 'Total Users'}</h3>
          <div className="number">{stats.totalUsers || 0}</div>
        </div>
        <div className="stat-card">
          <h3>{language === 'hi' ? 'कुल सवारी' : 'Total Rides'}</h3>
          <div className="number">{stats.totalRides || 0}</div>
        </div>
        <div className="stat-card">
          <h3>{language === 'hi' ? 'कुल कमाई' : 'Total Earnings'}</h3>
          <div className="number">₹{stats.totalEarnings || 0}</div>
        </div>
        <div className="stat-card">
          <h3>{language === 'hi' ? 'कार्बन बचाया' : 'Carbon Saved'}</h3>
          <div className="number">{(stats.totalCarbonSaved || 0).toFixed(1)} kg</div>
        </div>
      </div>

      <div className="tab-buttons mb-4">
        <button className={`tab-button ${activeTab === 'users' ? 'active' : ''}`} onClick={() => setActiveTab('users')}>{language === 'hi' ? 'उपयोगकर्ता' : 'Users'}</button>
        <button className={`tab-button ${activeTab === 'verifications' ? 'active' : ''}`} onClick={() => setActiveTab('verifications')}>{language === 'hi' ? 'सत्यापन' : 'Verifications'}</button>
        <button className={`tab-button ${activeTab === 'fraud' ? 'active' : ''}`} onClick={() => setActiveTab('fraud')}>{language === 'hi' ? 'धोखाधड़ी घड़ी' : 'Fraud Watch'}</button>
        <button className={`tab-button ${activeTab === 'feedback' ? 'active' : ''}`} onClick={() => setActiveTab('feedback')}>{language === 'hi' ? 'प्रतिक्रिया' : 'Feedback'}</button>
      </div>

      {activeTab === 'verifications' && (
        <div className="bg-white rounded-lg border p-4 relative">
          {isActionLoading && (
            <div className="absolute inset-0 z-10 bg-white/50 backdrop-blur-[1px] flex items-center justify-center">
              <LoadingSpinner size="md" />
            </div>
          )}
          <h3 className="font-bold mb-4">{language === 'hi' ? 'लंबित सत्यापन' : 'Pending Verifications'}</h3>
          {pendingVerifications.length === 0 ? (
            <p className="text-gray-500 italic">{language === 'hi' ? 'कोई लंबित सत्यापन नहीं।' : 'No pending verifications.'}</p>
          ) : (
            pendingVerifications.map(u => (
              <div key={(u as any).id} className="p-4 border rounded-lg mb-4 bg-gray-50">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="font-bold text-lg">{u.username}</div>
                    <div className="text-sm text-gray-500">{u.email}</div>
                    <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
                      <span className="text-gray-400 uppercase font-bold">Full Name:</span> <span>{(u as any).fullName || 'N/A'}</span>
                      <span className="text-gray-400 uppercase font-bold">Aadhar:</span> <span>{(u as any).aadharNumber || 'N/A'}</span>
                      <span className="text-gray-400 uppercase font-bold">Vehicle:</span> <span>{(u as any).vehicleNumber || 'N/A'}</span>
                      <span className="text-gray-400 uppercase font-bold">Vehicle Name:</span> <span>{(u as any).carName || 'N/A'}</span>
                      <span className="text-gray-400 uppercase font-bold">Vehicle Type:</span> <span className="capitalize">{(u as any).carType || 'N/A'}</span>
                      <span className="text-gray-400 uppercase font-bold">License:</span> <span>{(u as any).licenseNumber || 'N/A'}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button className="success-btn text-xs py-1 px-3" onClick={() => handleApprove((u as any).id)}>{language === 'hi' ? 'अनुमोदित करें' : 'Approve'}</button>
                    <button className="logout-btn text-xs py-1 px-3" onClick={() => handleReject((u as any).id)}>{language === 'hi' ? 'अस्वीकार करें' : 'Reject'}</button>
                  </div>
                </div>

                {(u as any).verificationDocuments && (u as any).verificationDocuments.length > 0 && (
                  <div className="mt-4 pt-4 border-t">
                    <h4 className="text-xs font-bold uppercase text-gray-400 mb-2">Documents:</h4>
                    <div className="flex gap-4 overflow-x-auto pb-2">
                      {(u as any).verificationDocuments.map((doc: any, idx: number) => (
                        <div key={idx} className="flex-shrink-0">
                          <p className="text-[10px] font-bold mb-1">{doc.name}</p>
                          <div 
                            className="h-24 w-32 bg-white border rounded overflow-hidden cursor-pointer hover:border-blue-500 transition-colors"
                            onClick={() => setSelectedUserDocs({ user: u, doc })}
                          >
                            <img src={doc.data} alt={doc.name} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'fraud' && (
        <div className="bg-white rounded-lg border p-4">
          <h3 className="font-bold mb-4">{language === 'hi' ? 'संदिग्ध गतिविधियां' : 'Suspicious Activity'}</h3>
          <div className="overflow-x-auto">
            <table className="user-table">
              <thead>
                <tr>
                  <th>{language === 'hi' ? 'उपयोगकर्ता' : 'User'}</th>
                  <th>{language === 'hi' ? 'स्कोर' : 'Score'}</th>
                  <th>{language === 'hi' ? 'रद्द' : 'Cancels'}</th>
                  <th>{language === 'hi' ? 'ट्रस्ट' : 'Trust'}</th>
                  <th>{language === 'hi' ? 'कार्रवाई' : 'Action'}</th>
                </tr>
              </thead>
              <tbody>
                {allUsers.filter((u: any) => u.isFlagged || u.fraudScore > 20 || u.trustLevel === 'blocked').map((u: any) => (
                  <tr key={u.id} className={u.trustLevel === 'blocked' ? 'bg-red-50' : ''}>
                    <td>
                      <div className="font-bold">{u.username}</div>
                      <div className="text-[10px] text-gray-500">{u.email}</div>
                    </td>
                    <td>
                      <span className={`font-bold ${u.fraudScore > 50 ? 'text-red-600' : 'text-orange-600'}`}>
                        {u.fraudScore || 0}
                      </span>
                    </td>
                    <td>{u.cancellationCount || 0}</td>
                    <td>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        u.trustLevel === 'blocked' ? 'bg-red-600 text-white' :
                        u.trustLevel === 'suspicious' ? 'bg-orange-200 text-orange-800' :
                        u.trustLevel === 'neutral' ? 'bg-gray-200 text-gray-800' :
                        'bg-green-200 text-green-800'
                      }`}>
                        {u.trustLevel || 'neutral'}
                      </span>
                    </td>
                    <td>
                      <div className="flex gap-2">
                        {u.trustLevel !== 'blocked' ? (
                          <button 
                            className="bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded hover:bg-red-700"
                            onClick={async () => {
                              setIsActionLoading(true);
                              await updateDoc(doc(db, 'users', u.id), { trustLevel: 'blocked', isFlagged: true });
                              await fetchAdminData();
                              setIsActionLoading(false);
                            }}
                          >
                            Block
                          </button>
                        ) : (
                          <button 
                            className="bg-green-600 text-white text-[10px] font-bold px-2 py-1 rounded hover:bg-green-700"
                            onClick={async () => {
                              setIsActionLoading(true);
                              await updateDoc(doc(db, 'users', u.id), { trustLevel: 'trusted', isFlagged: false, fraudScore: 0, cancellationCount: 0 });
                              await fetchAdminData();
                              setIsActionLoading(false);
                            }}
                          >
                            Unblock
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
                {allUsers.filter((u: any) => u.isFlagged || u.fraudScore > 20 || u.trustLevel === 'blocked').length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center py-4 text-gray-500 italic">
                      {language === 'hi' ? 'कोई संदिग्ध उपयोगकर्ता नहीं मिले' : 'No suspicious users found'}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'feedback' && (
        <div className="bg-white rounded-lg border p-4">
          <h3 className="font-bold mb-4">{language === 'hi' ? 'उपयोगकर्ता प्रतिक्रिया' : 'User Feedback'}</h3>
          {feedback.length === 0 ? (
            <p className="text-gray-500 italic">{language === 'hi' ? 'कोई प्रतिक्रिया नहीं मिली।' : 'No feedback found.'}</p>
          ) : (
            feedback.map(f => (
              <div key={f.id} className={`p-4 border rounded-lg mb-3 ${f.type === 'issue' ? 'bg-red-50 border-red-100' : 'bg-blue-50 border-blue-100'}`}>
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${f.type === 'issue' ? 'bg-red-200 text-red-800' : 'bg-blue-200 text-blue-800'}`}>
                      {f.type === 'issue' ? (language === 'hi' ? 'समस्या' : 'Issue') : (language === 'hi' ? 'प्रतिक्रिया' : 'Feedback')}
                    </span>
                    <span className="ml-2 font-bold text-sm">{f.userName}</span>
                  </div>
                  <span className="text-[10px] text-gray-500">{new Date(f.createdAt).toLocaleString()}</span>
                </div>
                <p className="text-sm text-gray-700 whitespace-pre-wrap">{f.message}</p>
                <div className="mt-2 flex justify-between items-center">
                  <div className="flex gap-2">
                    {f.status !== 'resolved' && (
                      <button 
                        className="bg-green-600 text-white text-[10px] font-bold px-2 py-1 rounded hover:bg-green-700 transition-colors"
                        onClick={() => handleResolveFeedback(f.id)}
                        disabled={isActionLoading}
                      >
                        {language === 'hi' ? 'हल के रूप में चिह्नित करें' : 'Mark as Resolved'}
                      </button>
                    )}
                  </div>
                  <span className={`text-[10px] font-bold ${f.status === 'resolved' ? 'text-green-600' : 'text-orange-600'}`}>
                    {f.status === 'resolved' ? (language === 'hi' ? 'हल किया गया' : 'Resolved') : (language === 'hi' ? 'लंबित' : 'Pending')}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'users' && (
        <div className="overflow-x-auto">
          <table className="user-table">
            <thead>
              <tr>
                <th>{language === 'hi' ? 'उपयोगकर्ता नाम' : 'Username'}</th>
                <th>{language === 'hi' ? 'भूमिका' : 'Role'}</th>
                <th>{language === 'hi' ? 'सवारी' : 'Rides'}</th>
                <th>{language === 'hi' ? 'कार्बन बचाया' : 'Carbon Saved'}</th>
                <th>{language === 'hi' ? 'स्थिति' : 'Status'}</th>
                <th>{language === 'hi' ? 'कार्रवाई' : 'Action'}</th>
              </tr>
            </thead>
            <tbody>
              {allUsers.map((u: any) => (
                <tr key={u.id}>
                  <td>{u.username}</td>
                  <td className="capitalize">{u.role === 'admin' ? (language === 'hi' ? 'एडमिन' : 'admin') : (language === 'hi' ? 'उपयोगकर्ता' : 'user')}</td>
                  <td>{u.totalRides || 0}</td>
                  <td>{(u.carbonSaved || 0).toFixed(1)} kg</td>
                  <td><span className="text-green-600 font-bold">{language === 'hi' ? 'सक्रिय' : 'Active'}</span></td>
                  <td>
                    {u.id !== currentUser && (
                      <button 
                        className="text-red-600 hover:text-red-800 font-bold text-xs"
                        onClick={() => confirmDeleteUser(u)}
                      >
                        {language === 'hi' ? 'हटाएं' : 'Remove'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  )}

  {/* Document Viewer Modal */}
      {selectedUserDocs && (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-[10000] p-4" onClick={() => setSelectedUserDocs(null)}>
          <div className="relative max-w-4xl w-full max-h-[90vh] flex flex-col items-center" onClick={e => e.stopPropagation()}>
            <button 
              className="absolute -top-10 right-0 text-white text-2xl"
              onClick={() => setSelectedUserDocs(null)}
            >
              ✕
            </button>
            <h3 className="text-white font-bold mb-4 text-xl">{selectedUserDocs.user.username} - {selectedUserDocs.doc.name}</h3>
            <div className="w-full h-full bg-white rounded-lg overflow-hidden flex items-center justify-center">
              <img src={selectedUserDocs.doc.data} alt="Document" className="max-w-full max-h-full object-contain" referrerPolicy="no-referrer" />
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
          <div className="bg-white w-full max-w-md rounded-xl overflow-hidden shadow-2xl p-6">
            <h3 className="text-xl font-bold mb-4">{language === 'hi' ? 'उपयोगकर्ता को हटाएं' : 'Remove User'}</h3>
            <p className="text-sm text-gray-600 mb-6">
              {language === 'hi' 
                ? `क्या आप वाकई ${userToDelete?.username} को हटाना चाहते हैं? यह क्रिया अपरिवर्तनीय है।` 
                : `Are you sure you want to remove ${userToDelete?.username}? This action cannot be undone.`}
            </p>
            
            <div className="flex gap-3">
              <button className="secondary-btn flex-1" onClick={() => setShowDeleteModal(false)} disabled={isActionLoading}>
                {language === 'hi' ? 'रद्द करें' : 'Cancel'}
              </button>
              <button 
                className={`bg-red-600 text-white flex-1 rounded-lg font-bold flex items-center justify-center gap-2 ${isActionLoading ? 'opacity-70 cursor-not-allowed' : ''}`} 
                onClick={handleDeleteUser}
                disabled={isActionLoading}
              >
                {isActionLoading && <LoadingSpinner size="sm" color="white" />}
                {language === 'hi' ? 'हटाएं' : 'Remove'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
