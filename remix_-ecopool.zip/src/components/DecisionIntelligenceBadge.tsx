import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, ArrowRight, Zap, Leaf, Star } from 'lucide-react';
import { DecisionInsight } from '../services/decisionIntelligenceService';

interface DecisionIntelligenceBadgeProps {
  insight: DecisionInsight;
  onApply: (ride: any) => void;
  language: string;
}

export const DecisionIntelligenceBadge: React.FC<DecisionIntelligenceBadgeProps> = ({ insight, onApply, language }) => {
  const isHindi = language === 'hi';

  const icons = {
    cheaper: <Zap size={14} className="text-amber-500" />,
    eco: <Leaf size={14} className="text-emerald-500" />,
    rating: <Star size={14} className="text-blue-500" />
  };

  const colors = {
    cheaper: 'bg-amber-50 border-amber-100 text-amber-900',
    eco: 'bg-emerald-50 border-emerald-100 text-emerald-900',
    rating: 'bg-blue-50 border-blue-100 text-blue-900'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`p-3 rounded-2xl border flex items-center justify-between gap-4 shadow-sm ${colors[insight.type]}`}
    >
      <div className="flex items-center gap-3">
        <div className="bg-white/80 p-2 rounded-xl shadow-sm">
          {icons[insight.type]}
        </div>
        <div>
          <div className="flex items-center gap-1.5 ">
            <span className="text-[10px] font-black uppercase tracking-widest opacity-60">
              {isHindi ? 'बेहतर विकल्प मौजूद है' : 'Better option exists'}
            </span>
            <Sparkles size={10} className="animate-pulse" />
          </div>
          <p className="text-xs font-black leading-tight mt-0.5">
            {insight.reason}
          </p>
        </div>
      </div>

      <button
        onClick={(e) => {
          e.stopPropagation();
          onApply(insight.betterRide);
        }}
        className="flex items-center gap-2 px-3 py-2 bg-white/80 hover:bg-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all hover:translate-x-1 active:scale-95 shadow-sm border border-black/5"
      >
        {isHindi ? 'इसे चुनें' : 'Select This'}
        <ArrowRight size={12} />
      </button>
    </motion.div>
  );
};
