import React from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-routing-machine/dist/leaflet-routing-machine.css';
import 'leaflet-routing-machine';
import { Ride } from '../types';
import { X, Navigation, MapPin } from 'lucide-react';

// Fix Leaflet default icon issue with Vite
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface RouteMapProps {
  ride: Ride;
  onClose: () => void;
  language: string;
}

export const RouteMap: React.FC<RouteMapProps> = ({ ride, onClose, language }) => {
  const mapRef = React.useRef<HTMLDivElement>(null);
  const [map, setMap] = React.useState<L.Map | null>(null);
  const [distance, setDistance] = React.useState("--");
  const [eta, setEta] = React.useState("--");
  const [stopCoords, setStopCoords] = React.useState<any[]>([]);
  const routingControlRef = React.useRef<any>(null);
  const [activeTag, setActiveTag] = React.useState<'fastest' | 'cheapest' | 'eco'>('fastest');

  React.useEffect(() => {
    if (!mapRef.current) return;

    const routeMap = L.map(mapRef.current).setView([28.6139, 77.2090], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(routeMap);

    setMap(routeMap);

    return () => {
      routeMap.remove();
    };
  }, []);

  React.useEffect(() => {
    if (!map || !ride.from || !ride.to) return;

    const geocode = async (query: string) => {
      try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`);
        const data = await response.json();
        if (data && data.length > 0) {
          return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
        }
      } catch (err) {
        console.error("Geocoding error:", err);
      }
      return null;
    };

    const setupRoute = async () => {
      const start = await geocode(ride.from);
      const end = await geocode(ride.to);
      
      // Geocode waypoints if any
      const tempStopCoords = [];
      if (ride.waypoints) {
        for (const wp of ride.waypoints) {
          const coords = await geocode(wp.address);
          if (coords) tempStopCoords.push(coords);
        }
      }
      setStopCoords(tempStopCoords);

      if (start && end) {
        // Clear existing markers/controls if any
        map.eachLayer((layer: any) => {
          if (!!layer.toGeoJSON) { 
             map.removeLayer(layer);
          }
        });

        // Add Start/End Markers
        L.marker([start.lat, start.lng], {
          icon: L.divIcon({
            className: 'start-marker',
            html: `<div style="background-color: #43a047; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; font-size: 10px; font-weight: bold; box-shadow: 0 2px 10px rgba(67, 160, 71, 0.4);">S</div>`,
            iconSize: [24, 24],
            iconAnchor: [12, 12]
          })
        }).addTo(map).bindPopup(language === 'hi' ? 'प्रारंभ' : 'Start');

        L.marker([end.lat, end.lng], {
          icon: L.divIcon({
            className: 'end-marker',
            html: `<div style="background-color: #e53935; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; font-size: 10px; font-weight: bold; box-shadow: 0 2px 10px rgba(229, 57, 53, 0.4);">E</div>`,
            iconSize: [24, 24],
            iconAnchor: [12, 12]
          })
        }).addTo(map).bindPopup(language === 'hi' ? 'समाप्त' : 'End');

        // Add Stop Markers
        tempStopCoords.forEach((coords, idx) => {
          L.marker([coords.lat, coords.lng], {
            icon: L.divIcon({
              className: 'stop-marker',
              html: `<div style="background-color: #fb8c00; color: white; width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; font-size: 8px; font-weight: bold;">${idx + 1}</div>`,
              iconSize: [20, 20],
              iconAnchor: [10, 10]
            })
          }).addTo(map).bindPopup(`${language === 'hi' ? 'स्टॉप' : 'Stop'} ${idx + 1}: ${ride.waypoints?.[idx]?.address}`);
        });

        // Setup Routing
        if (routingControlRef.current && map) {
          try {
            map.removeControl(routingControlRef.current);
          } catch (e) {
            console.warn("Could not remove routing control:", e);
          }
        }

        const waypoints = [
          L.latLng(start.lat, start.lng),
          ...tempStopCoords.map(c => L.latLng(c.lat, c.lng)),
          L.latLng(end.lat, end.lng)
        ];

        const routingControl = (L as any).Routing.control({
          waypoints,
          routeWhileDragging: false,
          addWaypoints: false,
          draggableWaypoints: false,
          fitSelectedRoutes: true,
          show: false,
          createMarker: () => null,
          lineOptions: {
            styles: [
              { 
                color: activeTag === 'eco' ? '#059669' : activeTag === 'cheapest' ? '#2563eb' : '#4f46e5', 
                opacity: 0.8, 
                weight: 6 
              }
            ]
          }
        }).addTo(map);

        routingControl.on('routesfound', (e: any) => {
          const routes = e.routes;
          const summary = routes[0].summary;
          
          let distVal = summary.totalDistance / 1000;
          let timeVal = Math.round(summary.totalTime / 60);

          // Simulated differences for optimization modes
          if (activeTag === 'cheapest') {
            distVal *= 1.1; // Longer route but avoids tolls (simulated)
            timeVal *= 1.2;
          } else if (activeTag === 'eco') {
            distVal *= 0.95; // Shorter distance (simulated)
            timeVal *= 1.1; // But slower speeds
          }

          setDistance(distVal.toFixed(1) + " km");
          setEta(timeVal + " min");
        });

        routingControlRef.current = routingControl;
      }
    };

    setupRoute();
  }, [map, ride.from, ride.to, ride.waypoints, language, activeTag]);

  const tags = [
    { id: 'fastest', icon: '⚡', label: language === 'hi' ? 'सबसे तेज़' : 'Fastest', color: 'bg-indigo-600' },
    { id: 'cheapest', icon: '💰', label: language === 'hi' ? 'सस्ता' : 'Cheapest', color: 'bg-blue-600' },
    { id: 'eco', icon: '🌱', label: language === 'hi' ? 'इको' : 'Eco', color: 'bg-emerald-600' }
  ];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[5000] flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-4xl h-[85vh] rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col relative border border-white/20">
        <header className="bg-slate-900 text-white p-5 pt-7 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-4">
            <div className="bg-white/10 p-2.5 rounded-2xl backdrop-blur-md border border-white/10">
              <Navigation className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h3 className="font-black text-sm uppercase tracking-[0.2em] leading-none mb-1.5">{language === 'hi' ? 'स्मार्ट रूटिंग' : 'Smart Routing'}</h3>
              <p className="text-xs text-slate-400 font-bold">{ride.from} → {ride.to}</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2.5 hover:bg-white/10 rounded-2xl transition-all active:scale-90"
          >
            <X className="w-5 h-5" />
          </button>
        </header>

        <div className="flex-1 relative bg-slate-50">
          <div ref={mapRef} className="absolute inset-0"></div>
          
          {/* Optimization Selector */}
          <div className="absolute top-6 left-6 z-[1000] flex flex-col gap-2">
            {tags.map(t => (
              <button
                key={t.id}
                onClick={() => setActiveTag(t.id as any)}
                className={`p-1 pr-4 rounded-2xl flex items-center gap-2 transition-all duration-300 shadow-lg ${
                  activeTag === t.id 
                    ? `${t.color} text-white scale-105` 
                    : 'bg-white/90 backdrop-blur-md text-slate-500 hover:bg-white'
                }`}
              >
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold ${activeTag === t.id ? 'bg-white/20' : 'bg-slate-100'}`}>
                  {t.icon}
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest">{t.label}</span>
              </button>
            ))}
          </div>

          <div className="absolute bottom-6 left-6 right-6 z-[1000]">
            <div className="bg-white/95 backdrop-blur-xl p-4 rounded-[2rem] shadow-2xl border border-slate-100 flex justify-around text-center">
              <div className="flex-1">
                <div className="text-[9px] text-slate-400 uppercase font-black tracking-[0.2em] mb-1">{language === 'hi' ? 'दूरी' : 'Distance'}</div>
                <div className="text-sm font-black text-slate-900">{distance}</div>
              </div>
              <div className="w-px h-8 bg-slate-100 self-center"></div>
              <div className="flex-1">
                <div className="text-[9px] text-slate-400 uppercase font-black tracking-[0.2em] mb-1">{language === 'hi' ? 'अनुमानित' : 'Estimate'}</div>
                <div className="text-sm font-black text-slate-900">{eta}</div>
              </div>
              <div className="w-px h-8 bg-slate-100 self-center"></div>
              <div className="flex-1">
                <div className="text-[9px] text-slate-400 uppercase font-black tracking-[0.2em] mb-1">{language === 'hi' ? 'स्टॉप्स' : 'Stops'}</div>
                <div className="text-sm font-black text-slate-900">{stopCoords?.length || 0}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 border-t border-slate-50 shrink-0">
          <div className="flex flex-col gap-4">
            <div className="flex items-start gap-4">
              <div className="flex flex-col items-center shrink-0 pt-1">
                <div className="w-3 h-3 rounded-full border-2 border-emerald-500 bg-white"></div>
                <div className="w-0.5 h-10 border-l-2 border-dashed border-slate-200 my-1"></div>
                {ride.waypoints?.map((_, i) => (
                  <React.Fragment key={i}>
                    <div className="w-2 h-2 rounded-full bg-orange-400"></div>
                    <div className="w-0.5 h-6 border-l-2 border-dashed border-slate-200 my-1"></div>
                  </React.Fragment>
                ))}
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
              </div>

              <div className="flex-1 space-y-6">
                <div>
                  <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{language === 'hi' ? 'पिकअप' : 'Pickup'}</div>
                  <div className="text-xs font-bold text-slate-800">{ride.from}</div>
                </div>

                {ride.waypoints?.map((wp, i) => (
                  <div key={i}>
                    <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{language === 'hi' ? 'स्टॉप' : 'Stop'} {i + 1}</div>
                    <div className="text-xs font-bold text-slate-800">{wp.address}</div>
                  </div>
                ))}

                <div>
                  <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{language === 'hi' ? 'ड्रॉप' : 'Drop'}</div>
                  <div className="text-xs font-bold text-slate-800">{ride.to}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
