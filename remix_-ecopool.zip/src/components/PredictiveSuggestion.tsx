import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ArrowRight, X } from 'lucide-react';
import { PredictionService, PredictiveHint } from '../services/predictionService';

interface PredictiveSuggestionProps {
  userId: string | null;
  language: string;
  onApply: (hint: PredictiveHint) => void;
}

export const PredictiveSuggestion: React.FC<PredictiveSuggestionProps> = ({ userId, language, onApply }) => {
  const [hint, setHint] = React.useState<PredictiveHint | null>(null);
  const [isVisible, setIsVisible] = React.useState(true);

  React.useEffect(() => {
    if (!userId) return;

    const fetchHint = async () => {
      const bookings = await PredictionService.getRecentBookings(userId);
      const prediction = PredictionService.analyzePatterns(bookings, language);
      setHint(prediction);
    };

    fetchHint();
  }, [userId, language]);

  if (!hint || !isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-gradient-to-r from-blue-600 via-indigo-600 to-primary p-[1px] rounded-2xl shadow-lg shadow-blue-100 group"
      >
        <div className="bg-white rounded-[15px] p-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-blue-50 p-2.5 rounded-xl text-blue-600 group-hover:scale-110 transition-transform">
              <Sparkles size={20} className="animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest bg-blue-50 px-2 py-0.5 rounded-full">
                  {language === 'hi' ? 'स्मार्ट सुझाव' : 'Smart Suggestion'}
                </span>
                <span className="text-[10px] font-bold text-slate-400">
                  {hint.frequency} {language === 'hi' ? 'पिछली यात्राएं' : 'past trips'}
                </span>
              </div>
              <h4 className="text-sm font-bold text-slate-800 mt-1">
                {hint.label}
              </h4>
              <div className="flex items-center gap-2 mt-1 text-[11px] font-medium text-slate-500">
                <span>{hint.from}</span>
                <ArrowRight size={10} className="text-slate-300" />
                <span>{hint.to}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3 w-full md:w-auto">
            <button
              onClick={() => onApply(hint)}
              className="flex-1 md:flex-none px-6 py-2 bg-primary hover:bg-primary-dark text-white rounded-xl font-bold text-xs transition-all shadow-md shadow-blue-100 active:scale-95"
            >
              {language === 'hi' ? 'अभी भरें' : 'Book Now'}
            </button>
            <button
              onClick={() => setIsVisible(false)}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-colors"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
