import React from 'react';
import { motion } from 'motion/react';
import { AlertTriangle, CheckCircle2, Info, AlertCircle } from 'lucide-react';
import { UncertaintyInsight } from '../services/uncertaintyService';

interface UncertaintyIndicatorProps {
  insight: UncertaintyInsight;
  compact?: boolean;
  language: string;
}

export const UncertaintyIndicator: React.FC<UncertaintyIndicatorProps> = ({ insight, compact, language }) => {
  const isHindi = language === 'hi';

  const configs = {
    stable: {
      icon: <CheckCircle2 size={compact ? 10 : 14} />,
      color: 'text-emerald-600',
      bg: 'bg-emerald-50',
      border: 'border-emerald-100',
      dot: 'bg-emerald-500'
    },
    moderate: {
      icon: <AlertCircle size={compact ? 10 : 14} />,
      color: 'text-amber-600',
      bg: 'bg-amber-50',
      border: 'border-amber-100',
      dot: 'bg-amber-500'
    },
    uncertain: {
      icon: <AlertTriangle size={compact ? 10 : 14} />,
      color: 'text-rose-600',
      bg: 'bg-rose-50',
      border: 'border-rose-100',
      dot: 'bg-rose-500'
    }
  };

  const config = configs[insight.level];

  if (compact) {
    return (
      <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full border ${config.bg} ${config.border} ${config.color}`}>
        <div className={`w-1.5 h-1.5 rounded-full ${config.dot} animate-pulse`} />
        <span className="text-[9px] font-black uppercase tracking-tight">{insight.label}</span>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      className={`p-4 rounded-3xl border-2 ${config.bg} ${config.border} space-y-3`}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={`p-1.5 rounded-xl bg-white shadow-sm ${config.color}`}>
            {config.icon}
          </div>
          <div>
            <h5 className={`text-xs font-black uppercase tracking-widest ${config.color}`}>
              {insight.label}
            </h5>
            <div className="text-[9px] font-bold text-slate-400">
              {isHindi ? 'अनिश्चितता सूचकांक' : 'Uncertainty Index'}: {insight.score}%
            </div>
          </div>
        </div>
        
        <div className="flex gap-0.5">
          {[1, 2, 3, 4, 5].map((step) => {
            const threshold = step * 20;
            const isActive = insight.score >= threshold;
            return (
              <div 
                key={step}
                className={`w-4 h-1 rounded-full transition-all ${isActive ? config.dot : 'bg-slate-200'}`}
              />
            );
          })}
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {insight.factors.map((factor, i) => (
          <div key={i} className="flex items-center gap-1 text-[9px] font-bold text-slate-500 bg-white/50 px-2 py-1 rounded-lg">
            <Info size={10} className="opacity-50" />
            {factor}
          </div>
        ))}
      </div>

      <p className="text-[10px] font-medium text-slate-500 leading-tight italic">
        {insight.level === 'stable' 
          ? (isHindi ? 'यह सवारी समय पर और सुरक्षित होने की अत्यधिक संभावना है।' : 'Highly likely to be on time and reliable.')
          : insight.level === 'moderate'
          ? (isHindi ? 'कुछ देरी या तकनीकी बदलावों की संभावना हो सकती है।' : 'Potential for slight delays or minor changes.')
          : (isHindi ? 'उच्च यातायात या रद्दीकरण जोखिम। बैकअप योजना तैयार रखें।' : 'High traffic or cancellation risk. Have a backup plan.')}
      </p>
    </motion.div>
  );
};
