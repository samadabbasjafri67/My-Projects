import React from 'react';
import { TRANSLATIONS, AMENITIES } from '../constants';
import { User, Ride } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import { db, collection, addDoc, doc, getDoc, query, where, getDocs, updateDoc } from '../firebase';

interface OfferSectionProps {
  currentUser: string | null;
  user: User | null;
  showNotification: (msg: string, color?: string) => void;
  language: string;
}

export const OfferSection: React.FC<OfferSectionProps> = ({ currentUser, user, showNotification, language }) => {
  const [from, setFrom] = React.useState("");
  const [to, setTo] = React.useState("");
  const [date, setDate] = React.useState("");
  const [time, setTime] = React.useState("");
  const [price, setPrice] = React.useState("");
  const [seats, setSeats] = React.useState("");
  const [isRecurring, setIsRecurring] = React.useState(false);
  const [recurringDays, setRecurringDays] = React.useState<string[]>([]);
  const [useDynamicPricing, setUseDynamicPricing] = React.useState(true);
  const [amenities, setAmenities] = React.useState<string[]>([]);
  const [isWomenOnly, setIsWomenOnly] = React.useState(false);
  const [isEV, setIsEV] = React.useState(false);
  const [batteryRange, setBatteryRange] = React.useState("");
  const [waypoints, setWaypoints] = React.useState<string[]>([]);
  const [optimizationTags, setOptimizationTags] = React.useState<string[]>(['fastest']);
  const [isVerified, setIsVerified] = React.useState(user?.isVerified || false);
  const [userSubscription, setUserSubscription] = React.useState<any>(user?.subscription || { plan: 'free' });
  const [userData, setUserData] = React.useState<User | null>(user);
  const [creatingRide, setCreatingRide] = React.useState(false);
  const [tripType, setTripType] = React.useState<'ride' | 'parcel'>('ride');
  const [vehiclePoolType, setVehiclePoolType] = React.useState<'car' | 'bike' | 'ev'>('car');
  const [helmetAvailable, setHelmetAvailable] = React.useState(true);
  const [luggageCapacity, setLuggageCapacity] = React.useState<'none' | 'small' | 'medium' | 'large'>('small');
  const [maxWeight, setMaxWeight] = React.useState("5");
  const [maxSize, setMaxSize] = React.useState<'small' | 'medium' | 'large'>('small');
  const [parcelDescription, setParcelDescription] = React.useState("");

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  React.useEffect(() => {
    if (user) {
      setUserData(user);
      setIsVerified(user.isVerified || false);
      setUserSubscription(user.subscription || { plan: 'free' });
    }
  }, [user]);

  const toggleAmenity = (value: string) => {
    setAmenities(prev =>
      prev.includes(value) ? prev.filter(a => a !== value) : [...prev, value]
    );
  };

  const addWaypoint = () => {
    if (waypoints.length < 3) {
      setWaypoints([...waypoints, ""]);
    } else {
      showNotification(language === 'hi' ? "अधिकतम 3 स्टॉप जोड़े जा सकते हैं" : "Maximum 3 stops can be added", "#ffa000");
    }
  };

  const removeWaypoint = (index: number) => {
    setWaypoints(waypoints.filter((_, i) => i !== index));
  };

  const updateWaypoint = (index: number, val: string) => {
    const newWaypoints = [...waypoints];
    newWaypoints[index] = val;
    setWaypoints(newWaypoints);
  };

  const toggleTag = (tag: string) => {
    setOptimizationTags(prev => 
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  };

  const toggleRecurringDay = (day: string) => {
    setRecurringDays(prev =>
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
    );
  };

  const calculateDynamicPrice = (basePrice: number) => {
    const now = new Date();
    const hour = now.getHours();
    const dayOfWeek = now.getDay();
    let priceMultiplier = 1.0;

    if ((hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19)) priceMultiplier *= 1.3;
    if (dayOfWeek === 0 || dayOfWeek === 6) priceMultiplier *= 1.2;
    
    if (isEV) priceMultiplier *= 0.95;

    return {
      finalPrice: Math.round(basePrice * priceMultiplier),
      basePrice,
      peakSurcharge: (hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19),
      weekendSurcharge: dayOfWeek === 0 || dayOfWeek === 6,
      evDiscount: isEV ? 0.95 : 1
    };
  };

  const createRide = async () => {
    if (!from || !to || !date || !time || !price || !seats) {
      showNotification("Please fill all required details!", "#e53935");
      return;
    }

    if (!currentUser) return;

    // Phone number check
    if (!userData?.phone) {
      showNotification(language === 'hi' ? "कृपया सवारी पेश करने से पहले अपनी प्रोफ़ाइल में अपना फ़ोन नंबर जोड़ें!" : "Please add your phone number in your profile before offering a ride!", "#e53935");
      return;
    }

    // Subscription check
    if (userSubscription?.plan === 'free') {
      setCreatingRide(true);
      try {
        const q = query(collection(db, 'rides'), where('driver', '==', currentUser));
        const snapshot = await getDocs(q);
        const userRidesThisMonth = snapshot.docs.filter(doc => {
          const data = doc.data();
          return new Date(data.date).getMonth() === new Date().getMonth();
        }).length;
        
        if (userRidesThisMonth >= 5) {
          showNotification("Free plan limit reached! Upgrade to offer more rides.", "#e53935");
          setCreatingRide(false);
          return;
        }
      } catch (error) {
        setCreatingRide(false);
        return;
      }
    }

    setCreatingRide(true);

    let finalPrice = parseFloat(price);
    let pricingDetails = null;
    if (useDynamicPricing) {
      pricingDetails = calculateDynamicPrice(finalPrice);
      finalPrice = pricingDetails.finalPrice;
    }

    let fromCoords = null;
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(from)}`);
      const data = await response.json();
      if (data && data.length > 0) {
        fromCoords = { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
      }
    } catch (err) {
      console.error("Geocoding from address failed:", err);
    }

    const baseRideData = {
      driver: currentUser,
      driverName: userData?.username || 'User',
      driverPhoto: userData?.profilePhoto || null,
      from,
      fromCoords,
      to,
      time,
      price: finalPrice,
      seats: parseInt(seats),
      bookings: [],
      type: tripType,
      vehiclePoolType: vehiclePoolType,
      helmetAvailable: vehiclePoolType === 'bike' ? helmetAvailable : false,
      luggageCapacity: luggageCapacity,
      waypoints: waypoints.filter(w => w.trim() !== "").map(w => ({ address: w })),
      optimizationTags,
      parcelDetails: tripType === 'parcel' ? {
        maxWeight: parseFloat(maxWeight),
        maxSize,
        description: parcelDescription
      } : null,
      dynamicPricing: pricingDetails,
      amenities: amenities,
      isWomenOnly: isWomenOnly,
      womenOnly: isWomenOnly,
      isEV: isEV,
      batteryRange: isEV ? batteryRange : null,
      createdAt: new Date().toISOString(),
      driverVerified: isVerified,
      driverPhone: userData?.phone || null,
      driverEmail: userData?.email || null,
      carName: userData?.carName || null,
      carType: userData?.carType || null,
      carImage: userData?.carImage || null,
      status: 'active'
    };

    try {
      if (isRecurring && recurringDays.length > 0) {
        for (const day of recurringDays) {
          const rideDate = new Date(date);
          while (rideDate.getDay() !== parseInt(day)) {
            rideDate.setDate(rideDate.getDate() + 1);
          }
          await addDoc(collection(db, 'rides'), {
            ...baseRideData,
            date: rideDate.toISOString().split('T')[0],
            isRecurring: true,
            recurringPattern: recurringDays,
          });
        }
        showNotification(`${recurringDays.length} recurring rides created successfully!`);
      } else {
        await addDoc(collection(db, 'rides'), {
          ...baseRideData,
          date,
          isRecurring: false,
        });
        showNotification("Ride created successfully!");
      }

      // Update user stats and role
      if (userData) {
        await updateDoc(doc(db, 'users', currentUser), {
          totalRides: (userData.totalRides || 0) + 1,
          points: (userData.points || 0) + 10,
          role: 'driver'
        });
      }

      // Reset form
      setFrom(""); setTo(""); setDate(""); setTime(""); setPrice(""); setSeats("");
      setIsRecurring(false); setRecurringDays([]); setAmenities([]);
      setIsWomenOnly(false); setIsEV(false); setBatteryRange("");
      setWaypoints([]); setOptimizationTags(['fastest']);
    } catch (error) {
      showNotification("Failed to create ride!", "#e53935");
    } finally {
      setCreatingRide(false);
    }
  };

  if (!isVerified) {
    return (
      <div className="verification-section p-6 text-center">
        <h3 className="text-xl font-bold mb-2">{t.verificationRequired}</h3>
        <p className="mb-4">{t.verificationDesc}</p>
        <button onClick={() => window.location.reload()}>{t.completeVerification}</button>
      </div>
    );
  }

  return (
    <div id="offerSection">
      <h2 className="text-xl font-bold mb-4">{t.offerRide}</h2>

      <div className="flex gap-2 mb-6 bg-slate-100 p-1 rounded-xl">
        <button 
          onClick={() => setTripType('ride')}
          className={`flex-1 py-2 rounded-lg text-xs font-black transition-all ${tripType === 'ride' ? 'bg-white text-primary shadow-sm' : 'text-slate-500'}`}
        >
          🚗 {t.passengerRide}
        </button>
        <button 
          onClick={() => setTripType('parcel')}
          className={`flex-1 py-2 rounded-lg text-xs font-black transition-all ${tripType === 'parcel' ? 'bg-white text-primary shadow-sm' : 'text-slate-500'}`}
        >
          📦 {t.deliveryService}
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
        <input type="text" placeholder={t.from} value={from} onChange={(e) => setFrom(e.target.value)} />
        <input type="text" placeholder={t.to} value={to} onChange={(e) => setTo(e.target.value)} />
        
        {waypoints.map((wp, idx) => (
          <div key={idx} className="col-span-full flex gap-2">
            <div className="w-8 h-10 flex flex-col items-center justify-center shrink-0">
               <div className="w-1.5 h-1.5 rounded-full bg-slate-300"></div>
            </div>
            <input 
              type="text" 
              placeholder={`${language === 'hi' ? 'स्टॉप' : 'Stop'} ${idx + 1}`} 
              value={wp} 
              onChange={(e) => updateWaypoint(idx, e.target.value)}
              className="flex-1"
            />
            <button 
              onClick={() => removeWaypoint(idx)}
              className="px-3 text-red-500 hover:bg-red-50 rounded-xl"
            >
              ×
            </button>
          </div>
        ))}

        {tripType === 'ride' && waypoints.length < 3 && (
          <button 
            onClick={addWaypoint}
            className="col-span-full py-2 border-2 border-dashed border-slate-200 rounded-xl text-[10px] font-black text-slate-400 uppercase tracking-widest hover:border-primary hover:text-primary transition-all flex items-center justify-center gap-2"
          >
            ➕ {language === 'hi' ? 'स्टॉप जोड़ें' : 'Add Stop'}
          </button>
        )}

        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        <input type="time" value={time} onChange={(e) => setTime(e.target.value)} />
        <input type="number" placeholder={t.price} value={price} onChange={(e) => setPrice(e.target.value)} />
        <input 
          type="number" 
          placeholder={t.seats} 
          value={vehiclePoolType === 'bike' ? "1" : seats} 
          onChange={(e) => setSeats(vehiclePoolType === 'bike' ? "1" : e.target.value)} 
          disabled={vehiclePoolType === 'bike'}
          className={vehiclePoolType === 'bike' ? "bg-slate-50 text-slate-400 cursor-not-allowed select-none" : ""}
          title={vehiclePoolType === 'bike' ? "Bike pool allows maximum 1 passenger" : undefined}
        />
      </div>

      {tripType === 'ride' && (
        <div className="mb-4 space-y-1">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">
            🛵 {language === 'hi' ? 'वाहन प्रकार देखें' : 'Vehicle / Pool Type'}
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'car', label: language === 'hi' ? 'कार पूल' : 'Car Pool', icon: '🚗' },
              { id: 'bike', label: language === 'hi' ? 'बाइक पूल ⭐' : 'Bike Pool ⭐', icon: '🏍️' },
              { id: 'ev', label: language === 'hi' ? 'ईवी पूल' : 'EV Pool', icon: '⚡' }
            ].map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => {
                  setVehiclePoolType(opt.id as any);
                  if (opt.id === 'bike') {
                    setSeats("1");
                    setIsEV(false);
                    // Set helmet default
                    setHelmetAvailable(true);
                  } else if (opt.id === 'ev') {
                    setIsEV(true);
                  } else {
                    setIsEV(false);
                  }
                }}
                className={`py-2 px-1 rounded-lg text-xs font-bold border transition-all flex flex-col items-center justify-center gap-1 ${vehiclePoolType === opt.id ? 'bg-primary/5 border-primary text-primary shadow-sm' : 'bg-white border-slate-100 text-slate-500 hover:border-slate-200'}`}
              >
                <span className="text-lg">{opt.icon}</span>
                <span>{opt.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {tripType === 'ride' && vehiclePoolType === 'bike' && (
        <label className="flex items-start gap-3 bg-amber-50 p-3 rounded-xl border border-amber-100 mb-4 cursor-pointer animate-fade-in">
          <input 
            type="checkbox" 
            checked={helmetAvailable} 
            onChange={(e) => setHelmetAvailable(e.target.checked)} 
            className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 mt-0.5"
          />
          <div className="flex flex-col">
            <span className="text-xs font-bold text-amber-950">🪖 {language === 'hi' ? 'हेलमेट प्रदान करें (Helmet Available)' : 'Provide Passenger Helmet'}</span>
            <span className="text-[10px] text-amber-700">{language === 'hi' ? 'मेरे पास यात्री की सुरक्षा के लिए एक अतिरिक्त हेलमेट उपलब्ध है।' : 'I will carry an extra helmet for the passenger\'s safety'}</span>
          </div>
        </label>
      )}

      {tripType === 'ride' && (
        <div className="mb-4 space-y-1">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">
            🧳 {t.luggageCapacity}
          </label>
          <div className="grid grid-cols-4 gap-2">
            {[
              { id: 'none', label: t.none },
              { id: 'small', label: t.smallLuggage },
              { id: 'medium', label: t.mediumLuggage },
              { id: 'large', label: t.largeLuggage }
            ].map((opt) => (
              <button
                key={opt.id}
                onClick={() => setLuggageCapacity(opt.id as any)}
                className={`py-2 px-1 rounded-lg text-[10px] font-bold border transition-all ${luggageCapacity === opt.id ? 'bg-primary/5 border-primary text-primary' : 'bg-white border-slate-100 text-slate-500 hover:border-slate-200'}`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {tripType === 'parcel' && (
        <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl mb-4">
          <h4 className="text-xs font-black text-blue-800 uppercase tracking-widest mb-3 flex items-center gap-2">
            <span className="p-1 bg-blue-100 rounded-md">📦</span>
            {t.parcelDetails}
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-blue-600 block px-1">{t.maxWeight}</label>
              <input 
                type="number" 
                value={maxWeight} 
                onChange={(e) => setMaxWeight(e.target.value)}
                className="w-full bg-white border-blue-100"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-blue-600 block px-1">{t.maxSize}</label>
              <select 
                value={maxSize} 
                onChange={(e) => setMaxSize(e.target.value as any)}
                className="w-full bg-white border-blue-100"
              >
                <option value="small">{t.small}</option>
                <option value="medium">{t.medium}</option>
                <option value="large">{t.large}</option>
              </select>
            </div>
          </div>
          <div className="mt-3 space-y-1">
            <label className="text-[10px] font-bold text-blue-600 block px-1">{t.parcelDesc} ({language === 'hi' ? 'वैकल्पिक' : 'Optional'})</label>
            <input 
              type="text" 
              placeholder={language === 'hi' ? 'उदा. छोटा बॉक्स, लिफाफा...' : 'e.g. Small box, envelope...'}
              value={parcelDescription}
              onChange={(e) => setParcelDescription(e.target.value)}
              className="w-full bg-white border-blue-100"
            />
          </div>
        </div>
      )}

      <div className="women-only-checkbox p-4 bg-pink-50 border border-pink-200 rounded-lg mb-4 flex items-center gap-3">
        <input
          type="checkbox"
          id="womenOnly"
          checked={isWomenOnly}
          onChange={(e) => setIsWomenOnly(e.target.checked)}
          className="w-5 h-5"
        />
        <label htmlFor="womenOnly" className="flex items-center gap-2 cursor-pointer font-semibold text-pink-700">
          <span>👩‍💼 {t.womenOnly} - {t.womenOnlyDesc}</span>
        </label>
      </div>

      <div className="p-4 bg-green-50 border border-green-200 rounded-lg mb-4">
        <label className="flex items-center gap-2 cursor-pointer font-semibold text-green-700">
          <input type="checkbox" checked={isEV} onChange={(e) => setIsEV(e.target.checked)} className="w-5 h-5" />
          <span>⚡ {t.isEV}</span>
        </label>
        {isEV && (
          <div className="mt-3">
            <input
              type="number"
              placeholder={t.batteryRange}
              value={batteryRange}
              onChange={(e) => setBatteryRange(e.target.value)}
              className="mb-2"
            />
            <div className="flex flex-wrap gap-2">
              <span className="carbon-badge text-xs">🌱 {language === 'hi' ? '5% छूट लागू' : '5% discount applied'}</span>
              <span className="carbon-badge text-xs">🍃 {language === 'hi' ? 'शून्य उत्सर्जन' : 'Zero emissions'}</span>
            </div>
          </div>
        )}
      </div>

      <div className="form-section p-4 bg-gray-50 rounded-lg mb-4">
        <h4 className="font-bold mb-3">{t.amenities}</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {AMENITIES.map(amenity => (
            <label key={amenity.value} className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={amenities.includes(amenity.value)}
                onChange={() => toggleAmenity(amenity.value)}
              />
              <span>{language === 'hi' ? (
                amenity.value === 'ac' ? 'एसी' :
                amenity.value === 'music' ? 'संगीत' :
                amenity.value === 'wifi' ? 'वाईफाई' :
                amenity.value === 'charging' ? 'चार्जिंग' :
                amenity.value === 'luggage' ? 'सामान' :
                amenity.value === 'pets' ? 'पालतू जानवर' :
                amenity.label
              ) : amenity.label}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="p-4 bg-blue-50 rounded-lg mb-4">
        <label className="flex items-center gap-2 cursor-pointer font-semibold">
          <input type="checkbox" checked={useDynamicPricing} onChange={(e) => setUseDynamicPricing(e.target.checked)} />
          <span>{t.dynamicPricing}</span>
        </label>
        {useDynamicPricing && price && (
          <div className="mt-3 text-sm border-t border-blue-100 pt-2">
            <p className="font-bold mb-1">{t.dynamicPricingPreview}</p>
            {(() => {
              const pricing = calculateDynamicPrice(parseFloat(price));
              return (
                <div className="grid grid-cols-2 gap-x-4">
                  <span>{language === 'hi' ? 'आधार मूल्य:' : 'Base Price:'}</span> <span className="font-bold">₹{pricing.basePrice}</span>
                  <span>{language === 'hi' ? 'अंतिम मूल्य:' : 'Final Price:'}</span> <span className="font-bold text-blue-700">₹{pricing.finalPrice}</span>
                  {pricing.peakSurcharge && <span className="text-orange-600 text-xs col-span-2">{t.peakSurcharge}</span>}
                  {pricing.weekendSurcharge && <span className="text-orange-600 text-xs col-span-2">{t.weekendSurcharge}</span>}
                  {isEV && <span className="text-green-600 text-xs col-span-2">{t.evDiscount}</span>}
                </div>
              );
            })()}
          </div>
        )}
      </div>

      <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl mb-4">
        <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-3">
          🛣️ {language === 'hi' ? 'स्मार्ट रूट विकल्प' : 'Smart Route Options'}
        </h4>
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'fastest', icon: '⚡', label: language === 'hi' ? 'सबसे तेज़' : 'Fastest' },
            { id: 'cheapest', icon: '💰', label: language === 'hi' ? 'सस्ता' : 'Cheapest' },
            { id: 'eco', icon: '🌱', label: language === 'hi' ? 'पारिस्थितिकी' : 'Eco' }
          ].map((tag) => (
            <button
              key={tag.id}
              onClick={() => toggleTag(tag.id)}
              className={`py-2 px-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 border transition-all ${optimizationTags.includes(tag.id) ? 'bg-primary/10 border-primary text-primary shadow-sm' : 'bg-white border-slate-100 text-slate-400 opacity-60'}`}
            >
              <span>{tag.icon}</span>
              {tag.label}
            </button>
          ))}
        </div>
      </div>

      <div className="p-4 bg-indigo-50 rounded-lg mb-6">
        <label className="flex items-center gap-2 cursor-pointer font-semibold">
          <input type="checkbox" checked={isRecurring} onChange={(e) => setIsRecurring(e.target.checked)} />
          <span>{t.recurringRide}</span>
        </label>
        {isRecurring && (
          <div className="mt-3">
            <p className="text-sm mb-2">{t.selectDays}</p>
            <div className="flex flex-wrap gap-2">
              {[
                { v: '0', l: language === 'hi' ? 'रवि' : 'Sun' }, { v: '1', l: language === 'hi' ? 'सोम' : 'Mon' }, { v: '2', l: language === 'hi' ? 'मंगल' : 'Tue' },
                { v: '3', l: language === 'hi' ? 'बुध' : 'Wed' }, { v: '4', l: language === 'hi' ? 'गुरु' : 'Thu' }, { v: '5', l: language === 'hi' ? 'शुक्र' : 'Fri' }, { v: '6', l: language === 'hi' ? 'शनि' : 'Sat' }
              ].map(day => (
                <button
                  key={day.v}
                  type="button"
                  className={`text-xs py-1 px-3 ${recurringDays.includes(day.v) ? 'success-btn' : 'secondary-btn'}`}
                  onClick={() => toggleRecurringDay(day.v)}
                >
                  {day.l}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <button 
        onClick={createRide} 
        disabled={creatingRide}
        className={`w-full py-3 text-lg font-bold flex items-center justify-center gap-2 ${creatingRide ? 'bg-blue-400 cursor-not-allowed' : ''}`}
      >
        {creatingRide && <LoadingSpinner size="sm" color="white" />}
        {creatingRide ? (language === 'hi' ? 'सवारी बनाई जा रही है...' : 'Creating Ride...') : t.createRide}
      </button>
    </div>
  );
};
