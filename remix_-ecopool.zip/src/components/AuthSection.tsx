import React from 'react';
import { motion } from 'motion/react';
import { TRANSLATIONS } from '../constants';
import { LoadingSpinner } from './LoadingSpinner';
import { Car, ShieldCheck, Leaf, IndianRupee } from 'lucide-react';

interface AuthSectionProps {
  onLogin: () => Promise<boolean>;
  language: string;
}

export const AuthSection: React.FC<AuthSectionProps> = ({ onLogin, language }) => {
  const [isLoggingIn, setIsLoggingIn] = React.useState(false);
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const handleLogin = async () => {
    setIsLoggingIn(true);
    try {
      await onLogin();
    } finally {
      setIsLoggingIn(false);
    }
  };

  const features = [
    { icon: Leaf, color: 'text-emerald-600', bg: 'bg-emerald-50', label: language === 'hi' ? 'अपना कार्बन पदचिह्न कम करें' : 'Reduce your carbon footprint' },
    { icon: IndianRupee, color: 'text-blue-600', bg: 'bg-blue-50', label: language === 'hi' ? 'यात्रा लागत पर बचत करें' : 'Save on travel costs' },
    { icon: ShieldCheck, color: 'text-indigo-600', bg: 'bg-indigo-50', label: language === 'hi' ? 'सत्यापित समुदाय के सदस्य' : 'Verified community members' },
    { icon: Car, color: 'text-amber-600', bg: 'bg-amber-50', label: language === 'hi' ? 'रीयल-टाइम राइड ट्रैकिंग' : 'Real-time ride tracking' },
  ];

  return (
    <div id="authSection" className="flex flex-col items-center justify-center min-h-[80vh] py-12 px-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-4xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
      >
        <div className="space-y-8">
          <div className="space-y-4">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border border-emerald-100"
            >
              <Leaf size={14} />
              {language === 'hi' ? 'पर्यावरण के अनुकूल यात्रा' : 'Eco-Friendly Commute'}
            </motion.div>
            <h2 className="text-5xl font-black text-slate-900 tracking-tight leading-tight">
              {t.welcome}
            </h2>
            <p className="text-xl text-slate-500 font-medium leading-relaxed">
              {t.welcomeSubtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {features.map((feature, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className="flex items-start gap-3 p-4 rounded-2xl bg-white border border-slate-100 shadow-sm"
              >
                <div className={`${feature.bg} ${feature.color} p-2 rounded-xl`}>
                  <feature.icon size={20} />
                </div>
                <span className="text-sm font-bold text-slate-700 leading-tight">{feature.label}</span>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="flex flex-col items-center justify-center space-y-8 bg-slate-50 p-12 rounded-[2.5rem] border border-slate-200">
          <div className="bg-white p-4 rounded-3xl shadow-xl shadow-slate-200/50 mb-4">
            <div className="bg-primary p-4 rounded-2xl text-white">
              <Car size={48} />
            </div>
          </div>
          
          <div className="text-center space-y-2">
            <h3 className="text-2xl font-black text-slate-900">{language === 'hi' ? 'शुरू करने के लिए तैयार?' : 'Ready to start?'}</h3>
            <p className="text-slate-500 font-medium">{language === 'hi' ? 'आज ही इकोपूल समुदाय में शामिल हों' : 'Join the EcoPool community today'}</p>
          </div>

          <button 
            onClick={handleLogin} 
            disabled={isLoggingIn}
            className={`w-full flex items-center justify-center gap-3 bg-white border border-slate-200 px-8 py-4 rounded-2xl shadow-sm hover:shadow-md hover:border-slate-300 transition-all text-slate-700 font-bold text-lg ${isLoggingIn ? 'opacity-70 cursor-not-allowed' : ''}`}
          >
            {isLoggingIn ? (
              <LoadingSpinner />
            ) : (
              <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-6 h-6" />
            )}
            {isLoggingIn ? (language === 'hi' ? 'लॉग इन किया जा रहा है...' : 'Logging in...') : t.loginWithGoogle}
          </button>

          <p className="text-xs text-slate-400 text-center max-w-[240px]">
            {language === 'hi' ? 'लॉग इन करके, आप हमारी सेवा की शर्तों और गोपनीयता नीति से सहमत होते हैं।' : 'By logging in, you agree to our Terms of Service and Privacy Policy.'}
          </p>
        </div>
      </motion.div>
    </div>
  );
};
