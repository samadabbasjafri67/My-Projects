import React from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { User } from '../types';
import { TRANSLATIONS } from '../constants';
import { LoadingSpinner } from './LoadingSpinner';
import { Car } from 'lucide-react';

interface NearbyDriversMapProps {
  drivers: User[];
  language: string;
}

// Fix Leaflet default icon issue with Vite
if (typeof window !== 'undefined') {
  delete (L.Icon.Default.prototype as any)._getIconUrl;
  L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
    iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  });
}

export const NearbyDriversMap: React.FC<NearbyDriversMapProps> = ({ drivers, language }) => {
  const mapContainerRef = React.useRef<HTMLDivElement>(null);
  const mapRef = React.useRef<L.Map | null>(null);
  const markersRef = React.useRef<{ [key: string]: L.Marker }>({});
  const [userLocation, setUserLocation] = React.useState<[number, number] | null>(null);
  
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  // Get User Location
  React.useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation([position.coords.latitude, position.coords.longitude]);
      },
      (err) => {
        console.error("Error getting user location", err);
        // Default to New Delhi if location denied
        setUserLocation([28.6139, 77.2090]);
      }
    );
  }, []);

  // Initialize Map
  React.useEffect(() => {
    if (!mapContainerRef.current || !userLocation) return;

    if (!mapRef.current) {
      mapRef.current = L.map(mapContainerRef.current, { zoomControl: false }).setView(userLocation, 12);
      L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO'
      }).addTo(mapRef.current);
      L.control.zoom({ position: 'topright' }).addTo(mapRef.current);

      // Add user marker
      const userIcon = L.divIcon({
        className: 'user-marker',
        html: `<div style="background-color: #2563eb; width: 12px; height: 12px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 10px rgba(37, 99, 235, 0.5);"></div>`,
        iconSize: [12, 12],
        iconAnchor: [6, 6]
      });
      L.marker(userLocation, { icon: userIcon }).addTo(mapRef.current).bindPopup(language === 'hi' ? "आप यहाँ हैं" : "You are here");
    } else {
        mapRef.current.setView(userLocation);
    }
  }, [userLocation]);

  // Update Driver Markers
  React.useEffect(() => {
    if (!mapRef.current) return;

    const map = mapRef.current;
    const currentDriverIds = new Set(drivers.map(d => d.username)); // Using username as ID for simplicity if UID not in object

    // Remove stale markers
    Object.keys(markersRef.current).forEach(id => {
      if (!currentDriverIds.has(id)) {
        map.removeLayer(markersRef.current[id]);
        delete markersRef.current[id];
      }
    });

    // Add or update markers
    drivers.forEach(driver => {
      if (!driver.currentLocation) return;
      const pos: [number, number] = [driver.currentLocation.lat, driver.currentLocation.lng];
      const id = driver.username;

      if (!markersRef.current[id]) {
        const carIcon = L.divIcon({
          className: 'online-driver-marker',
          html: `<div style="background-color: #10b981; color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/></svg>
                 </div>`,
          iconSize: [28, 28],
          iconAnchor: [14, 14]
        });

        markersRef.current[id] = L.marker(pos, { icon: carIcon })
          .addTo(map)
          .bindPopup(`<b>${driver.username}</b><br/>${language === 'hi' ? 'सक्रिय' : 'Active Now'}`);
      } else {
        markersRef.current[id].setLatLng(pos);
      }
    });
  }, [drivers]);

  return (
    <div className="relative w-full h-48 rounded-2xl border border-slate-100 overflow-hidden shadow-sm bg-slate-50 mb-6">
      {!userLocation && (
        <div className="absolute inset-0 z-[1001] bg-white/60 backdrop-blur-sm flex items-center justify-center">
          <LoadingSpinner size="sm" />
        </div>
      )}
      <div ref={mapContainerRef} className="w-full h-full z-0"></div>
      
      <div className="absolute top-3 left-3 z-[1000]">
         <div className="bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-100 shadow-sm flex items-center gap-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
            <span className="text-[10px] font-black text-slate-700 uppercase tracking-widest">
              {drivers.length} {language === 'hi' ? 'सक्रिय चालक आस-पास' : 'Active Drivers Nearby'}
            </span>
         </div>
      </div>
    </div>
  );
};
