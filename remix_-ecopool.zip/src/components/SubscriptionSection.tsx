import React from 'react';
import { User } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import { db, doc, updateDoc } from '../firebase';
import { UPIPayment } from './UPIPayment';
import { 
  Sparkles, 
  ShieldCheck, 
  Compass, 
  Info, 
  CreditCard, 
  MapPin, 
  User as UserIcon, 
  Calendar, 
  Check, 
  ArrowRight, 
  Cpu, 
  UserCheck, 
  Flame, 
  AlertCircle 
} from 'lucide-react';

interface SubscriptionSectionProps {
  currentUser: string;
  user: User;
  showNotification: (msg: string, color?: string) => void;
  updateUserProfile: (data: any) => Promise<boolean>;
  language: string;
}

export const SubscriptionSection: React.FC<SubscriptionSectionProps> = ({ 
  currentUser, 
  user, 
  showNotification, 
  updateUserProfile, 
  language 
}) => {
  const [isSubscribing, setIsSubscribing] = React.useState<string | null>(null);
  const [activeTab, setActiveTab] = React.useState<'pass' | 'basic'>('pass');
  
  // Payment states
  const [showPaymentModal, setShowPaymentModal] = React.useState(false);
  const [paymentAmount, setPaymentAmount] = React.useState(0);
  const [paymentPlanId, setPaymentPlanId] = React.useState('');
  const [paymentCustomMetadata, setPaymentCustomMetadata] = React.useState<any>(null);
  
  // Custom Pass Builder State
  const [pickup, setPickup] = React.useState('Home');
  const [destination, setDestination] = React.useState('Office');
  const [commuteTime, setCommuteTime] = React.useState('09:00 AM');
  const [seatPreference, setSeatPreference] = React.useState<'front' | 'back_window' | 'back_middle'>('back_window');
  const [sameDriver, setSameDriver] = React.useState(true);
  const [reservedSeat, setReservedSeat] = React.useState(true);
  const [passPrice, setPassPrice] = React.useState(2500);

  // Recalculate estimated custom pass price based on options
  React.useEffect(() => {
    let base = 2000;
    if (sameDriver) base += 350;
    if (reservedSeat) base += 150;
    if (seatPreference === 'front') base += 100;
    setPassPrice(base);
  }, [sameDriver, reservedSeat, seatPreference]);

  // Standard commission plan list
  const standardPlans = [
    { 
      id: 'free', 
      name: language === 'hi' ? 'मुफ्त' : 'Free Tier', 
      price: 0, 
      features: language === 'hi' 
        ? ['बुनियादी सवारी खोज', 'प्रति माह 5 सवारी', '15% कमीशन'] 
        : ['Basic ride search', '5 rides per month', '15% commission'] 
    },
    { 
      id: 'basic', 
      name: language === 'hi' ? 'बुनियादी' : 'Basic Member', 
      price: 299, 
      features: language === 'hi' 
        ? ['उन्नत सवारी खोज', 'असीमित सवारी', '10% कमीशन', 'ईमेल सहायता'] 
        : ['Advanced ride search', 'Unlimited rides', '10% commission', 'Email support'] 
    },
    { 
      id: 'premium', 
      name: language === 'hi' ? 'प्रीमियम प्लस' : 'Premium Plus', 
      price: 599, 
      features: language === 'hi' 
        ? ['स्मार्ट एआई मैचिंग', 'शून्य कमीशन', 'प्राथमिकता सहायता', 'कॉर्पोरेट एक्सेस'] 
        : ['Smart AI matching', 'Zero commission', 'Priority support', 'Corporate access'] 
    }
  ];

  // Preset smart pass configurations representing personal transport memberships
  const presetPasses = [
    {
      id: 'preset_office',
      title: language === 'hi' ? 'दैनिक कार्यालय कम्यूटर' : 'Daily Office Commuter',
      route: language === 'hi' ? 'घर ↔ कार्यालय (नोएडा/गुड़गांव)' : 'Home ↔ Tech Park / Office',
      price: 2500,
      badge: language === 'hi' ? 'पसंदीदा' : 'Most Popular',
      description: language === 'hi' ? 'निश्चित मासिक मार्ग, सुरक्षित डेली सीट आरक्षण, सेम विश्वसनीय ड्राइवर विकल्प।' : 'Fixed monthly route, reserved seat everyday, option to match with the same verified driver.',
      color: 'from-blue-600 via-indigo-600 to-indigo-700',
      features: language === 'hi' 
        ? ['निश्चित मासिक मूल्य ₹2500', 'हर दिन रिजर्व सीट', 'उसी ड्राइवर की प्राथमिकता', 'लास्ट-माइल गारंटी']
        : ['Fixed ₹2500/mo pricing', 'Guaranteed reserved seat', 'Same high-rated driver option', 'First & Last-mile priority']
    },
    {
      id: 'preset_student',
      title: language === 'hi' ? 'अकादमिक कॉलेज पास' : 'Academic College Pass',
      route: language === 'hi' ? 'हॉस्टल ↔ कैंपस हब' : 'Hostel/Metro ↔ Campus Hub',
      price: 1800,
      badge: language === 'hi' ? 'छात्र विशेष' : 'Student Special',
      description: language === 'hi' ? 'छात्रों के लिए अनुकूलित कार्यक्रम, सुबह व शाम की समय पर पिक-अप व ड्रॉप।' : 'Tailored schedules for regular student times, priority female driver routing for women safety.',
      color: 'from-amber-500 via-orange-600 to-amber-700',
      features: language === 'hi' 
        ? ['विद्यार्थी रियायती दर ₹1800', 'सुरक्षित पिकअप समय-सारणी', 'महिला-सहयोगी राइडर्स', 'अभिभावक ट्रैकिंग लिंक']
        : ['Student-discount rate ₹1800', 'Fixed morning/evening schedule', 'Female-friendly ride pools', 'Parent live-tracking link']
    },
    {
      id: 'preset_metro',
      title: language === 'hi' ? 'मेट्रो लाइन कनेक्टर' : 'Metro Line Connector',
      route: language === 'hi' ? 'घर ↔ निकटतम मेट्रो' : 'Home ↔ Nearest Metro Station',
      price: 800,
      badge: language === 'hi' ? 'सस्ता और तेज' : 'Eco transit',
      description: language === 'hi' ? 'मेट्रो स्टेशनों तक सुगम यात्रा। कभी भी ऑटो कतारों में न खड़े हों।' : 'First-mile & last-mile metro station shuttle connection. Never wait in auto-rickshaw queues again.',
      color: 'from-emerald-600 via-teal-600 to-emerald-700',
      features: language === 'hi' 
        ? ['किफायती ₹800 प्रति माह', 'त्वरित 10 मिनट ट्रांसफर', 'प्रतिदिन सुबह और शाम की राइड', 'बारिश / मौसम सुरक्षा']
        : ['Affordable ₹800/mo flat', 'Quick 10-min transit window', 'Morning + Evening daily ride slots', 'Weather disruption guard']
    }
  ];

  const handleSubscribePlan = async (planId: string, customMetadata?: any) => {
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + 30);
    
    // Construct subscription object with advanced metadata
    const subscription = { 
      plan: planId, 
      expiry: expiry.toISOString(),
      ...(customMetadata || {})
    };
    
    setIsSubscribing(planId);
    try {
      const success = await updateUserProfile({ subscription });
      if (success) {
        showNotification(
          language === 'hi' 
            ? `बधाई हो! आपकी स्मार्ट पास ${planId.toUpperCase()} सदस्यता सक्रिय है!` 
            : `Success! Your Smart Commute Pass (${planId.toUpperCase()}) is now fully active!`
        );
      }
    } catch (error) {
      showNotification(language === 'hi' ? 'सदस्यता अद्यतन विफल!' : 'Subscription activation failed!', '#e53935');
    } finally {
      setIsSubscribing(null);
    }
  };

  const handleInitiatePlanPurchase = (planId: string, price: number, customMetadata?: any) => {
    if (price <= 0) {
      handleSubscribePlan(planId, customMetadata);
    } else {
      setPaymentPlanId(planId);
      setPaymentAmount(price);
      setPaymentCustomMetadata(customMetadata);
      setShowPaymentModal(true);
    }
  };

  const currentSubscription = user?.subscription || { plan: 'free' };
  const isSmartCommuteActive = currentSubscription?.plan?.startsWith('preset_') || currentSubscription?.plan === 'smart_custom';

  return (
    <div id="subscription-hub-root" className="max-w-6xl mx-auto px-4 py-8 space-y-10">
      
      {/* Title & Promotion Board */}
      <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white rounded-3xl p-6 md:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 opacity-10 -translate-x-10 translate-y-2 pointer-events-none select-none">
          <Sparkles size={280} className="text-amber-400 rotate-12" />
        </div>
        <div className="relative z-10 space-y-4 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/15 text-amber-300 text-[10px] font-black uppercase tracking-widest rounded-full border border-amber-400/25">
            <Sparkles size={12} className="animate-pulse" /> {language === 'hi' ? 'अप्रतिबंधित विशेष सदस्यता' : 'Elite Personal Transport Pass'}
          </span>
          <h1 className="text-3xl md:text-5xl font-black tracking-tight leading-none bg-gradient-to-r from-white via-indigo-100 to-amber-200 bg-clip-text text-transparent">
            {language === 'hi' ? 'स्मार्ट कम्यूट सदस्यता पास' : 'Smart Commute Subscription Pass ⭐'}
          </h1>
          <p className="text-slate-300 text-sm md:text-base font-semibold leading-relaxed">
            {language === 'hi'
              ? 'साधारण कूरियर की तरह बार-बार बुकिंग के बजाय पर्सनल ट्रांसपोर्ट परमानेंट कार्ड की तरह महसूस करें। निश्चित मार्ग, फिक्स्ड प्राइसिंग, और डेली रिजर्व्ड ड्राइविंग सीट।'
              : 'Upgrade to a personal transport membership. Instead of simple one-off bookings, secure a premium monthly contract with daily reserved seating, customized fixed route pricing, and identical driver matching.'}
          </p>
        </div>
      </div>

      {/* Mode / Feature Navigation Tabs */}
      <div className="flex border-b border-slate-200 gap-6">
        <button
          onClick={() => setActiveTab('pass')}
          className={`pb-3 text-sm font-black uppercase tracking-wider relative transition-all ${activeTab === 'pass' ? 'text-indigo-600 font-extrabold' : 'text-slate-400 hover:text-slate-600'}`}
        >
          🏷️ {language === 'hi' ? 'स्मार्ट कम्यूट पास (पसंदीदा)' : 'Smart Commute Pass ⭐'}
          {activeTab === 'pass' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-full" />}
        </button>
        <button
          onClick={() => setActiveTab('basic')}
          className={`pb-3 text-sm font-black uppercase tracking-wider relative transition-all ${activeTab === 'basic' ? 'text-indigo-600 font-extrabold' : 'text-slate-400 hover:text-slate-600'}`}
        >
          💎 {language === 'hi' ? 'मानक योजनाएं' : 'Standard Plans'}
          {activeTab === 'basic' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-full" />}
        </button>
      </div>

      {/* Screen 1: Active Subscription Overview */}
      {currentSubscription && currentSubscription?.plan !== 'free' && (
        <div className="bg-emerald-50/70 border border-emerald-100 p-6 rounded-3xl space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
                <h3 className="text-sm font-black text-emerald-800 uppercase tracking-widest">
                  {language === 'hi' ? 'आपकी वर्तमान सदस्यता पूरी तरह सक्रिय है' : 'Your Membership Status: Fully Active'}
                </h3>
              </div>
              <h2 className="text-2xl font-black text-slate-900 capitalize">
                {currentSubscription?.plan.replace('preset_', '').replace('_', ' ')} Smart Pass
              </h2>
              {currentSubscription?.expiry && (
                <p className="text-xs text-slate-500 font-extrabold">
                  🗓️ {language === 'hi' ? 'अगला ऑटो-नवीनीकरण तिथि:' : 'Next Automatic Renewal Date:'} <span className="text-indigo-600 font-black">{new Date(currentSubscription.expiry).toLocaleDateString()}</span>
                </p>
              )}
            </div>

            <button
              onClick={() => handleSubscribePlan('free')}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-black uppercase tracking-wider rounded-xl transition-all border border-slate-200"
            >
              Cancel Membership
            </button>
          </div>

          {/* Holographic Digital Pass Card Graphic */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 bg-white p-6 rounded-2xl border border-emerald-200/80 shadow-sm relative overflow-hidden">
            <div className="md:col-span-4 bg-gradient-to-tr from-slate-900 to-indigo-950 p-6 rounded-xl text-white flex flex-col justify-between space-y-8 relative overflow-hidden shadow-inner">
              <div className="absolute right-0 top-0 opacity-10 translate-x-4 -translate-y-4">
                <Cpu size={150} />
              </div>
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-black text-amber-400 tracking-widest">ECOPOOLPASS</span>
                  <div className="h-6 w-9 bg-amber-400/20 border border-amber-400/30 rounded-md flex items-center justify-center">
                    <div className="w-5 h-4 bg-amber-400/30 rounded" />
                  </div>
                </div>
                <span className="text-xs font-black px-2 py-0.5 bg-white/10 text-white rounded">NFC Enabled</span>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] text-slate-300 font-extrabold block">ROUTE PLAN DETAILS</span>
                <p className="text-sm font-black">
                  {currentSubscription?.customRoute?.from || 'Home'} ➔ {currentSubscription?.customRoute?.to || 'Office'}
                </p>
                <div className="flex justify-between text-[11px] text-slate-400 font-bold">
                  <span>HOLDER: {user?.username}</span>
                  <span>PREFER SAME DRIVER: {currentSubscription?.sameDriver ? 'YES' : 'NO'}</span>
                </div>
              </div>
            </div>

            {/* Smart Pass Active Features Dashboard */}
            <div className="md:col-span-8 grid grid-cols-2 gap-4 content-center">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Reserved Seating</span>
                <p className="text-xs font-bold text-slate-800">✓ Guaranteed Seat Everyday</p>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Consistent Driver Preference</span>
                <p className="text-xs font-bold text-slate-800">{currentSubscription?.sameDriver ? '✓ Same Top-Rated Driver' : '✓ Dynamic Match'}</p>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Pricing Standard</span>
                <p className="text-xs font-bold text-slate-800">✓ Locked In No Dynamic Surge</p>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Security Priority</span>
                <p className="text-xs font-bold text-emerald-700">✓ 24/7 Verified Emergency Support</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'pass' && (
        <div className="space-y-10">
          
          {/* Preset Cards Row */}
          <div>
            <div className="flex gap-2 items-center mb-6">
              <span className="bg-indigo-100 text-indigo-700 w-10 h-10 rounded-xl flex items-center justify-center font-black">
                ✨
              </span>
              <div>
                <h2 className="text-xl font-black text-slate-900">{language === 'hi' ? 'लोकप्रिय व्यक्तिगत मार्ग पास' : 'Ready-to-Commit Route Presets'}</h2>
                <p className="text-slate-500 text-xs font-black">{language === 'hi' ? 'तेजी से शामिल होने के लिए प्री-डिफाइंड मार्ग।' : 'Skip setup and commit to a certified high-demand route immediately'}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {presetPasses.map(pass => (
                <div 
                  key={pass.id} 
                  className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between relative overflow-hidden"
                >
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] font-black bg-blue-100 text-indigo-700 px-2.5 py-1 rounded-full uppercase tracking-wider">
                        {pass.badge}
                      </span>
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-slate-900">{pass.title}</h3>
                      <p className="text-xs font-semibold text-slate-500 mt-1">{pass.route}</p>
                    </div>

                    <div className="text-3xl font-black text-slate-900">
                      ₹{pass.price}<span className="text-sm font-semibold text-slate-400">/{language === 'hi' ? 'माह' : 'mo'}</span>
                    </div>

                    <p className="text-[11px] text-slate-600 font-bold leading-normal">
                      {pass.description}
                    </p>

                    <ul className="text-xs font-bold text-slate-700 space-y-2 pt-2">
                      {pass.features.map((feat, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <Check size={14} className="text-emerald-500" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mt-8">
                    <button
                      onClick={() => handleInitiatePlanPurchase(pass.id, pass.price, { 
                        customRoute: { from: pass.route.split('↔')[0].trim(), to: pass.route.split('↔')[1].trim() },
                        sameDriver: true,
                        price: pass.price
                      })}
                      disabled={isSubscribing !== null || currentSubscription?.plan === pass.id}
                      className={`w-full py-3 rounded-xl text-xs font-black uppercase tracking-wider text-white transition-all flex items-center justify-center gap-2 bg-gradient-to-r ${pass.color} shadow-md`}
                    >
                      {isSubscribing === pass.id ? (
                        <LoadingSpinner size="sm" color="white" />
                      ) : currentSubscription?.plan === pass.id ? (
                        language === 'hi' ? 'सक्रिय' : 'Active Pass'
                      ) : (
                        language === 'hi' ? 'पास खरीदें' : 'Buy Monthly Pass'
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Interactive Custom Pass Configurator Block */}
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-6 md:p-8 grid grid-cols-1 md:grid-cols-12 gap-8">
            <div className="md:col-span-7 space-y-6">
              <div className="space-y-1">
                <span className="text-xs font-black text-indigo-600 uppercase tracking-wider">🌿 Custom Plan Builder</span>
                <h3 className="text-2xl font-black text-slate-900">{language === 'hi' ? 'नया कस्टम पास कॉन्फ़िगर करें' : 'Tailor Your Own Personal Direct Pass'}</h3>
                <p className="text-slate-500 text-xs font-bold leading-relaxed">
                  Configure your exact pickup location, work address, specific timing, preferred seats, and driver options for a unique transport membership pass.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider px-1">📍 Home Address / Pickup</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3.5 text-slate-400" size={14} />
                    <input 
                      type="text" 
                      value={pickup}
                      onChange={(e) => setPickup(e.target.value)}
                      className="w-full pl-9 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider px-1">🏢 Destination / Work Site</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3.5 text-slate-400" size={14} />
                    <input 
                      type="text" 
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      className="w-full pl-9 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider px-1">⏰ Morning Timing</label>
                  <input 
                    type="text" 
                    value={commuteTime}
                    onChange={(e) => setCommuteTime(e.target.value)}
                    className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                    placeholder="e.g. 09:00 AM"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider px-1">🪑 Daily Seating Preference</label>
                  <select
                    value={seatPreference}
                    onChange={(e: any) => setSeatPreference(e.target.value)}
                    className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="back_window">Window Seat </option>
                    <option value="front">Front Passenger Seat</option>
                    <option value="back_middle">Back Row Middle</option>
                  </select>
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <label className="flex items-start gap-3 cursor-pointer group">
                  <input 
                    type="checkbox" 
                    checked={sameDriver} 
                    onChange={(e) => setSameDriver(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 mt-0.5"
                  />
                  <div>
                    <span className="text-xs font-extrabold text-slate-800 block">👤 Pre-establish Same Verified Driver Preference</span>
                    <p className="text-[10px] text-slate-400 font-bold leading-normal">System matches you with the same high-rated driver everyday to replicate a private chauffeur experience (+₹350/mo).</p>
                  </div>
                </label>

                <label className="flex items-start gap-3 cursor-pointer group">
                  <input 
                    type="checkbox" 
                    checked={reservedSeat} 
                    onChange={(e) => setReservedSeat(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 mt-0.5"
                  />
                  <div>
                    <span className="text-xs font-extrabold text-slate-800 block">🛋️ Reserved Daily Front/Window Seat Position</span>
                    <p className="text-[10px] text-slate-400 font-bold leading-normal">Never sit cramped. Reserve your daily seat alignment for superior posture support (+₹150/mo).</p>
                  </div>
                </label>
              </div>
            </div>

            <div className="md:col-span-5 bg-white border border-slate-200 p-6 rounded-2xl flex flex-col justify-between scale-102 shadow-sm">
              <div className="space-y-4">
                <span className="text-[10px] font-black px-2.5 py-1 bg-indigo-50 text-indigo-600 rounded-full border border-indigo-100 uppercase tracking-wider">
                  Estimator Breakdown
                </span>

                <div className="space-y-2 pt-2 border-b border-dashed border-slate-100 pb-4">
                  <div className="flex justify-between text-xs font-bold text-slate-500">
                    <span>Base Route Pass (FLAT):</span>
                    <span>₹2000/mo</span>
                  </div>
                  {sameDriver && (
                    <div className="flex justify-between text-xs font-bold text-slate-500">
                      <span>Same Driver matching premium:</span>
                      <span>+₹350/mo</span>
                    </div>
                  )}
                  {reservedSeat && (
                    <div className="flex justify-between text-xs font-bold text-slate-500">
                      <span>Daily seat reservation locking:</span>
                      <span>+₹150/mo</span>
                    </div>
                  )}
                  {seatPreference === 'front' && (
                    <div className="flex justify-between text-xs font-bold text-slate-500">
                      <span>Front seat position bonus:</span>
                      <span>+₹100/mo</span>
                    </div>
                  )}
                </div>

                <div className="flex justify-between items-baseline pt-2">
                  <span className="text-sm font-black text-slate-900">Total Price:</span>
                  <div className="text-3xl font-black text-indigo-600">
                    ₹{passPrice}<span className="text-sm font-semibold text-slate-400">/mo</span>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-100 p-3 rounded-xl flex gap-2 items-start text-[10px] text-blue-800 font-bold leading-normal">
                  <Info size={14} className="mt-0.5 flex-shrink-0" />
                  <span>Your custom contract locks in this price forever. No peak demand pricing, no weather surges, absolute transport independence.</span>
                </div>
              </div>

              <div className="pt-6">
                <button
                  onClick={() => handleInitiatePlanPurchase('smart_custom', passPrice, { 
                    customRoute: { from: pickup, to: destination },
                    sameDriver,
                    reservedSeat,
                    seatPreference,
                    price: passPrice
                  })}
                  disabled={isSubscribing !== null}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-md flex items-center justify-center gap-2"
                >
                  {isSubscribing === 'smart_custom' ? (
                    <LoadingSpinner size="sm" color="white" />
                  ) : (
                    <>
                      <span>Generate Custom Member Pass</span>
                      <ArrowRight size={14} />
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'basic' && (
        <div className="space-y-6">
          <div className="flex gap-2 items-center mb-2">
            <span className="bg-slate-100 text-slate-700 w-10 h-10 rounded-xl flex items-center justify-center font-black">
              🛡️
            </span>
            <div>
              <h2 className="text-xl font-black text-slate-900">{language === 'hi' ? 'मानक योजनाएं' : 'Standard Member tiers'}</h2>
              <p className="text-slate-500 text-xs font-black">{language === 'hi' ? 'सवारी पोस्टिंग/खोज आधार पर सरल सदस्यता।' : 'Basic access plans for casual carpool ride matching.'}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {standardPlans.map(plan => (
              <div 
                key={plan.id} 
                className={`bg-white rounded-3xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between ${plan.id === 'premium' ? 'ring-2 ring-indigo-500 ring-offset-2' : ''}`}
              >
                <div className="space-y-4">
                  <h3 className="text-lg font-black text-slate-900">{plan.name}</h3>
                  <div className="text-3xl font-black text-slate-900">
                    ₹{plan.price}<span className="text-sm font-semibold text-slate-400">/{language === 'hi' ? 'माह' : 'mo'}</span>
                  </div>
                  <ul className="text-xs font-bold text-slate-700 space-y-2 pt-2">
                    {plan.features.map((f, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <Check size={14} className="text-indigo-500" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-8">
                  <button 
                    onClick={() => handleInitiatePlanPurchase(plan.id, plan.price)}
                    disabled={currentSubscription?.plan === plan.id || isSubscribing !== null}
                    className={`w-full py-3 rounded-xl text-xs font-black uppercase tracking-wider text-white transition-all flex items-center justify-center gap-2 ${
                      currentSubscription?.plan === plan.id 
                        ? 'bg-slate-200 text-slate-400 cursor-not-allowed border' 
                        : plan.id === 'premium' 
                          ? 'bg-indigo-600 hover:bg-indigo-700 shadow-md shadow-indigo-100' 
                          : 'bg-slate-900 hover:bg-slate-800'
                    }`}
                  >
                    {isSubscribing === plan.id && <LoadingSpinner size="sm" color="white" />}
                    {currentSubscription?.plan === plan.id 
                      ? (language === 'hi' ? 'वर्तमान योजना' : 'Current Plan') 
                      : (language === 'hi' ? 'सदस्यता लें' : 'Subscribe')}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Real UPI Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto w-full h-full">
          <div className="relative w-full max-w-md my-8 animate-in fade-in zoom-in duration-200 z-55">
            <UPIPayment
              amount={paymentAmount}
              language={language}
              showNotification={showNotification}
              onSuccess={(paymentId) => {
                const updatedMeta = {
                  ...(paymentCustomMetadata || {}),
                  paymentId,
                  paidAmount: paymentAmount,
                  paidAt: new Date().toISOString()
                };
                handleSubscribePlan(paymentPlanId, updatedMeta);
                setShowPaymentModal(false);
              }}
              onCancel={() => {
                setShowPaymentModal(false);
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};
