import React from 'react';
import { Ride, Booking } from '../types';
import { TRANSLATIONS } from '../constants';
import { motion, AnimatePresence } from 'motion/react';
import { Armchair, HelpCircle, CheckCircle2, AlertCircle, Sparkles, RefreshCw, Percent } from 'lucide-react';
import { db, collection, query, where, getDocs } from '../firebase';

interface BookingFormProps {
  ride: Ride;
  language: string;
  onConfirm: (details: Partial<Booking>) => void;
  onCancel: () => void;
}

export const BookingForm: React.FC<BookingFormProps> = ({ ride, language, onConfirm, onCancel }) => {
  const [pickupLocation, setPickupLocation] = React.useState(ride.from);
  const [dropLocation, setDropLocation] = React.useState(ride.to);
  const [specialRequests, setSpecialRequests] = React.useState("");
  const [luggageSize, setLuggageSize] = React.useState<'none' | 'small' | 'medium' | 'large'>('small');
  
  // Seat-related states
  const [selectedSeats, setSelectedSeats] = React.useState<string[]>([]);
  const [selectedSeatGenders, setSelectedSeatGenders] = React.useState<Record<string, 'any' | 'female' | 'male'>>({});
  const [occupiedSeats, setOccupiedSeats] = React.useState<string[]>([]);
  const [seatGenders, setSeatGenders] = React.useState<Record<string, 'any' | 'female' | 'male'>>({});
  const [hoveredSeat, setHoveredSeat] = React.useState<string | null>(null);
  const [confirmationMsg, setConfirmationMsg] = React.useState<string | null>(null);
  const [isLoadingSeats, setIsLoadingSeats] = React.useState(true);

  // Parcel specific fields
  const [parcelWeight, setParcelWeight] = React.useState("1");
  const [parcelDescription, setParcelDescription] = React.useState("");
  const [parcelItemType, setParcelItemType] = React.useState("");
  
  // Dynamic booking type selection
  const [bookingType, setBookingType] = React.useState<'passenger' | 'parcel'>(ride.type === 'parcel' ? 'parcel' : 'passenger');
  
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  // Negotiation-related states
  const [negotiatedPrice, setNegotiatedPrice] = React.useState<number>(ride.price);
  const [suggestedPriceInput, setSuggestedPriceInput] = React.useState<string>("");
  const [negotiationStatus, setNegotiationStatus] = React.useState<'none' | 'negotiating' | 'approved' | 'rejected' | 'countered'>('none');
  const [aiAnalysisMessage, setAiAnalysisMessage] = React.useState<string>("");
  const [negotiationHistory, setNegotiationHistory] = React.useState<Array<{ role: 'user' | 'driver' | 'ai', message: string, price?: number }>>([]);
  const [loadingAi, setLoadingAi] = React.useState<boolean>(false);

  const handleNegotiate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const offeredVal = parseInt(suggestedPriceInput);
    if (!offeredVal || isNaN(offeredVal) || offeredVal <= 0) {
      alert(language === 'hi' ? "कृपया एक मान्य मूल्य दर्ज करें!" : "Please enter a valid price!");
      return;
    }

    setLoadingAi(true);
    setNegotiationStatus('negotiating');

    const originalPrice = ride.price;
    const minFair = Math.round(originalPrice * 0.82);
    const maxFair = Math.round(originalPrice * 0.90);

    const userHistoryItem = { 
      role: 'user' as const, 
      message: language === 'hi' 
        ? `यात्री का प्रस्ताव: ₹${offeredVal}` 
        : `Passenger proposed: ₹${offeredVal}`,
      price: offeredVal
    };

    const updatedHistory = [...negotiationHistory, userHistoryItem];
    setNegotiationHistory(updatedHistory);

    try {
      let aiText = "";
      let status: 'approved' | 'rejected' | 'countered' = 'countered';
      let finalApprovedPrice = negotiatedPrice;

      try {
        const response = await fetch("/api/negotiate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            language,
            originalPrice,
            offeredVal,
            minFair,
            maxFair,
            rideFrom: ride.from,
            rideTo: ride.to
          })
        });
        const data = await response.json();
        if (data.success && data.aiAnalysis) {
          aiText = data.aiAnalysis;
          status = data.status || 'countered';
          finalApprovedPrice = data.counterPrice || offeredVal;
        } else {
          console.warn("Negotiation API fallback mode used.");
        }
      } catch (apiErr) {
        console.warn("Gemini pricing generation API failed, resorting to Indian context bargaining simulation...", apiErr);
      }

      if (!aiText) {
        if (offeredVal < minFair) {
          status = 'countered';
          const counter = Math.round(originalPrice * 0.88);
          finalApprovedPrice = counter;
          aiText = language === 'hi'
            ? `मूल किराया चालक द्वारा: ₹${originalPrice}\nयात्री की बोली: ₹${offeredVal}\nएआई विश्लेषक का कहना है: “उचित मूल्य दायरा ₹${minFair}–₹${maxFair}”\nचालक: "अरे भाई! ₹${offeredVal} बहुत कम है। इस ट्रैफिक और पेट्रोल की कीमत में इतने में कैसे होगा? चलो ₹${counter} कर लेते हैं, डन?"`
            : `Driver price: ₹${originalPrice}\nPassenger: ₹${offeredVal}\nAI analysis says:\n“Fair price range ₹${minFair}–₹${maxFair}”\nDriver: "Arey Bhai! ₹${offeredVal} is too low. With current traffic and fuel prices, it's not possible! Let's do a fair compromise at ₹${counter}."`;
        } 
        else if (offeredVal >= minFair && offeredVal <= maxFair) {
          if (offeredVal === 170 && originalPrice === 200) {
            status = 'countered';
            finalApprovedPrice = 175;
            aiText = language === 'hi'
              ? `चालक द्वारा किराया: ₹${originalPrice}\nयात्री की बोली: ₹${offeredVal}\nएआई विश्लेषक का कहना है: “उचित मूल्य दायरा ₹165–₹180”\nचालक: "चलो भाई, न आपका न मेरा, ₹175 फाइनल करते हैं! मोल-भाव दोनों के लिए सही हो गया।"`
              : `Driver price: ₹${originalPrice}\nPassenger: ₹${offeredVal}\nAI analysis says:\n“Fair price range ₹165–₹180”\nDriver: "Chalo Bhai, neither yours nor mine. Let's settle at ₹175! Fair deal for both of us?"`;
          } else {
            status = 'approved';
            finalApprovedPrice = offeredVal;
            aiText = language === 'hi'
              ? `एआई विश्लेषक का कहना है: “उचित मूल्य दायरा ₹${minFair}–₹${maxFair}”\nचालक: "यह बहुत ही उचित और आकर्षक दाम है! आपका प्रस्ताव स्वीकार किया गया। चलिए निकलते हैं!"`
              : `AI analysis says:\n“Fair price range ₹${minFair}–₹${maxFair}”\nDriver: "That's a very fair and reasonable price! Offer accepted. Let's start the journey!"`;
          }
        } 
        else if (offeredVal > maxFair && offeredVal < originalPrice) {
          status = 'approved';
          finalApprovedPrice = offeredVal;
          aiText = language === 'hi'
            ? `एआई विश्लेषक का कहना है: “उचित मूल्य दायरा ₹${minFair}–₹${maxFair}”\nचालक: "शानदार! मैं तुरंत चलने को तैयार हूँ। धन्यवाद!"`
            : `AI analysis says:\n“Fair price range ₹${minFair}–₹${maxFair}”\nDriver: "Superb offer! I am ready to start right away. Thank you!"`;
        } 
        else {
          status = 'approved';
          finalApprovedPrice = originalPrice;
          aiText = language === 'hi'
            ? `चालक: "अरे! आप तो बहुत दयालु हैं, लेकिन मैं मूल किराया ₹${originalPrice} ही लूँगा। धन्यवाद!"`
            : `Driver: "Wow, you are very generous! But I will keep it capped at the original price of ₹${originalPrice}. Deal sealed!"`;
        }
      }

      setAiAnalysisMessage(aiText);
      setNegotiationStatus(status);
      setNegotiatedPrice(finalApprovedPrice);

      setNegotiationHistory(prev => [
        ...prev,
        { role: 'ai', message: aiText, price: finalApprovedPrice }
      ]);

    } catch (err) {
      console.error("Negotiation error:", err);
      setNegotiationStatus('rejected');
    } finally {
      setLoadingAi(false);
    }
  };

  // Decide if vehicle is Bike, SUV, or standard Sedan/Hatchback
  const isBike = ride.carType === 'bike';
  const isSUV = !isBike && ((ride.seats || 0) > 3 || (ride.carName && /suv|innova|ertiga|fortuner|scorpio|xuv/i.test(ride.carName)));

  const SEAT_CONFIGS = isBike ? [
    { id: 'pillion', name: 'Rear Seat (Pillion)', nameHi: 'पीछे की सीट (पिलियन)', type: 'back', row: 'back', col: 'center' }
  ] : isSUV ? [
    { id: 'front_passenger', name: 'Front Passenger Seat', nameHi: 'फ्रंट पैसेंजर सीट', type: 'front', row: 'front', col: 'left' },
    { id: 'mid_left', name: 'Middle Row Left (Window)', nameHi: 'मिडिल रो लेफ्ट (विंडो)', type: 'window', row: 'middle', col: 'left' },
    { id: 'mid_center', name: 'Middle Row Center', nameHi: 'मिडिल रो सेंटर', type: 'middle', row: 'middle', col: 'center' },
    { id: 'mid_right', name: 'Middle Row Right (Window)', nameHi: 'मिडिल रो राइट (विंडो)', type: 'window', row: 'middle', col: 'right' },
    { id: 'back_left', name: 'Back Row Left (Window)', nameHi: 'बैक रो लेफ्ट (विंडो)', type: 'window', row: 'back', col: 'left' },
    { id: 'back_right', name: 'Back Row Right (Window)', nameHi: 'बैक रो राइट (विंडो)', type: 'window', row: 'back', col: 'right' }
  ] : [
    { id: 'front_passenger', name: 'Front Passenger Seat', nameHi: 'फ्रंट पैसेंजर सीट', type: 'front', row: 'front', col: 'left' },
    { id: 'back_left', name: 'Back Left Seat (Window)', nameHi: 'पीछे बाईं सीट (विंडो)', type: 'window', row: 'back', col: 'left' },
    { id: 'back_middle', name: 'Back Middle Seat', nameHi: 'पीछे बीच की सीट', type: 'middle', row: 'back', col: 'center' },
    { id: 'back_right', name: 'Back Right Seat (Window)', nameHi: 'पीछे दाईं सीट (विंडो)', type: 'window', row: 'back', col: 'right' }
  ];

  // Fetch occupied seats for this ride
  React.useEffect(() => {
    if (ride.type !== 'ride') {
      setIsLoadingSeats(false);
      return;
    }

    const fetchBookings = async () => {
      try {
        setIsLoadingSeats(true);
        const q = query(
          collection(db, 'bookings'),
          where('rideId', '==', ride.id)
        );
        const querySnapshot = await getDocs(q);
        const bookings: any[] = [];
        querySnapshot.forEach((doc) => {
          const data = doc.data();
          if (data.status !== 'cancelled') {
            bookings.push({ id: doc.id, ...data });
          }
        });

        const occupiedSet = new Set<string>();
        const gendersMap: Record<string, 'any' | 'female' | 'male'> = {};

        // 1st pass: extract specific seat selections if they exist
        bookings.forEach(b => {
          if (b.selectedSeats && Array.isArray(b.selectedSeats)) {
            b.selectedSeats.forEach((seatId: string) => {
              occupiedSet.add(seatId);
              if (b.seatGenders && b.seatGenders[seatId]) {
                gendersMap[seatId] = b.seatGenders[seatId];
              }
            });
          }
        });

        // 2nd pass: legacy bookings that only had seat counts (block additional seats)
        bookings.forEach(b => {
          if (!b.selectedSeats || !Array.isArray(b.selectedSeats)) {
            const seatsToOccupyCount = b.seats || 1;
            let occupiedCount = 0;
            const allSeatIds = SEAT_CONFIGS.map(s => s.id);
            for (const seatId of allSeatIds) {
              if (occupiedCount >= seatsToOccupyCount) break;
              if (!occupiedSet.has(seatId)) {
                occupiedSet.add(seatId);
                occupiedCount++;
              }
            }
          }
        });

        setOccupiedSeats(Array.from(occupiedSet));
        setSeatGenders(gendersMap);

        // Pre-select the first available seat as a friendly default
        const firstAvailable = SEAT_CONFIGS.find(seat => !occupiedSet.has(seat.id));
        if (firstAvailable) {
          setSelectedSeats([firstAvailable.id]);
          setSelectedSeatGenders({ [firstAvailable.id]: 'any' });
        }
      } catch (error) {
        console.error("Error loading seat bookings:", error);
      } finally {
        setIsLoadingSeats(false);
      }
    };

    fetchBookings();
  }, [ride.id, ride.type]);

  const handleSeatClick = (seatId: string) => {
    const isSelected = selectedSeats.includes(seatId);
    const seatConfig = SEAT_CONFIGS.find(s => s.id === seatId);
    const label = seatConfig ? (language === 'hi' ? seatConfig.nameHi : seatConfig.name) : 'Seat';

    if (isSelected) {
      // Allow deselecting, but we must have at least 1 seat selected for submission
      setSelectedSeats(selectedSeats.filter(id => id !== seatId));
      const newGenders = { ...selectedSeatGenders };
      delete newGenders[seatId];
      setSelectedSeatGenders(newGenders);
      setConfirmationMsg(language === 'hi' ? `${label} को हटाया गया` : `${label} deselected`);
    } else {
      // Check maximum limit
      if (selectedSeats.length >= ride.seats) {
        setConfirmationMsg(
          language === 'hi' 
            ? `आप अधिकतम ${ride.seats} सीटें बुक कर सकते हैं!` 
            : `You can select at most ${ride.seats} seats!`
        );
        return;
      }

      setSelectedSeats([...selectedSeats, seatId]);
      setSelectedSeatGenders({
        ...selectedSeatGenders,
        [seatId]: 'any'
      });
      setConfirmationMsg(
        language === 'hi' 
          ? `${label} सफलतापूर्वक चुना गया!` 
          : `${label} selected successfully!`
      );
    }
  };

  const handleGenderToggle = (seatId: string, gender: 'any' | 'female' | 'male') => {
    setSelectedSeatGenders({
      ...selectedSeatGenders,
      [seatId]: gender
    });
  };

  // Clear confirmation message after 3.5s
  React.useEffect(() => {
    if (confirmationMsg) {
      const timer = setTimeout(() => {
        setConfirmationMsg(null);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [confirmationMsg]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (bookingType !== 'parcel' && selectedSeats.length === 0) {
      setConfirmationMsg(
        language === 'hi' 
          ? 'कृपया बुकिंग के लिए कम से कम एक सीट का चयन करें!' 
          : 'Please select at least one seat to confirm your booking!'
      );
      return;
    }

    // Map first selected seat row/col to legacy seatPreference
    let derivedPref: 'front' | 'back_window' | 'back_middle' = 'back_window';
    if (selectedSeats.length > 0) {
      const firstSeed = selectedSeats[0];
      if (firstSeed.includes('front')) {
        derivedPref = 'front';
      } else if (firstSeed.includes('middle') || firstSeed.includes('center')) {
        derivedPref = 'back_middle';
      }
    }

    onConfirm({
      seats: bookingType === 'parcel' ? 0 : selectedSeats.length,
      pickupLocation,
      dropLocation,
      specialRequests,
      luggageSize: bookingType === 'parcel' ? undefined : luggageSize,
      seatPreference: bookingType === 'parcel' ? undefined : derivedPref,
      selectedSeats: bookingType === 'parcel' ? undefined : selectedSeats,
      selectedSeatLabels: bookingType === 'parcel' ? undefined : selectedSeats.map(id => {
        const item = SEAT_CONFIGS.find(s => s.id === id);
        return item ? (language === 'hi' ? item.nameHi : item.name) : id;
      }),
      seatGenders: bookingType === 'parcel' ? undefined : selectedSeatGenders,
      type: bookingType,
      parcelInfo: bookingType === 'parcel' ? {
        weight: parseFloat(parcelWeight),
        description: parcelDescription,
        itemType: parcelItemType
      } : undefined,
      totalPrice: negotiatedPrice * (bookingType === 'parcel' ? 1 : selectedSeats.length)
    });
  };

  // Helper to render driver seat visually
  const renderDriverInfo = () => {
    return (
      <div className="flex flex-col items-center select-none opacity-60">
        <div className="w-11 h-11 rounded-xl bg-slate-100 border-2 border-slate-200 flex flex-col items-center justify-center relative shadow-inner">
          <span className="text-base select-none">🧭</span>
        </div>
        <span className="text-[8px] font-black uppercase text-slate-400 mt-1">
          {language === 'hi' ? 'चालक' : 'Driver'}
        </span>
      </div>
    );
  };

  // Helper to render passenger seats with animations and tooltips
  const renderSeatInline = (seatId: string, name: string, nameHi: string) => {
    const isOccupied = occupiedSeats.includes(seatId);
    const isSelected = selectedSeats.includes(seatId);
    const gender = seatGenders[seatId];

    const label = language === 'hi' ? nameHi : name;

    let bgClass = "bg-white border-slate-200 text-slate-700 hover:border-slate-350 hover:shadow-xs";
    let iconColor = "text-slate-400 hover:text-slate-500";
    let borderStyle = "";

    if (isOccupied) {
      if (gender === 'female') {
        bgClass = "bg-pink-50 border-pink-200 text-pink-400 cursor-not-allowed";
        iconColor = "text-pink-400";
      } else if (gender === 'male') {
        bgClass = "bg-blue-50 border-blue-200 text-blue-400 cursor-not-allowed";
        iconColor = "text-blue-400";
      } else {
        bgClass = "bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed";
        iconColor = "text-slate-300";
      }
    } else if (isSelected) {
      bgClass = "bg-blue-600 border-blue-700 text-white shadow-md shadow-blue-200 scale-105";
      iconColor = "text-blue-100";
      borderStyle = "ring-2 ring-blue-100";
    }

    const tooltipText = `${label} (${
      isOccupied 
        ? gender === 'female' 
          ? (language === 'hi' ? 'महिला सहयात्री' : 'Women Occupied') 
          : (language === 'hi' ? 'आरक्षित' : 'Occupied')
        : isSelected
        ? (language === 'hi' ? 'चयनित' : 'Your Selected Seat')
        : (language === 'hi' ? 'उपलब्ध' : 'Available seat')
    })`;

    return (
      <div 
        key={seatId} 
        className="relative flex flex-col items-center group"
        onMouseEnter={() => setHoveredSeat(seatId)}
        onMouseLeave={() => setHoveredSeat(null)}
      >
        {/* Simple inline absolute tooltip */}
        <AnimatePresence>
          {hoveredSeat === seatId && (
            <motion.div 
              initial={{ opacity: 0, y: -4, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -4, scale: 0.95 }}
              className="absolute bottom-full mb-1 bg-slate-900 text-white text-[9px] font-bold py-1 px-2 rounded-lg shadow-md z-120 whitespace-nowrap pointer-events-none"
            >
              {tooltipText}
            </motion.div>
          )}
        </AnimatePresence>

        <button
          type="button"
          disabled={isOccupied}
          onClick={() => handleSeatClick(seatId)}
          className={`w-11 h-11 rounded-xl border flex flex-col items-center justify-center transition-all duration-200 relative ${bgClass} ${borderStyle}`}
        >
          <Armchair size={18} className={iconColor} />
          
          {isOccupied && (
            <span className="absolute bottom-0.5 text-[8px] font-black uppercase">
              {gender === 'female' ? '🌸' : '🔒'}
            </span>
          )}

          {isSelected && (
            <span className="absolute -top-1 -right-1 bg-green-500 text-white p-0.5 rounded-full text-[6px] w-3.5 h-3.5 flex items-center justify-center font-bold">
              ✓
            </span>
          )}
        </button>

        <span className="text-[8px] font-black uppercase text-slate-400 mt-1 select-none text-center leading-none max-w-[65px]">
          {language === 'hi' 
            ? nameHi.replace('पीछे ', '').replace('फ्रंट ', '') 
            : name.replace('Back ', '').replace('Front ', '').replace(' Window', '')}
        </span>
      </div>
    );
  };

  // Helper to render Gender Preference Panel
  const renderPreferencesPanel = () => {
    if (selectedSeats.length === 0) return null;

    return (
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 bg-blue-50/40 rounded-2xl border border-blue-100 space-y-3"
      >
        <h3 className="text-xs font-black text-blue-800 uppercase tracking-widest flex items-center gap-1.5 px-0.5">
          👤 {language === 'hi' ? 'सहयात्री जेंडर चयन' : 'Set Seat Passenger / Gender Preferences'}
        </h3>
        <p className="text-[9.5px] text-slate-400 mt-0.5 px-0.5 font-medium leading-relaxed">
          {language === 'hi' 
            ? 'महिलाओं को प्राथमिकता देने या सीट चिन्हित करने के लिए नीचे जेंडर चुने:' 
            : 'Useful for marking women-only passenger seats or letting drivers know passenger details.'}
        </p>
        <div className="space-y-2">
          {selectedSeats.map(seatId => {
            const seat = SEAT_CONFIGS.find(s => s.id === seatId);
            if (!seat) return null;
            
            const currentGender = selectedSeatGenders[seatId] || 'any';
            
            return (
              <div key={seatId} className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 bg-white rounded-xl border border-slate-150 hover:border-slate-200/85 shadow-xs transition-all gap-2">
                <div>
                  <p className="text-xs font-bold text-slate-800">
                    {language === 'hi' ? seat.nameHi : seat.name}
                  </p>
                  <div className="text-[9px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">
                    {seat.type} row
                  </div>
                </div>
                
                <div className="flex gap-1">
                  {[
                    { id: 'any', label: language === 'hi' ? 'कोई भी' : 'Any Gender', icon: '👤' },
                    { id: 'female', label: language === 'hi' ? 'महिला' : 'Female', icon: '🌸' },
                    { id: 'male', label: language === 'hi' ? 'पुरुष' : 'Male', icon: '👨' }
                  ].map(opt => {
                    const isActive = currentGender === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => handleGenderToggle(seatId, opt.id as any)}
                        className={`px-2.5 py-1.5 rounded-lg text-[9px] font-black border transition-all flex items-center gap-1 ${
                          isActive 
                            ? opt.id === 'female' 
                              ? 'bg-pink-100 border-pink-200 text-pink-700 shadow-xs'
                              : opt.id === 'male'
                              ? 'bg-blue-100 border-blue-200 text-blue-700 shadow-xs'
                              : 'bg-slate-200 border-slate-300 text-slate-700 shadow-xs'
                            : 'bg-slate-50 border-slate-100 text-slate-550 hover:bg-slate-100'
                        }`}
                      >
                        <span className="text-[10px]">{opt.icon}</span>
                        <span>{opt.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </motion.div>
    );
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-blue-800">
        {bookingType === 'parcel' ? t.parcelDetails : (language === 'hi' ? 'बुकिंग विवरण' : 'Booking Details')}
      </h2>
      
      <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
        <div className="flex justify-between items-center mb-2">
          <span className="font-bold text-lg">{ride.from} → {ride.to}</span>
          <span className="text-blue-700 font-bold">
            ₹{ride.price} / {bookingType === 'parcel' ? t.parcelDelivery : (language === 'hi' ? 'सीट' : 'seat')}
          </span>
        </div>
        <div className="text-sm text-gray-600 mb-3">
          {ride.date} {language === 'hi' ? 'को' : 'at'} {ride.time} | {language === 'hi' ? 'ड्राइवर' : 'Driver'}: {ride.driverName || ride.driver}
        </div>
        
        {bookingType === 'parcel' && ride.parcelDetails && (
          <div className="mb-3 flex gap-2">
            <span className="bg-white border border-blue-200 text-blue-700 px-2 py-1 rounded text-[10px] font-bold uppercase">
              ⚖️ {t.maxWeight}: {ride.parcelDetails.maxWeight}kg
            </span>
            <span className="bg-white border border-blue-200 text-blue-700 px-2 py-1 rounded text-[10px] font-bold uppercase">
              📏 {t[ride.parcelDetails.maxSize]}
            </span>
          </div>
        )}
        
        {ride.carName && (
          <div className="flex items-center gap-4 p-3 bg-white rounded-lg border border-blue-200">
            {ride.carImage && (
              <div className="w-20 h-14 rounded overflow-hidden flex-shrink-0 bg-gray-100">
                <img src={ride.carImage} alt={ride.carName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
            )}
            <div>
              <p className="text-[10px] font-bold text-blue-600 uppercase tracking-wider">{language === 'hi' ? 'वाहन विवरण' : 'Vehicle Details'}</p>
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="font-bold text-gray-800">{ride.carName}</span>
                {ride.carType && (
                  <span className="px-1.5 py-0.25 rounded text-[8.5px] font-black uppercase tracking-wider bg-blue-50 border border-blue-100 text-blue-700">
                    {ride.carType}
                  </span>
                )}
              </div>
              {ride.vehicleNumber && <p className="text-xs text-gray-500">{ride.vehicleNumber}</p>}
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Smart India Bargain Engine Section */}
        <div className="bg-gradient-to-br from-emerald-50 to-blue-50/60 rounded-2xl border border-emerald-100 p-5 space-y-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="bg-emerald-600 text-white p-1 rounded-lg">
                <Sparkles size={16} />
              </span>
              <div>
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-wide">
                  {language === 'hi' ? '🤝 बुद्धिमान किराया तोल-मोल (मोल-भाव)' : '🤝 Smart Fare Negotiation'}
                </h3>
                <p className="text-[10px] text-emerald-700 font-bold uppercase tracking-wide">
                  {language === 'hi' ? 'भारत का अनोखा एआई मोल-भाव इंजन' : 'India Unique AI Bargain Engine'}
                </p>
              </div>
            </div>
            {negotiatedPrice < ride.price && (
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-1 rounded-full border border-emerald-200 uppercase tracking-wider animate-pulse">
                {language === 'hi' ? `बचत ₹${ride.price - negotiatedPrice}!` : `Saved ₹${ride.price - negotiatedPrice}!`}
              </span>
            )}
          </div>

          <p className="text-xs text-slate-500 leading-relaxed font-semibold">
            {language === 'hi' 
              ? 'किराया अधिक लग रहा है? अपना उचित दाम प्रस्तावित करें! हमारा एआई मूल्य निर्धारण इंजन बाजार मूल्य का विश्लेषण करके ड्राइवर को सहमत कराएगा।' 
              : 'Too expensive? Propose your price! Our intelligent AI pricing assistant calculates fair market range dynamically and negotiates the best fare for you.'}
          </p>

          {/* Pricing meter stage */}
          <div className="grid grid-cols-3 gap-3 bg-white p-3.5 rounded-xl border border-slate-150 text-center shadow-xs">
            <div>
              <p className="text-[9px] font-black uppercase text-slate-400 tracking-wider">
                {language === 'hi' ? 'मूल किराया' : 'Driver Price'}
              </p>
              <p className={`text-lg font-black mt-0.5 ${negotiatedPrice < ride.price ? 'text-slate-400 line-through' : 'text-slate-800'}`}>
                ₹{ride.price}
              </p>
            </div>
            <div className="border-x border-slate-100 flex flex-col justify-center">
              <p className="text-[9px] font-black uppercase text-slate-400 tracking-wider">
                {language === 'hi' ? 'आपका दाम' : 'Your Suggestion'}
              </p>
              <p className="text-lg font-black text-blue-600 mt-0.5">
                {suggestedPriceInput ? `₹${suggestedPriceInput}` : "—"}
              </p>
            </div>
            <div>
              <p className="text-[9px] font-black uppercase text-emerald-600 tracking-wider flex items-center justify-center gap-1">
                <Percent size={10} /> {language === 'hi' ? 'सहमति मूल्य' : 'Agreed Fare'}
              </p>
              <p className="text-lg font-black text-emerald-600 mt-0.5">
                ₹{negotiatedPrice}
              </p>
            </div>
          </div>

          {/* Input field & suggestions */}
          <div className="space-y-3">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-black text-slate-400">₹</span>
                <input
                  type="number"
                  placeholder={language === 'hi' ? 'जैसे: 170' : 'e.g. 170'}
                  value={suggestedPriceInput}
                  onChange={(e) => setSuggestedPriceInput(e.target.value)}
                  className="w-full pl-7 pr-3 py-2 text-xs font-bold border border-slate-250 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>
              <button
                type="button"
                onClick={() => handleNegotiate()}
                disabled={loadingAi || !suggestedPriceInput}
                className="bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-black text-xs px-4 py-2 rounded-xl transition-all shadow-md shadow-emerald-100 flex items-center gap-1.5"
              >
                {loadingAi ? (
                  <>
                    <RefreshCw size={12} className="animate-spin" />
                    <span>{language === 'hi' ? 'मूल्यांकन...' : 'Negotiating...'}</span>
                  </>
                ) : (
                  <span>{language === 'hi' ? 'प्रस्ताव भेजें' : 'Propose Offer'}</span>
                )}
              </button>
            </div>

            {/* Smart Pre-set buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[9.5px] font-black text-slate-400 uppercase tracking-widest mr-1">
                {language === 'hi' ? 'त्वरित मोलभाव:' : 'Quick Bargain:'}
              </span>
              {[
                { pct: 0.10, label: language === 'hi' ? '-10%' : '-10%' },
                { pct: 0.15, label: language === 'hi' ? '-15%' : '-15%' },
                { pct: 0.20, label: language === 'hi' ? '-20%' : '-20%' }
              ].map((item, idx) => {
                const calculatedOffer = Math.round(ride.price * (1 - item.pct));
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setSuggestedPriceInput(calculatedOffer.toString());
                      setTimeout(() => {
                        const originalPrice = ride.price;
                        const minFair = Math.round(originalPrice * 0.82);
                        const maxFair = Math.round(originalPrice * 0.90);
                        let finalApprovedPrice = calculatedOffer;
                        let status: 'approved' | 'rejected' | 'countered' = 'countered';
                        let aiText = "";

                        if (calculatedOffer < minFair) {
                          status = 'countered';
                          const counter = Math.round(originalPrice * 0.88);
                          finalApprovedPrice = counter;
                          aiText = language === 'hi'
                            ? `मूल किराया चालक द्वारा: ₹${originalPrice}\nयात्री की बोली: ₹${calculatedOffer}\nएआई विश्लेषक का कहना है: “उचित मूल्य दायरा ₹${minFair}–₹${maxFair}”\nचालक: "अरे भाई! ₹${calculatedOffer} बहुत कम है। इस ट्रैफिक और पेट्रोल की कीमत में इतने में कैसे होगा? चलो ₹${counter} कर लेते हैं, डन?"`
                            : `Driver price: ₹${originalPrice}\nPassenger: ₹${calculatedOffer}\nAI analysis says:\n“Fair price range ₹${minFair}–₹${maxFair}”\nDriver: "Arey Bhai! ₹${calculatedOffer} is too low. With current traffic and fuel prices, it's not possible! Let's do a fair compromise at ₹${counter}."`;
                        } else {
                          status = 'countered';
                          finalApprovedPrice = Math.round((calculatedOffer + originalPrice) / 2);
                          aiText = language === 'hi'
                            ? `चालक द्वारा किराया: ₹${originalPrice}\nयात्री की बोली: ₹${calculatedOffer}\nएआई विश्लेषक का कहना है: “उचित मूल्य दायरा ₹${minFair}–₹${maxFair}”\nचालक: "चलो भाई, न आपका न मेरा, ₹${finalApprovedPrice} फाइनल करते हैं! मोल-भाव दोनों के लिए सही हो गया।"`
                            : `Driver price: ₹${originalPrice}\nPassenger: ₹${calculatedOffer}\nAI analysis says:\n“Fair price range ₹${minFair}–₹${maxFair}”\nDriver: "Chalo Bhai, neither yours nor mine. Let's settle at ₹${finalApprovedPrice}! Fair deal for both of us?"`;
                        }

                        setAiAnalysisMessage(aiText);
                        setNegotiationStatus(status);
                        setNegotiatedPrice(finalApprovedPrice);
                        setSuggestedPriceInput(calculatedOffer.toString());
                        setNegotiationHistory([
                          { role: 'user', message: language === 'hi' ? `यात्री का प्रस्ताव: ₹${calculatedOffer}` : `Passenger proposed: ₹${calculatedOffer}`, price: calculatedOffer },
                          { role: 'ai', message: aiText, price: finalApprovedPrice }
                        ]);
                      }, 50);
                    }}
                    className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-extrabold text-[9.5px] px-2.5 py-1 rounded-lg transition-all"
                  >
                    {item.label} (₹{calculatedOffer})
                  </button>
                );
              })}
            </div>
          </div>

          {/* AI Analysis and dialog history */}
          {negotiationHistory.length > 0 && (
            <div className="bg-slate-100/50 p-3.5 rounded-xl border border-slate-250 max-h-48 overflow-y-auto space-y-3">
              <p className="text-[9px] font-black uppercase text-slate-400 tracking-wider">
                {language === 'hi' ? 'मोलभाव इतिहास और एआई विश्लेषण:' : 'Bargain History & AI Analysis:'}
              </p>
              <div className="space-y-2.5">
                {negotiationHistory.map((item, id) => (
                  <div
                    key={id}
                    className={`flex flex-col gap-1 p-2.5 rounded-lg text-xs leading-relaxed ${
                      item.role === 'user'
                        ? 'bg-blue-50/70 border-l-4 border-l-blue-500 self-end ml-4'
                        : 'bg-emerald-50/70 border-l-4 border-l-emerald-500 mr-4'
                    }`}
                  >
                    <div className="flex items-center gap-1 text-[9px] font-black uppercase tracking-wider">
                      {item.role === 'user' ? (
                        <span className="text-blue-700">👤 {language === 'hi' ? 'आप' : 'You (Passenger)'}</span>
                      ) : (
                        <span className="text-emerald-700 flex items-center gap-1">
                          <Sparkles size={10} /> {language === 'hi' ? 'इलेक्ट्रॉनिक एआई सहायक व चालक' : 'AI Assistant & Driver'}
                        </span>
                      )}
                    </div>
                    <div className="whitespace-pre-line text-[11px] font-semibold text-slate-700">
                      {item.message}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Success Deal lock panel */}
          {negotiationStatus !== 'none' && negotiationStatus !== 'negotiating' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className={`p-3.5 rounded-xl border text-center font-bold ${
                negotiationStatus === 'approved' || negotiationStatus === 'countered'
                  ? 'bg-emerald-100 border-emerald-300 text-emerald-800'
                  : 'bg-red-50 border-red-200 text-red-800'
              }`}
            >
              <p className="text-xs uppercase tracking-wider font-extrabold flex items-center justify-center gap-1.5">
                {negotiationStatus === 'approved' ? (
                  <>🎉 {language === 'hi' ? 'पक्का सौदा! स्वीकार किया गया' : 'Deal Approved!'}</>
                ) : (
                  <>🤝 {language === 'hi' ? 'चालक की ओर से काउंटर-ऑफ़र' : 'Driver Partner Countered'}</>
                )}
              </p>
              <p className="text-[11px] font-semibold mt-1">
                {language === 'hi'
                  ? `किराया ₹${negotiatedPrice} प्रति सीट स्वीकृत हो गया है। आप भुगतान पर ₹${ride.price - negotiatedPrice} की बचत कर रहे हैं!`
                  : `Fare of ₹${negotiatedPrice} per seat is ready. You are saving ₹${ride.price - negotiatedPrice} on this ride!`}
              </p>
              <div className="mt-2.5 flex gap-2 justify-center">
                <button
                  type="button"
                  onClick={() => {
                    alert(language === 'hi' ? "किराया सफलतापूर्वक लॉक कर दिया गया!" : "Negotiated price successfully locked!");
                  }}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-[10px] px-3.5 py-1.5 rounded-lg shadow-sm transition-all"
                >
                  {language === 'hi' ? 'लॉक किया गया ✓' : 'Agreed & Locked ✓'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setNegotiatedPrice(ride.price);
                    setSuggestedPriceInput("");
                    setNegotiationStatus('none');
                    setNegotiationHistory([]);
                  }}
                  className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-extrabold text-[10px] px-3.5 py-1.5 rounded-lg transition-all"
                >
                  {language === 'hi' ? 'रीसेट करें' : 'Reset Fare'}
                </button>
              </div>
            </motion.div>
          )}
        </div>

        {/* Booking Type Selector */}
        <div className="p-4 bg-slate-50 border border-slate-200/60 rounded-xl mb-4">
          <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2 px-1">
            ⚡ {t.rideType || (language === 'hi' ? 'बुकिंग का प्रकार' : 'Booking Type')}
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              id="booking-type-passenger"
              onClick={() => setBookingType('passenger')}
              className={`py-2.5 px-3 rounded-lg text-xs font-bold border transition-all flex items-center justify-center gap-2 ${
                bookingType === 'passenger'
                  ? 'bg-blue-600 border-blue-700 text-white shadow-xs font-black scale-102'
                  : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
              }`}
            >
              👤 {t.passengerRide || (language === 'hi' ? 'यात्री सवारी' : 'Passenger Ride')}
            </button>
            <button
              type="button"
              id="booking-type-parcel"
              onClick={() => setBookingType('parcel')}
              className={`py-2.5 px-3 rounded-lg text-xs font-bold border transition-all flex items-center justify-center gap-2 ${
                bookingType === 'parcel'
                  ? 'bg-blue-600 border-blue-700 text-white shadow-xs font-black scale-102'
                  : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
              }`}
            >
              📦 {t.parcelDelivery || (language === 'hi' ? 'पार्सल डिलीवरी' : 'Parcel Delivery')}
            </button>
          </div>
        </div>

        {bookingType === 'parcel' ? (
          <div className="space-y-4 p-4 bg-slate-50 border border-slate-200 rounded-xl">
             <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 mb-2">
               📦 {t.packageInfo}
             </h4>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold mb-1">{t.parcelType}</label>
                  <input 
                    type="text" 
                    value={parcelItemType} 
                    onChange={(e) => setParcelItemType(e.target.value)}
                    className="w-full p-2 border rounded-lg bg-white"
                    placeholder={language === 'hi' ? 'जैसे: कपड़े, इलेक्ट्रॉनिक्स...' : 'e.g. Clothes, electronics...'}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold mb-1">{t.parcelWeight}</label>
                  <input 
                    type="number" 
                    value={parcelWeight} 
                    onChange={(e) => setParcelWeight(e.target.value)}
                    className="w-full p-2 border rounded-lg bg-white"
                    max={ride.parcelDetails?.maxWeight || 50}
                    required
                  />
                </div>
             </div>
             <div>
                <label className="block text-sm font-bold mb-1">{t.parcelDesc}</label>
                <textarea 
                  value={parcelDescription} 
                  onChange={(e) => setParcelDescription(e.target.value)}
                  className="w-full p-2 border rounded-lg h-20 bg-white"
                  placeholder={language === 'hi' ? 'पैकेज की सामग्री और निर्देशों का वर्णन करें' : 'Describe the package contents and instructions'}
                />
             </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Passenger Seat Visual Map Panel */}
            <div className="p-5 bg-gradient-to-br from-slate-50 to-slate-100/50 rounded-2xl border border-slate-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                <div>
                  <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    💺 {language === 'hi' ? 'सीट मैप चुनें' : 'Choose Seats'}
                  </h3>
                  <p className="text-[10.5px] text-slate-400 font-bold uppercase tracking-wide mt-0.5">
                    {ride.seats} {language === 'hi' ? 'सीटें उपलब्ध हैं' : 'seats available'} • {language === 'hi' ? 'चयनित: ' : 'Selected: '}{selectedSeats.length}
                  </p>
                </div>

                {/* Animated Confirmation Message */}
                <AnimatePresence mode="wait">
                  {confirmationMsg && (
                    <motion.div
                      key={confirmationMsg}
                      initial={{ opacity: 0, x: 10, scale: 0.95 }}
                      animate={{ opacity: 1, x: 0, scale: 1 }}
                      exit={{ opacity: 0, x: -10, scale: 0.95 }}
                      className="bg-blue-600 text-white font-black text-[9px] uppercase tracking-wider px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-md shadow-blue-100"
                    >
                      <CheckCircle2 size={11} className="flex-shrink-0 text-white animate-bounce" />
                      <span>{confirmationMsg}</span>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {isLoadingSeats ? (
                <div className="flex flex-col items-center justify-center py-10 space-y-2">
                  <div className="w-6 h-6 border-2 border-slate-400 border-t-blue-600 rounded-full animate-spin" />
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    {language === 'hi' ? 'सक्रिय सीटें लोड हो रही हैं...' : 'Loading Seat Layout...'}
                  </p>
                </div>
              ) : (
                <div className="flex flex-col lg:flex-row items-center justify-around gap-6 py-2">
                  
                  {/* Legend Panel */}
                  <div className="flex flex-row lg:flex-col flex-wrap gap-2.5 bg-white p-3 rounded-xl border border-slate-100 shadow-sm w-full lg:w-48 text-[10px] font-bold text-slate-500 justify-center">
                    <div className="flex items-center gap-1.5">
                      <div className="w-3.5 h-3.5 rounded bg-white border border-slate-200 flex items-center justify-center">
                        <Armchair size={8} className="text-slate-400" />
                      </div>
                      <span>{language === 'hi' ? 'उपलब्ध' : 'Available'}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-3.5 h-3.5 rounded bg-blue-600 border border-blue-700 flex items-center justify-center">
                        <Armchair size={8} className="text-blue-100" />
                      </div>
                      <span className="text-blue-600">{language === 'hi' ? 'चयनित' : 'Your Choice'}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-3.5 h-3.5 rounded bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-400 font-bold text-[7px]" title="Booked Seat">
                        🔒
                      </div>
                      <span className="text-slate-400">{language === 'hi' ? 'बुक किया हुआ' : 'Occupied'}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-3.5 h-3.5 rounded bg-pink-50 border border-pink-200 flex items-center justify-center text-[7px]" title="Women Passenger Seat">
                        🌸
                      </div>
                      <span className="text-pink-600">{language === 'hi' ? 'महिला' : 'Women Occupied'}</span>
                    </div>
                  </div>

                  {/* Visual Car/Bike Cabin representation */}
                  <div className="relative bg-white border-4 border-slate-200 rounded-[35px] shadow-sm p-5 pt-8 pb-7 flex flex-col items-center w-[230px] border-b-[8px] border-b-slate-300">
                    {/* Headlights highlight */}
                    {isBike ? (
                      <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-5 h-2 bg-yellow-300/90 rounded-t-full" />
                    ) : (
                      <>
                        <div className="absolute -top-1 left-7 w-4 h-2 bg-yellow-300/80 rounded-t-full" />
                        <div className="absolute -top-1 right-7 w-4 h-2 bg-yellow-300/80 rounded-t-full" />
                      </>
                    )}
                    {/* Taillights highlight */}
                    {isBike ? (
                      <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-4 h-1.5 bg-red-600 rounded-b-full" />
                    ) : (
                      <>
                        <div className="absolute -bottom-1.5 left-7 w-4 h-1.5 bg-red-500 rounded-b-full" />
                        <div className="absolute -bottom-1.5 right-7 w-4 h-1.5 bg-red-500 rounded-b-full" />
                      </>
                    )}
                    {/* Mirrors */}
                    {isBike ? (
                      <>
                        <div className="absolute left-[50px] top-4 w-3.5 h-1.5 bg-slate-400 rounded-t-full -rotate-12 pointer-events-none" />
                        <div className="absolute right-[50px] top-4 w-3.5 h-1.5 bg-slate-400 rounded-t-full rotate-12 pointer-events-none" />
                      </>
                    ) : (
                      <>
                        <div className="absolute -left-2.5 top-14 w-2 h-6 bg-slate-300 rounded-l" />
                        <div className="absolute -right-2.5 top-14 w-2 h-6 bg-slate-300 rounded-r" />
                      </>
                    )}

                    {/* Dashboard steering wheel/handlebar indicator */}
                    {!isBike ? (
                      <div className="absolute top-1 right-6 opacity-30 pointer-events-none">
                        <div className="w-7 h-7 rounded-full border-4 border-slate-800 flex items-center justify-center relative">
                          <div className="w-1.5 h-1.5 rounded-full bg-slate-800" />
                          <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-0.5 bg-slate-800" />
                          <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-0.5 bg-slate-800" />
                        </div>
                      </div>
                    ) : (
                      <div className="absolute top-1.5 left-1/2 -translate-x-1/2 opacity-30 pointer-events-none flex flex-col items-center">
                        <div className="w-12 h-1 bg-slate-800 rounded-full" />
                        <div className="w-0.5 h-3 bg-slate-800" />
                      </div>
                    )}

                    <p className="text-[7.5px] font-black uppercase text-slate-300 tracking-widest mb-4">
                      {isBike ? '=== BIKE / SCOOTER ===' : isSUV ? '=== SUV CABIN ===' : '=== SEDAN CABIN ==='}
                    </p>

                    {/* Seat Map Layout Grid */}
                    {isBike ? (
                      <div className="space-y-6 w-full flex flex-col items-center">
                        {/* Front: Driver */}
                        <div className="flex flex-col items-center">
                          {renderDriverInfo()}
                        </div>

                        {/* Mid chassis connector */}
                        <div className="w-2.5 h-4 bg-slate-100 rounded border border-slate-200/60 shadow-inner flex items-center justify-center pointer-events-none">
                          <div className="w-0.5 h-3 bg-slate-300" />
                        </div>

                        {/* Rear: Passenger Seat (Pillion) */}
                        <div className="flex flex-col items-center bg-slate-50/40 p-2 rounded-2xl border border-slate-100">
                          {renderSeatInline('pillion', 'Rear Seat (Pillion)', 'पीछे की सीट (पिलियन)')}
                        </div>
                      </div>
                    ) : isSUV ? (
                      <div className="space-y-4 w-full">
                        {/* Row 1 (Front) */}
                        <div className="grid grid-cols-2 gap-4 w-full justify-items-center">
                          {renderSeatInline('front_passenger', 'Front Passenger', 'फ्रंट पैसेंजर सीट')}
                          {renderDriverInfo()}
                        </div>

                        {/* Row 2 (Middle SUV Row) */}
                        <div className="grid grid-cols-3 gap-2 w-full justify-items-center bg-slate-50/20 p-1 rounded-xl">
                          {renderSeatInline('mid_left', 'Mid Left Row', 'मिडिल बाईं सीट')}
                          {renderSeatInline('mid_center', 'Mid Center Row', 'मिडिल बीच की सीट')}
                          {renderSeatInline('mid_right', 'Mid Right Row', 'मिडिल दाईं सीट')}
                        </div>

                        {/* Row 3 (Back SUV Row) */}
                        <div className="grid grid-cols-2 gap-4 w-full justify-items-center bg-slate-50/50 p-1.5 rounded-xl border border-slate-100">
                          {renderSeatInline('back_left', 'Back Left', 'बैक लेफ्ट')}
                          {renderSeatInline('back_right', 'Back Right', 'बैक RIGHT')}
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-5 w-full">
                        {/* Row 1 (Front Sedan) */}
                        <div className="grid grid-cols-2 gap-5 w-full justify-items-center">
                          {renderSeatInline('front_passenger', 'Front Seat', 'फ्रंट पैसेंजर')}
                          {renderDriverInfo()}
                        </div>

                        {/* Row 2 (Back Sedan) */}
                        <div className="grid grid-cols-3 gap-1.5 w-full justify-items-center bg-slate-50/50 p-2 rounded-2xl border border-slate-100">
                          {renderSeatInline('back_left', 'Back Left', 'बाईं सीट')}
                          {renderSeatInline('back_middle', 'Back Middle', 'बीच की सीट')}
                          {renderSeatInline('back_right', 'Back Right', 'दाईं सीट')}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Render passenger seat gender indicators (the Women-Only toggles) */}
            {renderPreferencesPanel()}

            {/* Luggage Size selection inside a beautiful container */}
            <div className="p-4 bg-slate-50/55 rounded-xl border border-slate-100">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2 px-1">
                🧳 {t.luggageSize}
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { id: 'none', label: t.none },
                  { id: 'small', label: t.smallLuggage },
                  { id: 'medium', label: t.mediumLuggage },
                  { id: 'large', label: t.largeLuggage }
                ].map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setLuggageSize(opt.id as any)}
                    className={`py-2 px-1 rounded-lg text-[9.5px] font-black border transition-all ${
                      luggageSize === opt.id 
                        ? 'bg-blue-55 border-blue-600 text-blue-700 shadow-xs' 
                        : 'bg-white border-slate-200 text-slate-500 hover:border-slate-300'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-bold mb-1">
              {language === 'hi' ? 'पिकअप स्थान' : 'Pickup Location'}
            </label>
            <input 
              type="text" 
              value={pickupLocation} 
              onChange={(e) => setPickupLocation(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-bold mb-1">
              {language === 'hi' ? 'ड्रॉप स्थान' : 'Drop Location'}
            </label>
            <input 
              type="text" 
              value={dropLocation} 
              onChange={(e) => setDropLocation(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold mb-1">
            {language === 'hi' ? 'विशेष अनुरोध (वैकल्पिक)' : 'Special Requests (Optional)'}
          </label>
          <textarea 
            value={specialRequests} 
            onChange={(e) => setSpecialRequests(e.target.value)}
            className="w-full p-2 border rounded-lg h-24"
            placeholder={language === 'hi' ? 'जैसे: अतिरिक्त सामान, पालतू जानवर, आदि।' : 'e.g. Extra luggage, pet, etc.'}
          />
        </div>

        <div className="p-4 bg-gray-50 rounded-lg flex justify-between items-center bg-emerald-50/40 border border-emerald-100">
          <div>
            <span className="font-bold block text-sm text-slate-700">{language === 'hi' ? 'कुल राशि:' : 'Total Amount:'}</span>
            {negotiatedPrice < ride.price && (
              <span className="text-[10px] bg-emerald-100 text-emerald-800 font-extrabold px-1.5 py-0.5 rounded uppercase">
                {language === 'hi' ? `बचत लागू: ₹${(ride.price - negotiatedPrice) * (bookingType === 'parcel' ? 1 : selectedSeats.length)}!` : `Discount applied: ₹${(ride.price - negotiatedPrice) * (bookingType === 'parcel' ? 1 : selectedSeats.length)}!`}
              </span>
            )}
          </div>
          <span className="text-2xl font-black text-blue-700">₹{negotiatedPrice * (bookingType === 'parcel' ? 1 : selectedSeats.length)}</span>
        </div>

        <div className="flex gap-4 pt-4">
          <button 
            type="button" 
            onClick={onCancel}
            className="flex-1 secondary-btn py-3"
          >
            {language === 'hi' ? 'रद्द करें' : 'Cancel'}
          </button>
          <button 
            type="submit" 
            className="flex-1 py-3 bg-blue-700 text-white rounded-lg font-bold hover:bg-blue-800 transition-colors"
          >
            {language === 'hi' ? 'भुगतान के लिए आगे बढ़ें' : 'Proceed to Payment'}
          </button>
        </div>
      </form>
    </div>
  );
};
