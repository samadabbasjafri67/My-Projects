import React from 'react';
import { TRANSLATIONS } from '../constants';
import { Menu, X, Car, Search, List, ShieldCheck, Building2, CreditCard, User, Star, BarChart3, MessageSquare, LogOut, Navigation, Wallet, Compass, HelpCircle } from 'lucide-react';

interface HeaderProps {
  currentUser: string | null;
  onLogout: () => void;
  onShowSection: (section: string) => void;
  language: string;
  isAdmin: boolean;
  activeSection: string;
}

export const Header: React.FC<HeaderProps> = ({ currentUser, onLogout, onShowSection, language, isAdmin, activeSection }) => {
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const navItems = [
    { id: "offerSection", label: t.offerRide, icon: Car },
    { id: "searchSection", label: t.searchRide, icon: Search },
    { id: "transportHubSection", label: t.transportHub, icon: Compass },
    { id: "rideMatchingSection", label: t.rideMatching, icon: Navigation },
    { id: "myRidesSection", label: t.myRides, icon: List },
    { id: "lostFoundSection", label: t.lostAndFound || "Lost & Found", icon: HelpCircle },
    { id: "driverVerificationSection", label: t.driverVerification, icon: ShieldCheck },
    { id: "corporateSection", label: t.corporate, icon: Building2 },
    { id: "subscriptionSection", label: t.subscription, icon: CreditCard },
    { id: "walletSection", label: t.wallet, icon: Wallet },
    { id: "profileSection", label: t.myProfile, icon: User },
    { id: "ratingSection", label: t.ratings, icon: Star },
    { id: "evAnalyticsSection", label: t.evAnalytics, icon: BarChart3 },
    { id: "feedbackSection", label: t.feedback, icon: MessageSquare },
  ];

  const handleNavClick = (id: string) => {
    onShowSection(id);
    setIsMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto w-full flex items-center justify-between px-4 py-3">
        <div 
          className="flex items-center gap-2 cursor-pointer group"
          onClick={() => onShowSection("searchSection")}
        >
          <div className="bg-primary p-1.5 rounded-lg text-white group-hover:scale-110 transition-transform">
            <Car size={24} />
          </div>
          <span className="text-xl font-extrabold tracking-tight text-slate-900">EcoPool</span>
        </div>

        {currentUser && (
          <div className="flex items-center gap-4">
            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-1 flex-wrap justify-end">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                    activeSection === item.id 
                      ? "bg-blue-50 text-primary" 
                      : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                  }`}
                >
                  <item.icon size={16} />
                  {item.label}
                </button>
              ))}
              {isAdmin && (
                <button
                  onClick={() => handleNavClick("adminSection")}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                    activeSection === "adminSection" 
                      ? "bg-amber-100 text-amber-800" 
                      : "bg-amber-50 text-amber-700 hover:bg-amber-100"
                  }`}
                >
                  <ShieldCheck size={16} className="text-amber-600" />
                  {t.adminPanel}
                </button>
              )}
              <button 
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 transition-all ml-2 animate-pulse" 
                onClick={onLogout}
              >
                <LogOut size={16} />
                {t.logout}
              </button>
            </nav>
            
            {/* Mobile Menu Toggle */}
            <button 
              className="lg:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        )}
      </div>

      {/* Mobile Nav Overlay */}
      {currentUser && isMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 w-full bg-white border-b border-slate-200 shadow-xl max-h-[80vh] overflow-y-auto animate-in slide-in-from-top duration-200 z-50">
          <nav className="flex flex-col p-4 gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl text-base font-semibold transition-all ${
                  activeSection === item.id 
                    ? "bg-blue-50 text-primary" 
                    : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                <item.icon size={20} />
                {item.label}
              </button>
            ))}
            {isAdmin && (
              <button
                onClick={() => handleNavClick("adminSection")}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl text-base font-bold transition-all ${
                  activeSection === "adminSection" 
                    ? "bg-amber-100 text-amber-800" 
                    : "bg-amber-50 text-amber-700 hover:bg-amber-100"
                }`}
              >
                <ShieldCheck size={20} className="text-amber-600" />
                {t.adminPanel}
              </button>
            )}
            <div className="h-px bg-slate-100 my-2" />
            <button 
              className="flex items-center gap-3 px-4 py-3 rounded-xl text-base font-semibold text-red-600 hover:bg-red-50 transition-all" 
              onClick={onLogout}
            >
              <LogOut size={20} />
              {t.logout}
            </button>
          </nav>
        </div>
      )}
    </header>
  );
};
