import { Ride } from '../types';

export interface ScenarioSuggestion {
  label: string;
  actionLabel: string;
  type: 'wait' | 'walk' | 'shared';
  benefit: string;
  targetRideId?: string | number;
}

export const ScenarioSuggestionService = {
  getSuggestions(selectedRide: Ride, allRides: Ride[], language: string): ScenarioSuggestion[] {
    const isHindi = language === 'hi';
    const suggestions: ScenarioSuggestion[] = [];

    // 1. "Wait 5-15 min" suggestion
    // Find rides that are at the same location but slightly later and cheaper
    const selectedTimeInMinutes = this.timeToMinutes(selectedRide.time);
    const cheaperLaterRide = allRides.find(r => {
      const rTime = this.timeToMinutes(r.time);
      return r.id !== selectedRide.id && 
             r.from === selectedRide.from && 
             rTime > selectedTimeInMinutes && 
             rTime <= selectedTimeInMinutes + 30 &&
             r.price < selectedRide.price - 5;
    });

    if (cheaperLaterRide) {
      const waitTime = this.timeToMinutes(cheaperLaterRide.time) - selectedTimeInMinutes;
      suggestions.push({
        type: 'wait',
        label: isHindi 
          ? `${waitTime} मिनट रुकें और ₹${selectedRide.price - cheaperLaterRide.price} बचाएं` 
          : `Wait ${waitTime} min and save ₹${selectedRide.price - cheaperLaterRide.price}`,
        benefit: isHindi ? 'सस्ती सवारी' : 'Cheaper Ride',
        actionLabel: isHindi ? 'समय बदलें' : 'Change Time',
        targetRideId: cheaperLaterRide.id
      });
    }

    // 2. "Walk 200m" suggestion (Simulated)
    // In a real app, this would check nearby pickup points.
    // For this demo, let's simulate if there's a ride starting from a "Major Landmark" nearby
    if (selectedRide.price > 40 && !selectedRide.from.includes('Station')) {
       suggestions.push({
         type: 'walk',
         label: isHindi 
           ? '300 मीटर पैदल चलें और 10 मिनट पहले पहुंचें' 
           : 'Walk 300m for 10 min faster pickup',
         benefit: isHindi ? 'तेज़ पिकअप' : 'Faster Pickup',
         actionLabel: isHindi ? 'नक्शा देखें' : 'View Map'
       });
    }

    // 3. "Eco Sharing" suggestion
    if (!selectedRide.isEV && allRides.some(r => r.isEV && r.from === selectedRide.from)) {
      suggestions.push({
        type: 'shared',
        label: isHindi 
          ? 'इलेक्ट्रिक वाहन चुनें और 2KG CO₂ बचाएं' 
          : 'Choose EV and save 2KG CO₂',
        benefit: isHindi ? 'पर्यावरण अनुकूल' : 'Eco Friendly',
        actionLabel: isHindi ? 'EV चुनें' : 'Switch to EV'
      });
    }

    return suggestions;
  },

  timeToMinutes(timeStr: string): number {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours * 60 + minutes;
  }
};
