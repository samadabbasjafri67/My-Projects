import { Booking, User, Ride } from '../types';
import { db, doc, updateDoc } from '../firebase';

export interface PreferenceInsight {
  label: string;
  type: 'ac' | 'price' | 'eco' | 'security';
}

export const PreferenceLearningService = {
  /**
   * Analyzes history to update the user's learned preferences in Firestore
   */
  async updateLearnedPreferences(userId: string, bookings: Booking[]) {
    if (bookings.length < 3) return; // Need a baseline

    const stats = {
      ac: 0,
      ev: 0,
       priceSum: 0,
      womenOnly: 0,
      rideTypes: { passenger: 0, parcel: 0 }
    };

    bookings.forEach(b => {
      const ride = b.ride;
      if (!ride) return;

      if (ride.amenities?.includes('AC')) stats.ac++;
      if (ride.isEV) stats.ev++;
      if (ride.womenOnly) stats.womenOnly++;
      stats.priceSum += ride.price;
      
      const type = (ride.type || 'passenger') as 'passenger' | 'parcel';
      stats.rideTypes[type]++;
    });

    const count = bookings.length;
    const avgPrice = stats.priceSum / count;
    
    // Low price preference if they consistently choose below-average price rides 
    // This is a simplification; ideally we'd compare chosen price vs available average at that time
    const prefersLowPrice = avgPrice < 40 ? 0.8 : 0.3; 

    const preferences: User['learnedPreferences'] = {
      prefersAC: stats.ac / count,
      prefersEV: stats.ev / count,
      prefersLowPrice,
      prefersWomenOnly: stats.womenOnly / count,
      frequentRideType: stats.rideTypes.parcel > stats.rideTypes.passenger ? 'parcel' : 'passenger'
    };

    try {
      await updateDoc(doc(db, 'users', userId), {
        learnedPreferences: preferences
      });
    } catch (e) {
      console.error("Failed to update preferences:", e);
    }
  },

  /**
   * Returns a score boost for a ride based on learned preferences
   */
  calculatePreferenceMatch(ride: Ride, preferences: User['learnedPreferences'] | undefined): number {
    if (!preferences) return 0;
    
    let score = 0;
    
    if (ride.amenities?.includes('AC') && (preferences.prefersAC || 0) > 0.6) score += 20;
    if (ride.isEV && (preferences.prefersEV || 0) > 0.6) score += 15;
    if (ride.price < 40 && (preferences.prefersLowPrice || 0) > 0.6) score += 25;
    if (ride.womenOnly && (preferences.prefersWomenOnly || 0) > 0.6) score += 30;
    
    return score;
  },

  getMatchInsight(ride: Ride, preferences: User['learnedPreferences'] | undefined, language: string): PreferenceInsight | null {
    if (!preferences) return null;
    const isHindi = language === 'hi';

    if (ride.amenities?.includes('AC') && (preferences.prefersAC || 0) > 0.7) {
      return { 
        label: isHindi ? 'पसंदीदा: AC' : 'Prefers: AC', 
        type: 'ac' 
      };
    }
    
    if (ride.price < 35 && (preferences.prefersLowPrice || 0) > 0.7) {
      return { 
        label: isHindi ? 'बजट अनुकूल' : 'Budget Friendly', 
        type: 'price' 
      };
    }

    if (ride.isEV && (preferences.prefersEV || 0) > 0.7) {
      return { 
        label: isHindi ? 'इको-फ्रेंडली' : 'Eco-Friendly', 
        type: 'eco' 
      };
    }

    return null;
  }
};
