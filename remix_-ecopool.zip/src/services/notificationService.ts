import { db, doc, updateDoc } from '../firebase';

export class NotificationService {
  static async requestPermission(userId: string) {
    if (!('Notification' in window)) {
      console.warn('This browser does not support notifications.');
      return false;
    }

    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        await updateDoc(doc(db, 'users', userId), {
          notificationsEnabled: true,
          // In a full FCM setup, we would fetch the token here:
          // pushToken: await getFCMToken()
        });
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      return false;
    }
  }

  static async sendNotification(title: string, options?: NotificationOptions) {
    if (!('Notification' in window)) return;
    
    if (Notification.permission === 'granted') {
      try {
        const registration = await navigator.serviceWorker.getRegistration();
        if (registration) {
          registration.showNotification(title, {
            icon: '/pwa-192x192.png', // Assuming base icons exist
            badge: '/pwa-192x192.png',
            ...options,
          });
        } else {
          new Notification(title, options);
        }
      } catch (err) {
        console.error('Notification failed:', err);
      }
    }
  }

  static checkPermission() {
    if (!('Notification' in window)) return 'unsupported';
    return Notification.permission;
  }
}
