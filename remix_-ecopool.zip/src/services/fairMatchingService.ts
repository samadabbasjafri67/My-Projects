import { Ride, User } from '../types';

export interface FairMatchingInsight {
  priorityReason: string;
  isBoosted: boolean;
  explanation: string;
}

export const FairMatchingService = {
  /**
   * Calculates a fairness score to reorder search results.
   * Logic: Drivers with fewer recent rides or who are just starting get a slight visibility boost.
   */
  calculateFairnessPriority(ride: Ride, driverData: User | null): number {
    let score = 0;

    if (!driverData) return 0;

    // 1. Boost for New Drivers (less than 5 total rides)
    if ((driverData.totalRides || 0) < 5) {
      score += 50; 
    }

    // 2. Boost for drivers who haven't earned much today
    const todayEarnings = driverData.driverEarnings?.today || 0;
    if (todayEarnings === 0) {
      score += 30;
    }

    // 3. Penalty for high cancellation counts (simulated)
    const cancellations = driverData.cancellationCount || 0;
    score -= (cancellations * 10);

    return score;
  },

  getFairnessInsight(ride: Ride, driverData: User | null, language: string): FairMatchingInsight | null {
    const isHindi = language === 'hi';
    
    if (!driverData) return null;

    if ((driverData.totalRides || 0) < 5) {
      return {
        isBoosted: true,
        priorityReason: isHindi ? 'नया ड्राइवर' : 'New Driver',
        explanation: isHindi 
          ? 'इस ड्राइवर को मंच पर शुरुआत करने में मदद करने के लिए प्राथमिकता दी जा रही है।' 
          : 'This driver is being prioritized to help them get started on the platform.'
      };
    }

    if ((driverData.driverEarnings?.today || 0) === 0) {
      return {
        isBoosted: true,
        priorityReason: isHindi ? 'उचित अवसर' : 'Fair Chance',
        explanation: isHindi 
          ? 'हमारा एल्गोरिदम यह सुनिश्चित करता है कि सभी ड्राइवरों को प्रतिदिन समान अवसर मिले।' 
          : 'Our algorithm ensures all drivers get equal opportunities daily.'
      };
    }

    return null;
  }
};
