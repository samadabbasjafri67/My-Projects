import { db, collection, query, where, getDocs, limit, orderBy } from '../firebase';
import { Booking, Ride } from '../types';

export interface PredictiveHint {
  from: string;
  to: string;
  timeSlot: string;
  frequency: number;
  label: string;
  type: 'frequent' | 'time_based' | 'recent';
}

export const PredictionService = {
  /**
   * Mocking or fetching actual bookings and analyzing patterns
   */
  async getRecentBookings(userId: string): Promise<Booking[]> {
    try {
      const bookingsRef = collection(db, 'bookings');
      const q = query(
        bookingsRef,
        where('passenger', '==', userId),
        orderBy('bookedAt', 'desc'),
        limit(20)
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => doc.data() as Booking);
    } catch (error) {
      console.error("Booking fetch error:", error);
      return [];
    }
  },

  analyzePatterns(bookings: Booking[], language: string): PredictiveHint | null {
    if (bookings.length === 0) return null;

    const frequencyMap: { [key: string]: number } = {};
    const timePatterns: { [key: string]: { [key: string]: number } } = {};

    bookings.forEach(b => {
      if (!b.ride) return;
      const routeKey = `${b.ride.from} -> ${b.ride.to}`;
      frequencyMap[routeKey] = (frequencyMap[routeKey] || 0) + 1;

      const time = b.ride.time;
      const hour = time.split(':')[0];
      if (!timePatterns[hour]) timePatterns[hour] = {};
      timePatterns[hour][routeKey] = (timePatterns[hour][routeKey] || 0) + 1;
    });

    const currentHour = new Date().getHours().toString().padStart(2, '0');
    const relevantHourPattern = timePatterns[currentHour];

    if (relevantHourPattern) {
      const topRoute = Object.entries(relevantHourPattern).sort((a, b) => b[1] - a[1])[0];
      if (topRoute) {
        const [from, to] = topRoute[0].split(' -> ');
        return {
          from,
          to,
          timeSlot: `${currentHour}:00`,
          frequency: topRoute[1],
          label: language === 'hi' ? 'आप आमतौर पर इस समय कॉलेज जाते हैं' : 'You usually travel around this time',
          type: 'time_based'
        };
      }
    }

    const mostFrequent = Object.entries(frequencyMap).sort((a, b) => b[1] - a[1])[0];
    if (mostFrequent && mostFrequent[1] >= 2) {
      const [from, to] = mostFrequent[0].split(' -> ');
      return {
        from,
        to,
        timeSlot: '09:00', // Default
        frequency: mostFrequent[1],
        label: language === 'hi' ? 'आपका अक्सर लिया जाने वाला मार्ग' : 'Your most frequent route',
        type: 'frequent'
      };
    }

    return null;
  }
};
