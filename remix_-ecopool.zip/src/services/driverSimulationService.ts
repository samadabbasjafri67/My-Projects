import { db, doc, updateDoc, getDoc, auth } from '../firebase';
import { Ride } from '../types';

export class DriverSimulationService {
  private static simulationIntervals: Record<string, NodeJS.Timeout> = {};

  /**
   * Starts a simulation for a specific ride
   * Moves the driver from their current location to the pickup point
   */
  static startSimulation(rideId: string, fromCoords: { lat: number, lng: number } | null) {
    if (this.simulationIntervals[rideId]) return;
    if (!fromCoords) return;

    const user = auth.currentUser;
    if (!user) return;

    let step = 0;
    const totalSteps = 100;
    
    // Initial random position somewhat near the pickup point
    let currentLat = fromCoords.lat + (Math.random() - 0.5) * 0.02;
    let currentLng = fromCoords.lng + (Math.random() - 0.5) * 0.02;

    const interval = setInterval(async () => {
      step++;
      
      // Calculate next position (linear interpolation with a bit of noise)
      const latDiff = (fromCoords.lat - currentLat) / (totalSteps - step + 1);
      const lngDiff = (fromCoords.lng - currentLng) / (totalSteps - step + 1);
      
      currentLat += latDiff + (Math.random() - 0.5) * 0.0001;
      currentLng += lngDiff + (Math.random() - 0.5) * 0.0001;

      const newLoc = {
        lat: currentLat,
        lng: currentLng,
        timestamp: new Date().toISOString()
      };

      try {
        // Double-check auth remains valid and matches driver privilege before doing the call
        if (auth.currentUser) {
          await updateDoc(doc(db, 'rides', rideId), {
            currentLocation: newLoc
          });
        }
      } catch (error) {
        console.error(`Simulation error for ride ${rideId}:`, error);
        this.stopSimulation(rideId);
      }

      if (step >= totalSteps) {
        this.stopSimulation(rideId);
      }
    }, 5000); // Update every 5 seconds

    this.simulationIntervals[rideId] = interval;
  }

  static stopSimulation(rideId: string) {
    if (this.simulationIntervals[rideId]) {
      clearInterval(this.simulationIntervals[rideId]);
      delete this.simulationIntervals[rideId];
    }
  }

  /**
   * Automatically starts simulations for rides that are 'on_the_way'
   */
  static syncAllActiveSimulations(rides: Ride[]) {
    const user = auth.currentUser;
    rides.forEach(ride => {
      // Check if any booking in this ride is 'on_the_way'
      const hasActiveBooking = ride.bookings?.some(b => b.pickupStatus === 'on_the_way');
      
      // ONLY simulate if user is authenticated and is the driver of this ride
      const isDriver = user && ride.driver === user.uid;
      
      if (hasActiveBooking && ride.fromCoords && isDriver) {
        this.startSimulation(String(ride.id), ride.fromCoords);
      } else {
        this.stopSimulation(String(ride.id));
      }
    });
  }
}
