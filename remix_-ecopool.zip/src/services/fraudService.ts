import { db, doc, updateDoc, getDoc, collection, query, where, getDocs, increment, serverTimestamp } from '../firebase';
import { User, Booking } from '../types';

export const FraudService = {
  /**
   * Evaluates a user's behavior and updates their fraud score.
   */
  evaluateUser: async (userId: string) => {
    try {
      const userRef = doc(db, 'users', userId);
      const userSnap = await getDoc(userRef);
      
      if (!userSnap.exists()) return;
      
      const userData = userSnap.data() as User;
      const cancellations = userData.cancellationCount || 0;
      const suspicious = userData.suspiciousActivityCount || 0;
      
      // Basic logic: Score increases with negative actions
      // Max score 100
      let score = (cancellations * 10) + (suspicious * 25);
      score = Math.min(score, 100);
      
      let trustLevel: User['trustLevel'] = 'trusted';
      if (score > 70) trustLevel = 'blocked';
      else if (score > 40) trustLevel = 'suspicious';
      else if (score > 20) trustLevel = 'neutral';
      
      const isFlagged = score > 40;
      
      await updateDoc(userRef, {
        fraudScore: score,
        trustLevel,
        isFlagged,
        lastFraudCheckAt: new Date().toISOString()
      });
      
      return { score, trustLevel, isFlagged };
    } catch (error) {
      console.error("Fraud Evaluation Error:", error);
      return null;
    }
  },

  /**
   * Tracks a cancellation and triggers evaluation.
   */
  recordCancellation: async (userId: string, reason: string) => {
    try {
      const userRef = doc(db, 'users', userId);
      await updateDoc(userRef, {
        cancellationCount: increment(1)
      });
      
      await FraudService.evaluateUser(userId);
    } catch (error) {
      console.error("Record Cancellation Error:", error);
    }
  },

  /**
   * Detects duplicate or rapid booking attempts (Spam detection).
   */
  checkBookingSpam: async (userId: string): Promise<boolean> => {
    try {
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
      const q = query(
        collection(db, 'bookings'),
        where('passenger', '==', userId),
        where('bookedAt', '>', fiveMinutesAgo)
      );
      
      const snapshot = await getDocs(q);
      
      // If user made more than 3 bookings in 5 minutes, flag as suspicious
      if (snapshot.size > 3) {
        const userRef = doc(db, 'users', userId);
        await updateDoc(userRef, {
          suspiciousActivityCount: increment(1)
        });
        await FraudService.evaluateUser(userId);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error("Spam Check Error:", error);
      return false;
    }
  }
};
