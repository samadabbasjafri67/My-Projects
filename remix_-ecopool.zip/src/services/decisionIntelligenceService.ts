import { Ride } from '../types';

export interface DecisionInsight {
  betterRide: Ride;
  reason: string;
  saving?: number;
  type: 'cheaper' | 'eco' | 'rating';
}

export const DecisionIntelligenceService = {
  findBetterOption(currentRide: Ride, allResults: Ride[], language: string): DecisionInsight | null {
    if (allResults.length <= 1) return null;

    const isHindi = language === 'hi';

    // 1. Check for significantly cheaper options
    const cheaperOptions = allResults
      .filter(r => r.id !== currentRide.id && r.seats > 0 && r.price < currentRide.price - 10)
      .sort((a, b) => a.price - b.price);

    if (cheaperOptions.length > 0) {
      const bestCheaper = cheaperOptions[0];
      const saving = currentRide.price - bestCheaper.price;
      return {
        betterRide: bestCheaper,
        reason: isHindi 
          ? `यह सवारी ₹${saving} सस्ती है!` 
          : `This ride is ₹${saving} cheaper!`,
        saving,
        type: 'cheaper'
      };
    }

    // 2. Check for EV options if current isn't EV
    if (!currentRide.isEV) {
      const evOption = allResults.find(r => r.id !== currentRide.id && r.seats > 0 && r.isEV);
      if (evOption) {
        return {
          betterRide: evOption,
          reason: isHindi 
            ? 'पर्यावरण के अनुकूल विकल्प: इलेक्ट्रिक वाहन उपलब्ध है' 
            : 'Eco-friendly choice: Electric Vehicle available',
          type: 'eco'
        };
      }
    }

    // 3. Check for significantly better ratings
    const currentRating = (currentRide as any).averageRating || 0;
    const betterRated = allResults.find(r => {
      const rRating = (r as any).averageRating || 0;
      return r.id !== currentRide.id && r.seats > 0 && rRating > currentRating + 0.5;
    });

    if (betterRated) {
      return {
        betterRide: betterRated,
        reason: isHindi
          ? 'उच्च रेटिंग वाला ड्राइवर उपलब्ध है'
          : 'Higher rated driver available',
        type: 'rating'
      };
    }

    return null;
  }
};
