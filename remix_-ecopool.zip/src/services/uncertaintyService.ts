import { Ride, User } from '../types';

export type UncertaintyLevel = 'stable' | 'moderate' | 'uncertain';

export interface UncertaintyInsight {
  level: UncertaintyLevel;
  label: string;
  score: number; // 0 (stable) to 100 (uncertain)
  factors: string[];
}

export const UncertaintyService = {
  calculateUncertainty(ride: Ride, driverProfile: User | null, language: string): UncertaintyInsight {
    const isHindi = language === 'hi';
    const factors: string[] = [];
    let score = 20; // Baseline score

    // 1. Driver Experience Factor
    const totalRides = driverProfile?.totalRides || 0;
    if (totalRides < 10) {
      score += 20;
      factors.push(isHindi ? 'नया ड्राइवर (गहराई से जांचा जा रहा है)' : 'New Driver (In validation)');
    } else if (totalRides > 200) {
      score -= 10; // Veteran driver
    }

    // 2. Cancellation Factor
    const cancellations = driverProfile?.cancellationCount || 0;
    if (cancellations > 0) {
      const cancelRate = cancellations / (totalRides || 1);
      if (cancelRate > 0.15) {
        score += 40;
        factors.push(isHindi ? 'उच्च रद्दीकरण दर' : 'High cancellation rate');
      } else if (cancelRate > 0.05) {
        score += 15;
        factors.push(isHindi ? 'अस्थिर रद्दीकरण इतिहास' : 'Occasional cancellations');
      }
    }

    // 3. Peak Hour Factor (Time-based Traffic)
    const hour = parseInt(ride.time.split(':')[0]);
    const isPeakHour = (hour >= 8 && hour <= 10) || (hour >= 17 && hour <= 20);
    if (isPeakHour) {
      score += 25;
      factors.push(isHindi ? 'पीक ऑवर ट्रैफिक' : 'Peak hour traffic');
    }

    // 4. Rating Factor
    const rating = (ride as any).averageRating || 4.5;
    if (rating < 4.2) {
      score += 25;
      factors.push(isHindi ? 'कम रेटिंग' : 'Lower historical rating');
    }

    // Final categorization
    let level: UncertaintyLevel = 'stable';
    let label = isHindi ? 'स्थिर सवारी' : 'Stable Ride';

    if (score >= 70) {
      level = 'uncertain';
      label = isHindi ? 'उच्च अनिश्चितता' : 'High Uncertainty';
    } else if (score >= 40) {
      level = 'moderate';
      label = isHindi ? 'मध्यम जोखिम' : 'Moderate Risk';
    }

    if (factors.length === 0) {
      factors.push(isHindi ? 'आदर्श परिस्थितियां' : 'Ideal conditions');
    }

    return { 
      level, 
      label, 
      score: Math.min(score, 100), 
      factors: factors.slice(0, 2) // Limit to top 2 factors
    };
  }
};
